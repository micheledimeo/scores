#!/bin/bash

# Script di installazione per ledimeo.com su Ubuntu con Apache
# Questo script installa tutte le dipendenze necessarie e configura il sito

set -e  # Esce in caso di errore

echo "=========================================="
echo "Installazione ledimeo.com"
echo "=========================================="
echo ""

# Colori per output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Variabili configurabili
SITE_DIR="/var/www/ledimeo"
DOMAIN="ledimeo.com"
NODE_VERSION="20"
PORT="3000"

# Funzione per stampare messaggi
print_message() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verifica se lo script è eseguito come root
if [ "$EUID" -ne 0 ]; then 
    print_error "Questo script deve essere eseguito come root (usa sudo)"
    exit 1
fi

print_message "Aggiornamento del sistema..."
apt update && apt upgrade -y

# Installazione Node.js
print_message "Installazione Node.js ${NODE_VERSION}..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash -
    apt install -y nodejs
    print_message "Node.js installato: $(node --version)"
else
    print_message "Node.js già installato: $(node --version)"
fi

# Installazione PM2
print_message "Installazione PM2..."
if ! command -v pm2 &> /dev/null; then
    npm install -g pm2
    print_message "PM2 installato"
else
    print_message "PM2 già installato"
fi

# Installazione Apache (se non presente)
print_message "Verifica installazione Apache..."
if ! command -v apache2 &> /dev/null; then
    apt install -y apache2
    print_message "Apache installato"
else
    print_message "Apache già installato"
fi

# Abilita moduli Apache necessari
print_message "Abilitazione moduli Apache..."
a2enmod proxy
a2enmod proxy_http
a2enmod ssl
a2enmod rewrite
a2enmod headers

# Creazione directory del sito
print_message "Creazione directory del sito in ${SITE_DIR}..."
mkdir -p ${SITE_DIR}

# Copia dei file (assumendo che lo script sia nella root del progetto)
print_message "Copia dei file del progetto..."
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cp -r ${SCRIPT_DIR}/* ${SITE_DIR}/
cd ${SITE_DIR}

# Installazione dipendenze Node.js
print_message "Installazione dipendenze npm..."
npm install --legacy-peer-deps

# Build dell'applicazione
print_message "Build dell'applicazione Next.js..."
npm run build

# Configurazione variabili d'ambiente
print_message "Configurazione variabili d'ambiente..."
if [ ! -f "${SITE_DIR}/.env.production" ]; then
    cat > ${SITE_DIR}/.env.production << EOF
NEXTAUTH_URL=https://${DOMAIN}
NEXTAUTH_SECRET=$(openssl rand -base64 32)
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret
NODE_ENV=production
EOF
    print_warning "File .env.production creato. IMPORTANTE: Modifica ${SITE_DIR}/.env.production con le tue credenziali Google!"
else
    print_message "File .env.production già esistente"
fi

# Creazione file ecosystem PM2
print_message "Configurazione PM2..."
cat > ${SITE_DIR}/ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'ledimeo',
    script: 'node_modules/next/dist/bin/next',
    args: 'start',
    cwd: '${SITE_DIR}',
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: ${PORT}
    }
  }]
}
EOF

# Configurazione Apache Virtual Host
print_message "Configurazione Apache Virtual Host..."
cat > /etc/apache2/sites-available/${DOMAIN}.conf << EOF
<VirtualHost *:80>
    ServerName ${DOMAIN}
    ServerAlias www.${DOMAIN}
    
    ProxyPreserveHost On
    ProxyPass / http://localhost:${PORT}/
    ProxyPassReverse / http://localhost:${PORT}/
    
    # Gestione WebSocket per Next.js
    RewriteEngine on
    RewriteCond %{HTTP:Upgrade} websocket [NC]
    RewriteCond %{HTTP:Connection} upgrade [NC]
    RewriteRule ^/?(.*) "ws://localhost:${PORT}/\$1" [P,L]
    
    ErrorLog \${APACHE_LOG_DIR}/${DOMAIN}-error.log
    CustomLog \${APACHE_LOG_DIR}/${DOMAIN}-access.log combined
</VirtualHost>
EOF

# Disabilita il sito default e abilita il nuovo
print_message "Abilitazione del sito..."
a2dissite 000-default.conf 2>/dev/null || true
a2ensite ${DOMAIN}.conf

# Test configurazione Apache
print_message "Test configurazione Apache..."
apache2ctl configtest

# Riavvio Apache
print_message "Riavvio Apache..."
systemctl restart apache2

# Avvio applicazione con PM2
print_message "Avvio applicazione con PM2..."
# Ferma eventuali istanze precedenti
pm2 delete ledimeo 2>/dev/null || true
# Avvia la nuova istanza
pm2 start ${SITE_DIR}/ecosystem.config.js
pm2 save

# Configura PM2 per avviarsi al boot
print_message "Configurazione avvio automatico PM2..."
env PATH=$PATH:/usr/bin pm2 startup systemd -u root --hp /root
systemctl enable pm2-root

# Configurazione firewall (se ufw è installato)
if command -v ufw &> /dev/null; then
    print_message "Configurazione firewall..."
    ufw allow 'Apache Full'
fi

# Installazione Certbot per SSL (opzionale)
print_message "Vuoi installare Certbot per SSL/HTTPS? (s/n)"
read -r install_ssl
if [ "$install_ssl" = "s" ] || [ "$install_ssl" = "S" ]; then
    print_message "Installazione Certbot..."
    apt install -y certbot python3-certbot-apache
    print_message "Per ottenere il certificato SSL, esegui:"
    print_message "sudo certbot --apache -d ${DOMAIN} -d www.${DOMAIN}"
fi

echo ""
echo "=========================================="
echo -e "${GREEN}Installazione completata!${NC}"
echo "=========================================="
echo ""
echo "Prossimi passi:"
echo "1. Modifica il file ${SITE_DIR}/.env.production con le tue credenziali Google"
echo "2. Configura Google OAuth Console:"
echo "   - Aggiungi https://${DOMAIN}/api/auth/callback/google agli URI di reindirizzamento"
echo "3. Riavvia l'applicazione: pm2 restart ledimeo"
echo "4. Se hai installato Certbot, esegui: sudo certbot --apache -d ${DOMAIN} -d www.${DOMAIN}"
echo ""
echo "Comandi utili:"
echo "  - Visualizza log: pm2 logs ledimeo"
echo "  - Riavvia app: pm2 restart ledimeo"
echo "  - Stato app: pm2 status"
echo "  - Riavvia Apache: sudo systemctl restart apache2"
echo ""
echo "Il sito sarà accessibile su: http://${DOMAIN}"
echo ""
