# LEDIMEO.COM - Portfolio Website

A modern portfolio website for Michele Di Meo featuring Google authentication, theme toggle, and self-hosted portal monitoring.

## Features

- **Responsive Design**: Fully responsive layout matching the original ledimeo.com design
- **Theme Toggle**: Light/dark mode support with smooth transitions
- **Google Authentication**: Secure login restricted to authorized email (micheledmeo@gmail.com)
- **Portal Monitoring**: Real-time status monitoring for 8 self-hosted portals
  - Dynamic status badges (up/down)
  - Ping time measurements
  - Auto-refresh every 2 minutes
  - Manual refresh option
- **Sections**:
  - Hero with profile image
  - Experiments showcase
  - Protected Portali dashboard
  - Contact form
  - Footer with social links

## Setup Instructions

### 1. Environment Variables

Create a `.env.local` file in the root directory with the following variables:

\`\`\`env
# NextAuth Configuration
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your-secret-key-here

# Google OAuth
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret
\`\`\`

### 2. Google OAuth Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select an existing one
3. Enable the Google+ API
4. Go to "Credentials" and create OAuth 2.0 Client ID
5. Add authorized redirect URIs:
   - `http://localhost:3000/api/auth/callback/google` (development)
   - `https://yourdomain.com/api/auth/callback/google` (production)
6. Copy the Client ID and Client Secret to your `.env.local` file

### 3. Install Dependencies

\`\`\`bash
npm install
\`\`\`

### 4. Run Development Server

\`\`\`bash
npm run dev
\`\`\`

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Portal Monitoring

The Portali section monitors the following self-hosted services:

- NAS (https://nas.ledimeo.com)
- Cloud (https://cloud.ledimeo.com)
- Jellyfin (https://jelly.ledimeo.com)
- NPM (https://npm.ledimeo.com)
- Cloud Ottoniascoppio (https://cloud.ottoniascoppio.org)
- Radio Ottoniascoppio (https://radio.ottoniascoppio.org)
- Webmin (https://ottoniascoppio.org:10000)
- Port 9000 (https://ottoniascoppio.org:9000)

Status checks are performed server-side with a 5-second timeout per portal.

## Authentication

Only the email `micheledmeo@gmail.com` is authorized to access the Portali section. Other users will see an "Access Restricted" message.

## Technology Stack

- **Framework**: Next.js 15 (App Router)
- **Authentication**: NextAuth.js (Auth.js)
- **Styling**: Tailwind CSS v4
- **UI Components**: shadcn/ui
- **Theme**: next-themes
- **Icons**: Lucide React
- **Fonts**: Geist Sans & Geist Mono

## Deployment

### Vercel (Recommended)

1. Push your code to GitHub
2. Import the project in Vercel
3. Add environment variables in Vercel dashboard
4. Update Google OAuth redirect URIs with your production URL
5. Deploy

### Other Platforms

Ensure you set all required environment variables and update the `NEXTAUTH_URL` to match your production domain.

## License

Copyright © ledimeo.com 2016-2025
