#!/bin/bash

# Script di aggiornamento per ledimeo.com
# Usa questo script per aggiornare il sito dopo modifiche

set -e

echo "=========================================="
echo "Aggiornamento ledimeo.com"
echo "=========================================="
echo ""

GREEN='\033[0;32m'
NC='\033[0m'

SITE_DIR="/var/www/ledimeo"

print_message() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

if [ "$EUID" -ne 0 ]; then 
    echo "Questo script deve essere eseguito come root (usa sudo)"
    exit 1
fi

cd ${SITE_DIR}

print_message "Backup della build precedente..."
if [ -d ".next" ]; then
    rm -rf .next.backup 2>/dev/null || true
    cp -r .next .next.backup
fi

print_message "Installazione dipendenze..."
npm install --legacy-peer-deps --production

print_message "Build dell'applicazione..."
npm run build

print_message "Riavvio applicazione..."
pm2 restart ledimeo

print_message "Verifica stato..."
pm2 status

echo ""
echo "=========================================="
echo -e "${GREEN}Aggiornamento completato!${NC}"
echo "=========================================="
echo ""
echo "Visualizza i log con: pm2 logs ledimeo"
echo ""
