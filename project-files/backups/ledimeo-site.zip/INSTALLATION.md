# Guida all'Installazione di ledimeo.com

## Prerequisiti

- Server Ubuntu 20.04 o superiore
- Accesso root o sudo
- Dominio configurato (ledimeo.com) che punta al server

## Installazione Rapida

### 1. Carica i file sul server

\`\`\`bash
# Dal tuo computer locale, carica tutti i file del progetto
scp -r * root@your-server-ip:/root/ledimeo-install/
\`\`\`

### 2. Esegui lo script di installazione

\`\`\`bash
# Connettiti al server
ssh root@your-server-ip

# Vai nella directory
cd /root/ledimeo-install

# Rendi eseguibile lo script
chmod +x install.sh

# Esegui l'installazione
./install.sh
\`\`\`

Lo script installerà automaticamente:
- Node.js 20
- PM2 (process manager)
- Apache (se non presente)
- Tutte le dipendenze npm
- Configurazione Apache come reverse proxy
- Avvio automatico dell'applicazione

### 3. Configura le variabili d'ambiente

Dopo l'installazione, modifica il file con le tue credenziali:

\`\`\`bash
nano /var/www/ledimeo/.env.production
\`\`\`

Aggiorna questi valori:
\`\`\`
GOOGLE_CLIENT_ID=il-tuo-client-id-reale
GOOGLE_CLIENT_SECRET=il-tuo-client-secret-reale
\`\`\`

### 4. Riavvia l'applicazione

\`\`\`bash
pm2 restart ledimeo
\`\`\`

### 5. Configura SSL (Opzionale ma Raccomandato)

\`\`\`bash
sudo certbot --apache -d ledimeo.com -d www.ledimeo.com
\`\`\`

## Configurazione Google OAuth

1. Vai su [Google Cloud Console](https://console.cloud.google.com/)
2. Crea un nuovo progetto o seleziona uno esistente
3. Abilita "Google+ API"
4. Vai su "Credenziali" → "Crea credenziali" → "ID client OAuth"
5. Tipo applicazione: "Applicazione web"
6. Aggiungi URI di reindirizzamento autorizzati:
   - `https://ledimeo.com/api/auth/callback/google`
   - `http://localhost:3000/api/auth/callback/google` (per sviluppo locale)
7. Copia Client ID e Client Secret nel file `.env.production`

## Aggiornamenti Futuri

Per aggiornare il sito dopo modifiche:

\`\`\`bash
# Carica i nuovi file
scp -r * root@your-server-ip:/var/www/ledimeo/

# Sul server, esegui lo script di aggiornamento
cd /var/www/ledimeo
chmod +x update.sh
./update.sh
\`\`\`

## Comandi Utili

\`\`\`bash
# Visualizza log in tempo reale
pm2 logs ledimeo

# Stato dell'applicazione
pm2 status

# Riavvia l'applicazione
pm2 restart ledimeo

# Ferma l'applicazione
pm2 stop ledimeo

# Riavvia Apache
sudo systemctl restart apache2

# Verifica configurazione Apache
sudo apache2ctl configtest

# Visualizza log Apache
sudo tail -f /var/log/apache2/ledimeo.com-error.log
\`\`\`

## Risoluzione Problemi

### L'applicazione non si avvia

\`\`\`bash
# Controlla i log
pm2 logs ledimeo

# Verifica che Node.js sia installato
node --version

# Verifica che le dipendenze siano installate
cd /var/www/ledimeo
npm install
\`\`\`

### Apache non funziona

\`\`\`bash
# Verifica stato Apache
sudo systemctl status apache2

# Testa la configurazione
sudo apache2ctl configtest

# Riavvia Apache
sudo systemctl restart apache2
\`\`\`

### Errori di autenticazione Google

1. Verifica che le credenziali in `.env.production` siano corrette
2. Controlla che l'URI di reindirizzamento sia configurato correttamente in Google Cloud Console
3. Assicurati che `NEXTAUTH_URL` corrisponda al dominio effettivo

## Struttura Directory

\`\`\`
/var/www/ledimeo/
├── app/                    # Pagine Next.js
├── components/             # Componenti React
├── lib/                    # Utility e configurazioni
├── public/                 # File statici
├── .next/                  # Build Next.js (generata)
├── .env.production         # Variabili d'ambiente
├── ecosystem.config.js     # Configurazione PM2
└── package.json           # Dipendenze npm
\`\`\`

## Sicurezza

- Il file `.env.production` contiene informazioni sensibili - non condividerlo
- Usa sempre HTTPS in produzione
- Mantieni aggiornati Node.js e le dipendenze npm
- Configura un firewall (ufw) per limitare l'accesso

## Supporto

Per problemi o domande, controlla:
- Log dell'applicazione: `pm2 logs ledimeo`
- Log Apache: `/var/log/apache2/ledimeo.com-error.log`
- Stato servizi: `pm2 status` e `sudo systemctl status apache2`
