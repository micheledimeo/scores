import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { VideoSection } from "@/components/video-section"
import { ExperimentsSection } from "@/components/experiments-section"
import { PortaliSection } from "@/components/portali-section"
import { ContactSection } from "@/components/contact-section"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <VideoSection />
        <PortaliSection />
        <ExperimentsSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  )
}
