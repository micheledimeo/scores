import { NextResponse } from "next/server"

export const dynamic = "force-dynamic"

interface PortalConfig {
  name: string
  url: string
}

const portals: PortalConfig[] = [
  { name: "NAS", url: "https://nas.ledimeo.com" },
  { name: "Cloud", url: "https://cloud.ledimeo.com" },
  { name: "Jellyfin", url: "https://jelly.ledimeo.com" },
  { name: "NPM", url: "https://npm.ledimeo.com" },
  { name: "Cloud Ottoniascoppio", url: "https://cloud.ottoniascoppio.org" },
  { name: "Radio Ottoniascoppio", url: "https://radio.ottoniascoppio.org" },
  { name: "Webmin", url: "https://ottoniascoppio.org:10000" },
  { name: "Port 9000", url: "https://ottoniascoppio.org:9000" },
]

async function checkPortalStatus(portal: PortalConfig) {
  const startTime = Date.now()

  try {
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 second timeout

    const response = await fetch(portal.url, {
      method: "HEAD",
      signal: controller.signal,
      headers: {
        "User-Agent": "Portal-Status-Checker/1.0",
      },
    })

    clearTimeout(timeoutId)
    const ping = Date.now() - startTime

    return {
      name: portal.name,
      url: portal.url,
      status: response.ok ? ("up" as const) : ("down" as const),
      ping,
      lastChecked: new Date(),
    }
  } catch (error) {
    return {
      name: portal.name,
      url: portal.url,
      status: "down" as const,
      ping: Date.now() - startTime,
      lastChecked: new Date(),
    }
  }
}

export async function GET() {
  try {
    const statusChecks = await Promise.all(portals.map((portal) => checkPortalStatus(portal)))

    return NextResponse.json({
      portals: statusChecks,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to check portal status" }, { status: 500 })
  }
}
