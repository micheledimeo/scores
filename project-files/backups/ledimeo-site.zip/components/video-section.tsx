"use client"

export function VideoSection() {
  const portals = [
    { name: "Portainer", url: "https://portainer.ledimeo.com", icon: "🐳", color: "bg-[#4a6b7c]" },
    { name: "Proxmox", url: "https://proxmox.ledimeo.com", icon: "💻", color: "bg-[#2fb5d2]" },
    { name: "Jellyfin", url: "https://jellyfin.ledimeo.com", icon: "🎬", color: "bg-[#3b8fc4]" },
    { name: "Nextcloud", url: "https://nextcloud.ledimeo.com", icon: "☁️", color: "bg-[#5a7c8c]" },
    { name: "Gitea", url: "https://gitea.ledimeo.com", icon: "📦", color: "bg-[#3ecf8e]" },
    { name: "Uptime Kuma", url: "https://uptime.ledimeo.com", icon: "📊", color: "bg-[#4a8b9c]" },
    { name: "Vaultwarden", url: "https://vaultwarden.ledimeo.com", icon: "🔐", color: "bg-[#2a5b6c]" },
    { name: "Home Assistant", url: "https://homeassistant.ledimeo.com", icon: "🏠", color: "bg-[#3d7f9c]" },
  ]

  return (
    <section className="w-full bg-white dark:bg-[var(--ledimeo-dark-bg)] pt-8 pb-20">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Video/iframe embed */}

          <div className="mb-12">
            <h2 className="text-4xl font-bold text-center mb-4 dark:text-white">PORTALS</h2>

            <div className="flex items-center justify-center gap-3 mb-12">
              <div className="h-px w-16 bg-gray-400"></div>
              <span className="text-gray-600 dark:text-gray-400 text-2xl">★</span>
              <div className="h-px w-16 bg-gray-400"></div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {portals.map((portal) => (
                <a
                  key={portal.name}
                  href={portal.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group aspect-square rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
                >
                  <div className={`relative w-full h-full ${portal.color} flex items-center justify-center`}>
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                      <div className="w-32 h-32 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                        <span className="text-6xl leading-none">{portal.icon}</span>
                      </div>
                      <span className="text-white font-medium text-center px-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        {portal.name}
                      </span>
                    </div>
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Star divider */}
          <div className="flex items-center justify-center gap-3 mt-12">
            <div className="h-px w-16 bg-gray-400"></div>
            <span className="text-gray-600 dark:text-gray-400 text-2xl">★</span>
            <div className="h-px w-16 bg-gray-400"></div>
          </div>
        </div>
      </div>
    </section>
  )
}
