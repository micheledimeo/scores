export function ExperimentsSection() {
  const experiments = [
    {
      icon: "🚢",
      title: "Submarine",
      color: "bg-[#4a6b7c]",
    },
    {
      icon: "🎪",
      title: "Circus",
      color: "bg-[#2fb5d2]",
    },
    {
      icon: "🎮",
      title: "Gaming",
      color: "bg-[#3b8fc4]",
    },
  ]

  return (
    <section id="experiments" className="w-full bg-[var(--ledimeo-cream)] dark:bg-[var(--ledimeo-dark-bg)] py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-4 dark:text-white">EXPERIMENTS</h2>

        <div className="flex items-center justify-center gap-3 mb-12">
          <div className="h-px w-16 bg-gray-400"></div>
          <span className="text-gray-600 dark:text-gray-400 text-2xl">★</span>
          <div className="h-px w-16 bg-gray-400"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {experiments.map((exp, index) => (
            <div
              key={index}
              className="group aspect-square rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow cursor-pointer"
            >
              <div className={`relative w-full h-full ${exp.color} flex items-center justify-center`}>
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                  <div className="w-32 h-32 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                    <span className="text-6xl leading-none">{exp.icon}</span>
                  </div>
                  <span className="text-white font-medium text-center px-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    {exp.title}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
