"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Activity, Clock } from "lucide-react"
import type { PortalStatus } from "@/types/portal"

interface PortalCardProps {
  portal: PortalStatus
}

export function PortalCard({ portal }: PortalCardProps) {
  const statusColor =
    portal.status === "up" ? "bg-green-500" : portal.status === "down" ? "bg-red-500" : "bg-yellow-500"

  const statusText = portal.status === "up" ? "Online" : portal.status === "down" ? "Offline" : "Checking..."

  return (
    <Card className="hover:shadow-lg transition-shadow dark:bg-[var(--ledimeo-dark-bg)] dark:border-gray-700">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <CardTitle className="text-lg font-semibold dark:text-white">{portal.name}</CardTitle>
          <Badge className={`${statusColor} text-white border-0`}>{statusText}</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <a
          href={portal.url}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 text-sm text-[var(--ledimeo-teal)] hover:underline break-all"
        >
          <ExternalLink className="h-4 w-4 flex-shrink-0" />
          <span className="truncate">{portal.url}</span>
        </a>

        {portal.ping !== undefined && (
          <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
            <Activity className="h-4 w-4" />
            <span>Ping: {portal.ping}ms</span>
          </div>
        )}

        {portal.version && (
          <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
            <span>Version: {portal.version}</span>
          </div>
        )}

        {portal.lastChecked && (
          <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-500">
            <Clock className="h-3 w-3" />
            <span>Last checked: {new Date(portal.lastChecked).toLocaleTimeString()}</span>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
