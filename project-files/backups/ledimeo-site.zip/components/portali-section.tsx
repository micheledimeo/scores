"use client"

import { useEffect, useState } from "react"
import { useSession } from "next-auth/react"
import { PortalCard } from "./portal-card"
import { Button } from "@/components/ui/button"
import { RefreshCw, Lock } from "lucide-react"
import type { PortalStatus } from "@/types/portal"

export function PortaliSection() {
  const { data: session } = useSession()
  const [portals, setPortals] = useState<PortalStatus[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  const fetchPortalStatus = async () => {
    try {
      setRefreshing(true)
      const response = await fetch("/api/portal-status")
      const data = await response.json()
      setPortals(data.portals)
    } catch (error) {
      console.error("Failed to fetch portal status:", error)
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  useEffect(() => {
    if (session?.user?.email === "micheledmeo@gmail.com") {
      fetchPortalStatus()

      // Auto-refresh every 2 minutes
      const interval = setInterval(fetchPortalStatus, 120000)
      return () => clearInterval(interval)
    }
  }, [session])

  // Show nothing if not authenticated
  if (!session) {
    return null
  }

  // Show unauthorized message if not the correct user
  if (session.user?.email !== "micheledmeo@gmail.com") {
    return (
      <section id="portali" className="w-full bg-white dark:bg-[var(--ledimeo-navy)] py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <Lock className="h-16 w-16 mx-auto mb-4 text-gray-400" />
            <h2 className="text-2xl font-bold mb-4 dark:text-white">Access Restricted</h2>
            <p className="text-gray-600 dark:text-gray-400">
              You do not have permission to view this section. Only authorized users can access the portals dashboard.
            </p>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section id="portali" className="w-full bg-white dark:bg-[var(--ledimeo-navy)] py-20">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-4xl font-bold dark:text-white">PORTALI</h2>
          <Button
            onClick={fetchPortalStatus}
            disabled={refreshing}
            variant="outline"
            size="sm"
            className="dark:border-gray-600 dark:text-white dark:hover:bg-[var(--ledimeo-dark-bg)] bg-transparent"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>

        <div className="flex items-center justify-center gap-3 mb-12">
          <div className="h-px w-16 bg-gray-400"></div>
          <span className="text-gray-600 dark:text-gray-400 text-2xl">★</span>
          <div className="h-px w-16 bg-gray-400"></div>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <RefreshCw className="h-8 w-8 animate-spin mx-auto text-[var(--ledimeo-teal)]" />
            <p className="mt-4 text-gray-600 dark:text-gray-400">Checking portal status...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {portals.map((portal) => (
              <PortalCard key={portal.url} portal={portal} />
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
