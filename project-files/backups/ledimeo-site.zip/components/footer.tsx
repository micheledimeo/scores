import { Mail, Facebook, Linkedin } from "lucide-react"

export function Footer() {
  return (
    <footer className="w-full bg-[var(--ledimeo-navy)] dark:bg-[var(--ledimeo-dark-bg)] text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
          <div>
            <h3 className="font-bold mb-2 uppercase tracking-wide">Location</h3>
            <p className="text-sm text-gray-300">
              Calvello (Basilicata)
              <br />
              85010 Bernalda (MT)
            </p>
          </div>

          <div>
            <h3 className="font-bold mb-2 uppercase tracking-wide">Around the Web</h3>
            <div className="flex justify-center md:justify-start gap-4">
              <a
                href="#"
                className="w-10 h-10 rounded-full border-2 border-white flex items-center justify-center hover:bg-white hover:text-[var(--ledimeo-navy)] transition-colors"
              >
                <Mail className="h-4 w-4" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full border-2 border-white flex items-center justify-center hover:bg-white hover:text-[var(--ledimeo-navy)] transition-colors"
              >
                <Facebook className="h-4 w-4" />
              </a>
              <a
                href="#"
                className="w-10 h-10 rounded-full border-2 border-white flex items-center justify-center hover:bg-white hover:text-[var(--ledimeo-navy)] transition-colors"
              >
                <Linkedin className="h-4 w-4" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-bold mb-2 uppercase tracking-wide">About a Freelancer</h3>
            <p className="text-sm text-gray-300">Defin edetorsi, non est ad astra mollis e terra via.</p>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-600 text-center text-sm text-gray-400">
          Copyright © ledimeo.com 2016
        </div>
      </div>
    </footer>
  )
}
