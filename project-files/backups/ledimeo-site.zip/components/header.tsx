"use client"

import Link from "next/link"
import { ThemeToggle } from "./theme-toggle"
import { useSession, signIn, signOut } from "next-auth/react"
import { Button } from "@/components/ui/button"
import { LogIn, LogOut } from "lucide-react"

export function Header() {
  const { data: session } = useSession()

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b border-[var(--ledimeo-navy)] bg-[var(--ledimeo-navy)] dark:bg-[var(--ledimeo-dark-bg)]">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link href="/" className="text-lg font-bold text-white tracking-wider">
          LEDIMEO.COM
        </Link>

        <nav className="flex items-center gap-6">
          <button
            onClick={() => scrollToSection("experiments")}
            className="text-sm font-medium text-white hover:text-[var(--ledimeo-teal)] transition-colors uppercase tracking-wide"
          >
            EXPERIMENTS
          </button>
          {session?.user?.email === "micheledmeo@gmail.com" && (
            <button
              onClick={() => scrollToSection("portali")}
              className="text-sm font-medium text-white hover:text-[var(--ledimeo-teal)] transition-colors uppercase tracking-wide"
            >
              PORTALI
            </button>
          )}
          <button
            onClick={() => scrollToSection("contact")}
            className="text-sm font-medium bg-[var(--ledimeo-teal)] text-white px-4 py-2 rounded hover:opacity-90 transition-opacity uppercase tracking-wide"
          >
            CONTACT
          </button>
          <ThemeToggle />
          {session ? (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => signOut()}
              className="h-9 w-9 text-white hover:text-[var(--ledimeo-teal)]"
              title="Logout"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          ) : (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => signIn("google")}
              className="h-9 w-9 text-white hover:text-[var(--ledimeo-teal)]"
              title="Login with Google"
            >
              <LogIn className="h-4 w-4" />
            </Button>
          )}
        </nav>
      </div>
    </header>
  )
}
