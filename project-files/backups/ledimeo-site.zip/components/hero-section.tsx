export function HeroSection() {
  return (
    <section className="w-full bg-gradient-to-br from-[#3ecf8e] to-[#2ab574] dark:from-[#2ab574] dark:to-[#1f8a5a] py-20">
      <div className="container mx-auto px-4 text-center">
        <div className="flex justify-center mb-6">
          <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white shadow-lg">
            <img
              src="/professional-developer-portrait.png"
              alt="Michele Di Meo"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        <h1 className="text-5xl font-bold text-white mb-4">LEDIMEO</h1>

        <div className="flex items-center justify-center gap-3 mb-6">
          <div className="h-px w-16 bg-white"></div>
          <span className="text-white text-2xl">★</span>
          <div className="h-px w-16 bg-white"></div>
        </div>

        <p className="text-white text-lg font-medium mb-8">Dream Developer · Code Artist · Trumpet Lover</p>

        <div className="flex justify-center mt-8">
          <div className="w-full max-w-2xl bg-white/10 backdrop-blur-sm rounded-lg p-4 shadow-lg">
            <iframe
              src="https://radio.ottoniscoppio.org/public/ottoniscoppio_radio/embed"
              frameBorder="0"
              allowTransparency={true}
              className="w-full h-[120px]"
              title="Azuracast Radio Player"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
