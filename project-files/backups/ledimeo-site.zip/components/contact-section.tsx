"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export function ContactSection() {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    message: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Form submitted:", formData)
  }

  return (
    <section id="contact" className="w-full bg-white dark:bg-[var(--ledimeo-navy)] py-20">
      <div className="container mx-auto px-4 max-w-2xl">
        <h2 className="text-4xl font-bold text-center mb-4 dark:text-white">CONTACT ME</h2>

        <div className="flex items-center justify-center gap-3 mb-12">
          <div className="h-px w-16 bg-gray-400"></div>
          <span className="text-gray-600 dark:text-gray-400 text-2xl">★</span>
          <div className="h-px w-16 bg-gray-400"></div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <Input
            type="text"
            placeholder="Full name"
            value={formData.fullName}
            onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
            className="bg-white dark:bg-[var(--ledimeo-dark-bg)] dark:text-white dark:border-gray-600"
          />

          <Input
            type="email"
            placeholder="Email address"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            className="bg-white dark:bg-[var(--ledimeo-dark-bg)] dark:text-white dark:border-gray-600"
          />

          <Input
            type="tel"
            placeholder="Phone number"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            className="bg-white dark:bg-[var(--ledimeo-dark-bg)] dark:text-white dark:border-gray-600"
          />

          <Textarea
            placeholder="Message"
            value={formData.message}
            onChange={(e) => setFormData({ ...formData, message: e.target.value })}
            rows={6}
            className="bg-white dark:bg-[var(--ledimeo-dark-bg)] dark:text-white dark:border-gray-600"
          />

          <Button type="submit" className="bg-[var(--ledimeo-teal)] hover:bg-[#2ab574] text-white px-8">
            Send
          </Button>
        </form>
      </div>
    </section>
  )
}
