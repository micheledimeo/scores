export interface PortalStatus {
  name: string
  url: string
  status: "up" | "down" | "checking"
  ping?: number
  version?: string
  lastChecked?: Date
}
