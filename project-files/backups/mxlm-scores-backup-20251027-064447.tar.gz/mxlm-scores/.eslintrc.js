module.exports = {
	extends: [
		'@nextcloud',
	],
	rules: {
		// Regole personalizzate se necessario
	},
}
