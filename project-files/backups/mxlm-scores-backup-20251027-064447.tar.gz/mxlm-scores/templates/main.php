<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <div id="content" class="app-scores">
        <div id="app-content">
            <div id="app"></div>
        </div>
    </div>
</body>
</html>
