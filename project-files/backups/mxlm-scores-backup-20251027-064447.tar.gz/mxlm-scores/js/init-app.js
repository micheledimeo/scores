// CRITICAL: Set the app name for @nextcloud/vue BEFORE any components load
// This prevents the "@nextcloud/vue library was used without setting appName" error
window.OCA = window.OCA || {}
window.OCA.Scores = window.OCA.Scores || {}
window.OCA.Scores.appName = 'mxlmscores'

// Also set on window for compatibility
window.appName = 'mxlmscores'

console.log('✓ App name initialized:', window.appName)
