<template>
	<div class="music-viewer">
		<!-- Compact playback controls bar -->
		<div class="playback-controls">
			<div class="control-group">
				<!-- Play button -->
				<NcButton
					v-if="!isPlaying"
					type="primary"
					:disabled="!isLoaded || isInitializing"
					@click="play"
					:aria-label="'Play'">
					<template #icon>
						<Play :size="20" />
					</template>
				</NcButton>

				<!-- Pause button -->
				<NcButton
					v-if="isPlaying"
					:disabled="!isLoaded || isInitializing"
					@click="pause"
					:aria-label="'Pause'">
					<template #icon>
						<Pause :size="20" />
					</template>
				</NcButton>

				<!-- Stop button -->
				<NcButton
					:disabled="!isLoaded || isInitializing || (!isPlaying && currentTime === 0)"
					@click="stop"
					:aria-label="'Stop'">
					<template #icon>
						<Stop :size="20" />
					</template>
				</NcButton>

				<!-- Loop button -->
				<NcButton
					:disabled="!isLoaded || isInitializing"
					@click="toggleLoop"
					:class="{ 'loop-active': loopEnabled }"
					:aria-label="loopEnabled ? 'Loop enabled' : 'Loop disabled'">
					<template #icon>
						<Repeat :size="20" />
					</template>
				</NcButton>
			</div>

			<!-- Progress bar -->
			<div class="progress-section">
				<div class="progress-bar">
					<div class="progress-fill" :style="{ width: progressPercent + '%' }"></div>
				</div>
				<div class="time-display">
					<span>{{ formatTime(currentTime) }}</span>
					<span class="separator">/</span>
					<span>{{ formatTime(totalDuration) }}</span>
					<span class="measure-separator">•</span>
					<span class="measure-display">{{ currentMeasure + 1 }}/{{ totalMeasures }}</span>
				</div>
			</div>

			<!-- Tempo control -->
			<div class="tempo-control">
				<input
					id="tempo-input"
					v-model.number="tempo"
					type="number"
					min="40"
					max="240"
					step="1"
					class="tempo-input"
					:disabled="!isLoaded || isInitializing"
					@change="updateTempo"
					@keyup.enter="updateTempo">
				<span class="unit-label">BPM</span>
				<input
					id="tempo-slider"
					v-model.number="tempo"
					type="range"
					min="40"
					max="240"
					step="1"
					class="tempo-slider"
					:disabled="!isLoaded || isInitializing"
					@input="updateTempo">
			</div>

			<!-- Volume control -->
			<div class="volume-control">
				<input
					id="volume-input"
					v-model.number="volume"
					type="number"
					min="0"
					max="100"
					step="1"
					class="volume-input"
					:disabled="!isLoaded || isInitializing"
					@change="updateVolume"
					@keyup.enter="updateVolume">
				<span class="unit-label">%</span>
				<input
					id="volume-slider"
					v-model.number="volume"
					type="range"
					min="0"
					max="100"
					step="1"
					class="volume-slider"
					:disabled="!isLoaded || isInitializing"
					@input="updateVolume">
			</div>

			<!-- Zoom controls -->
			<div class="zoom-controls">
				<NcButton
					:disabled="!isLoaded"
					@click="zoomOut"
					:aria-label="'Zoom out'">
					<template #icon>
						<MagnifyMinusOutline :size="20" />
					</template>
				</NcButton>

				<span class="zoom-level">{{ Math.round(zoomLevel * 100) }}%</span>

				<NcButton
					:disabled="!isLoaded"
					@click="zoomIn"
					:aria-label="'Zoom in'">
					<template #icon>
						<MagnifyPlusOutline :size="20" />
					</template>
				</NcButton>
			</div>

			<!-- Share button -->
			<div class="share-control">
				<NcButton
					:disabled="!isLoaded"
					@click="shareScore"
					:aria-label="'Share score'"
					:title="'Share this score'">
					<template #icon>
						<ShareVariant :size="20" />
					</template>
				</NcButton>
			</div>
		</div>

		<!-- Sheet viewer -->
		<div class="sheet-viewer">
			<div v-if="loading" class="loading-spinner">
				<NcLoadingIcon :size="64" />
				<p>Loading score...</p>
			</div>
			<div
				v-if="!loading"
				ref="osmdContainer"
				class="osmd-container" />
		</div>

		<!-- Welcome Screen with Quick Tips - shown AFTER loading -->
		<div v-if="showWelcome && !loading && isLoaded" class="welcome-screen">
			<div class="welcome-content">
				<h2>{{ welcomeTitle }}</h2>
				
				<div class="quick-tips">
					<h3>{{ quickTipsTitle }}</h3>
					
					<div class="tip-item">
						<span class="tip-icon">⌨️</span>
						<div class="tip-text">
							<strong>{{ keyboardShortcutsTitle }}</strong>
							<ul>
								<li><kbd>Space</kbd> - {{ playPauseText }}</li>
								<li><kbd>←</kbd> <kbd>→</kbd> - {{ navigateMeasuresText }}</li>
								<li><kbd>+</kbd> <kbd>-</kbd> - {{ zoomText }}</li>
							</ul>
						</div>
					</div>
					
					<div class="tip-item">
						<span class="tip-icon">🎵</span>
						<div class="tip-text">
							<strong>{{ playbackControlsTitle }}</strong>
							<p>{{ playbackControlsDesc }}</p>
						</div>
					</div>
					
					<div class="tip-item">
						<span class="tip-icon">🔍</span>
						<div class="tip-text">
							<strong>{{ zoomTitle }}</strong>
							<p>{{ zoomDesc }}</p>
						</div>
					</div>
					
					<div class="tip-item">
						<span class="tip-icon">🔄</span>
						<div class="tip-text">
							<strong>{{ loopModeTitle }}</strong>
							<p>{{ loopModeDesc }}</p>
						</div>
					</div>
				</div>
				
				<NcButton
					type="primary"
					@click="closeWelcome">
					{{ gotItText }}
				</NcButton>
			</div>
		</div>
	</div>
</template>

<script>
import { ref, onMounted, onBeforeUnmount, markRaw, watch, nextTick } from 'vue'
import { showError, showSuccess } from '@nextcloud/dialogs'
import { translate as t } from '@nextcloud/l10n'
import axios from '@nextcloud/axios'
import { generateUrl } from '@nextcloud/router'

import { NcButton, NcLoadingIcon } from '@nextcloud/vue'

import { OpenSheetMusicDisplay } from 'opensheetmusicdisplay'
import PlaybackEngine from 'osmd-audio-player'
import { SoundfontPlayer } from 'osmd-audio-player/dist/players/SoundfontPlayer'

import Play from 'vue-material-design-icons/Play.vue'
import Pause from 'vue-material-design-icons/Pause.vue'
import Stop from 'vue-material-design-icons/Stop.vue'
import Repeat from 'vue-material-design-icons/Repeat.vue'
import MagnifyPlusOutline from 'vue-material-design-icons/MagnifyPlusOutline.vue'
import MagnifyMinusOutline from 'vue-material-design-icons/MagnifyMinusOutline.vue'
import ShareVariant from 'vue-material-design-icons/ShareVariant.vue'

export default {
	name: 'MusicViewer',
	components: {
		NcButton,
		NcLoadingIcon,
		Play,
		Pause,
		Stop,
		Repeat,
		MagnifyPlusOutline,
		MagnifyMinusOutline,
		ShareVariant,
	},
	props: {
		fileContent: {
			type: String,
			required: true,
		},
		fileName: {
			type: String,
			required: true,
		},
		fileId: {
			type: Number,
			required: false,
			default: null,
		},
		forceShowWelcome: {
			type: Boolean,
			default: false,
		},
	},
	emits: ['playback-state-changed', 'welcome-closed'],
	setup(props, { emit }) {
		// Refs
		const osmdContainer = ref(null)
		const osmd = ref(null)
		const playbackManager = ref(null)
		const audioContext = ref(null)
		const loading = ref(true)
		const isLoaded = ref(false)
		const isPlaying = ref(false)
		const isInitializing = ref(false)
		const tempo = ref(120)
		const volume = ref(80)
		const zoomLevel = ref(1.0)
		const currentTime = ref(0)
		const totalDuration = ref(0)
		const progressPercent = ref(0)
		const progressInterval = ref(null)
		const loopEnabled = ref(false)
		const showWelcome = ref(true)
		const currentMeasure = ref(0)
		const totalMeasures = ref(0)
		const playbackStartTime = ref(0) // AudioContext time when playback started
		const playbackStartOffset = ref(0) // Offset if starting from middle of score
		const currentTimestep = ref(0) // Current timestep for playback synchronization

		// Translations for welcome screen
		const welcomeTitle = ref(t('musicxmlviewer', 'Welcome to MusicXML Viewer'))
		const quickTipsTitle = ref(t('musicxmlviewer', 'Quick Tips'))
		const keyboardShortcutsTitle = ref(t('musicxmlviewer', 'Keyboard Shortcuts'))
		const playPauseText = ref(t('musicxmlviewer', 'Play/Pause'))
		const navigateMeasuresText = ref(t('musicxmlviewer', 'Navigate measures and start playback'))
		const zoomText = ref(t('musicxmlviewer', 'Zoom in/out'))
		const playbackControlsTitle = ref(t('musicxmlviewer', 'Playback Controls'))
		const playbackControlsDesc = ref(t('musicxmlviewer', 'Use the control bar to play, pause, stop, and loop your music. Adjust tempo and volume as needed.'))
		const zoomTitle = ref(t('musicxmlviewer', 'Zoom'))
		const zoomDesc = ref(t('musicxmlviewer', 'Use + and - buttons or keyboard shortcuts to zoom in and out of the score.'))
		const loopModeTitle = ref(t('musicxmlviewer', 'Loop Mode'))
		const loopModeDesc = ref(t('musicxmlviewer', 'Click the repeat button to enable continuous playback. The music will restart automatically when finished.'))
		const gotItText = ref(t('musicxmlviewer', 'Got it!'))

		// Format time in mm:ss
		const formatTime = (seconds) => {
			if (!seconds || isNaN(seconds)) return '0:00'
			const mins = Math.floor(seconds / 60)
			const secs = Math.floor(seconds % 60)
			return `${mins}:${secs.toString().padStart(2, '0')}`
		}

		// Watch playing state and emit to parent
		watch(isPlaying, (newVal) => {
			emit('playback-state-changed', newVal)
		})

		// Watch for forced welcome screen display
		watch(() => props.forceShowWelcome, (newVal) => {
			if (newVal) {
				showWelcome.value = true
			}
		})

		// Load score
		const loadScore = async () => {
			try {
				loading.value = true
				console.log('MusicViewer mounted')

				// Wait for the DOM to update and remove loading spinner
				await nextTick()
				
				// Set loading to false first, so the container becomes visible
				loading.value = false
				
				// Wait again for the container to be rendered in the DOM
				await nextTick()
				
				// Add a small delay to ensure the container has proper dimensions
				await new Promise(resolve => setTimeout(resolve, 100))

				if (!osmdContainer.value) {
					console.error('OSMD container not found')
					return
				}
				
				// Verify container has valid dimensions
				const containerWidth = osmdContainer.value.clientWidth
				const containerHeight = osmdContainer.value.clientHeight
				console.log(`Container dimensions: ${containerWidth}x${containerHeight}`)
				
				if (containerWidth === 0) {
					console.error('Container width is 0, cannot render score')
					showError(t('musicxmlviewer', 'Unable to display score: viewer container has no width'))
					return
				}
				
				// Initialize OSMD with proper settings
				const osmdInstance = new OpenSheetMusicDisplay(osmdContainer.value, {
					autoResize: true,
					backend: 'svg',
					drawTitle: true,
					drawComposer: true,
					drawLyricist: true,
					drawCredits: true,
					drawPartNames: true,
					drawFingerings: true,
					drawMeasureNumbers: true,
					measureNumberInterval: 5,
					useXMLMeasureNumbers: true,
					drawingParameters: 'compacttight', // Enable cursor support
				})

				osmd.value = markRaw(osmdInstance)

				const xmlContent = atob(props.fileContent)
				await osmd.value.load(xmlContent)
				await osmd.value.render()

				// Enable and show the cursor
				if (osmd.value.cursor) {
					osmd.value.cursor.show()
					console.log('OSMD cursor enabled and shown')
				}

				// Calculate total measures
				if (osmd.value.Sheet && osmd.value.Sheet.SourceMeasures) {
					totalMeasures.value = osmd.value.Sheet.SourceMeasures.length
					console.log(`Total measures: ${totalMeasures.value}`)
				}

				// Check if welcome screen should be shown
				const welcomeShown = localStorage.getItem('musicxmlviewer_welcome_shown')
				if (welcomeShown === 'true') {
					showWelcome.value = false
				}

				console.log('Score loaded successfully')

				isLoaded.value = true
			} catch (error) {
				console.error('Error loading score:', error)
				showError(t('musicxmlviewer', 'Failed to load the music score'))
				loading.value = false
			}
		}

		// Initialize playback manager
		const initializePlayback = async () => {
			if (!osmd.value || playbackManager.value) {
				return
			}

			try {
				isInitializing.value = true
				console.log('Initializing playback...')

				// 1. Create AudioContext FIRST
				if (!audioContext.value) {
					audioContext.value = new (window.AudioContext || window.webkitAudioContext)()
				}

				if (audioContext.value.state === 'suspended') {
					await audioContext.value.resume()
				}

				// 2. Create master gain node and connect it BEFORE creating player
				const masterGain = audioContext.value.createGain()
				masterGain.connect(audioContext.value.destination)
				masterGain.gain.value = volume.value / 100
				console.log('Master gain node created and connected')

				// 3. Create SoundfontPlayer normally
				const soundfontPlayer = new SoundfontPlayer()
				soundfontPlayer.init(audioContext.value)
				
				// 4. Create PlaybackEngine
				const pbManager = new PlaybackEngine(audioContext.value, soundfontPlayer)
				
				// 5. Load score (this will load instruments internally)
				await pbManager.loadScore(osmd.value)
				pbManager.setBpm(tempo.value)

				playbackManager.value = markRaw(pbManager)
				
				// Store master gain reference for volume control
				playbackManager.value.masterGain = masterGain
				
				// 6. CRITICAL: Now reroute all loaded instruments through master gain
				// Wait a bit to ensure instruments are fully loaded
				await new Promise(resolve => setTimeout(resolve, 500))
				
				console.log('Attempting to reroute instruments through master gain...')
				let reroutedCount = 0
				
				// The soundfontPlayer has a 'players' Map with the actual instrument objects
				if (soundfontPlayer.players && soundfontPlayer.players instanceof Map) {
					console.log('Found players Map with', soundfontPlayer.players.size, 'instruments')
					
					soundfontPlayer.players.forEach((player, instrumentName) => {
						console.log(`Inspecting player "${instrumentName}":`, player)
						
						// The player object should have an 'out' GainNode that we need to reroute
						if (player && player.out) {
							try {
								// Disconnect from default destination
								player.out.disconnect()
								// Connect through master gain
								player.out.connect(masterGain)
								reroutedCount++
								console.log(`✓ Rerouted player "${instrumentName}" through master gain`)
							} catch (e) {
								console.warn(`✗ Could not reroute player "${instrumentName}":`, e)
							}
						} else {
							console.warn(`Player "${instrumentName}" has no 'out' property:`, Object.keys(player || {}))
						}
					})
				} else {
					console.warn('soundfontPlayer.players is not a Map:', soundfontPlayer.players)
				}
				
				console.log(`Rerouting complete: ${reroutedCount} instruments connected to master gain`)
				
				if (reroutedCount === 0) {
					console.error('⚠️ WARNING: No instruments were rerouted! Volume control will not work.')
					console.log('soundfontPlayer structure:', soundfontPlayer)
					console.log('pbManager.player structure:', pbManager.player)
				}

				playbackManager.value.on('state-change', (state) => {
					console.log('Playback state changed:', state)
					if (state === 'PLAYING') {
						isPlaying.value = true
						startProgressTracking()
					} else if (state === 'PAUSED') {
						isPlaying.value = false
						stopProgressTracking()
					} else if (state === 'STOPPED') {
						isPlaying.value = false
						stopProgressTracking()

						// If loop is enabled and playback reached the end, restart
						if (loopEnabled.value && progressPercent.value >= 99) {
							console.log('Loop enabled: restarting playback')
							setTimeout(async () => {
								currentTime.value = 0
								progressPercent.value = 0
								currentMeasure.value = 0
								playbackStartTime.value = 0
								playbackStartOffset.value = 0

								// Reset cursor to beginning
								if (osmd.value && osmd.value.cursor) {
									osmd.value.cursor.reset()
									osmd.value.cursor.show()
								}

								await play()
							}, 200)
						}
					}
				})
				playbackManager.value.on('iteration', () => {
					updateProgress()
					
					// Track current measure from cursor position
					if (osmd.value && osmd.value.cursor && isPlaying.value) {
						try {
							const iterator = osmd.value.cursor.iterator
							
							// Update current measure based on cursor position
							const currentVoiceEntry = iterator.currentVoiceEntries
							if (currentVoiceEntry && currentVoiceEntry[0]) {
								const measureNum = currentVoiceEntry[0].parentSourceStaffEntry?.verticalContainerParent?.parentMeasure?.measureNumber
								if (measureNum !== undefined) {
									// OSMD measure numbers are 1-based, convert to 0-based
									currentMeasure.value = measureNum - 1
								}
							}
							
							// Check if cursor has reached the end of the score
							if (iterator.endReached) {
								console.log('Playback completed - cursor reached end of score')
								
								// Properly stop playback (not pause)
								if (playbackManager.value) {
									playbackManager.value.stop()
								}
								isPlaying.value = false
								stopProgressTracking()
								
								// If loop is enabled, restart
								if (loopEnabled.value) {
									console.log('Loop enabled: restarting playback')
									setTimeout(async () => {
										// Reset all values
										currentTime.value = 0
										progressPercent.value = 0
										currentMeasure.value = 0
										playbackStartTime.value = 0
										playbackStartOffset.value = 0
										
										// Reset cursor to beginning
										if (osmd.value && osmd.value.cursor) {
											osmd.value.cursor.reset()
											osmd.value.cursor.show()
										}
										
										// Start playback again
										await play()
									}, 200)
								} else {
									// Reset to beginning for next play
									console.log('Resetting to beginning for next play')
									
									// Reset all values
									currentTime.value = 0
									progressPercent.value = 0
									currentMeasure.value = 0
									playbackStartTime.value = 0
									playbackStartOffset.value = 0
									
									// Reset cursor to beginning
									if (osmd.value && osmd.value.cursor) {
										osmd.value.cursor.reset()
										osmd.value.cursor.show()
									}
								}
							}
						} catch (error) {
							// Cursor position update failed (non-critical)
							console.debug('Cursor position update error:', error)
						}
					}
				})

				console.log('Playback initialized successfully')
				isInitializing.value = false

				// Set initial volume
				updateVolume()

				// Estimate total duration
				estimateDuration()
			} catch (error) {
				console.error('Error initializing playback:', error)
				showError(t('musicxmlviewer', 'Failed to initialize audio playback'))
				isInitializing.value = false
			}
		}

		// Progress tracking
		const startProgressTracking = () => {
			if (progressInterval.value) {
				clearInterval(progressInterval.value)
			}
			progressInterval.value = setInterval(() => {
				updateProgress()
			}, 100)
		}

		const stopProgressTracking = () => {
			if (progressInterval.value) {
				clearInterval(progressInterval.value)
				progressInterval.value = null
			}
		}

		const updateProgress = () => {
			// PRECISE progress tracking using AudioContext time
			if (playbackManager.value && audioContext.value) {
				const state = playbackManager.value.state
				if (state === 'PLAYING') {
					// Calculate elapsed time using AudioContext currentTime (most accurate)
					const elapsedTime = audioContext.value.currentTime - playbackStartTime.value + playbackStartOffset.value
					currentTime.value = elapsedTime
					
					if (totalDuration.value > 0) {
						progressPercent.value = Math.min((currentTime.value / totalDuration.value) * 100, 100)
					}
				}
			}
		}

		const estimateDuration = () => {
			// Rough estimate based on tempo and number of measures
			if (osmd.value && osmd.value.Sheet) {
				const measures = osmd.value.Sheet.SourceMeasures.length
				const beatsPerMeasure = 4 // assumption
				const secondsPerBeat = 60 / tempo.value
				totalDuration.value = measures * beatsPerMeasure * secondsPerBeat
			}
		}

		// Play
		const play = async () => {
			if (!osmd.value) return

			if (!playbackManager.value) {
				await initializePlayback()
			}

			if (!playbackManager.value) {
				showError(t('musicxmlviewer', 'Playback not available'))
				return
			}

			try {
				// CRITICAL: Ensure playback manager is fully stopped before starting
				// This prevents double playback issues
				const state = playbackManager.value.state
				if (state === 'PLAYING' || state === 'PAUSED') {
					console.log('Stopping previous playback before starting new one')
					playbackManager.value.stop()
					// Small delay to ensure stop is processed
					await new Promise(resolve => setTimeout(resolve, 50))
				}

				if (audioContext.value && audioContext.value.state === 'suspended') {
					await audioContext.value.resume()
				}

				// If starting from the beginning, ensure cursor is reset
				if (currentTime.value === 0 && currentMeasure.value === 0) {
					if (osmd.value && osmd.value.cursor) {
						osmd.value.cursor.reset()
						osmd.value.cursor.show()
					}
					// Also ensure playback manager starts from beginning
					if (playbackManager.value.jumpToStep) {
						playbackManager.value.jumpToStep(0)
					}
					currentTimestep.value = 0
					console.log('Starting playback from the beginning')
				} else {
					// CRITICAL: If not starting from beginning, RE-APPLY the timestep
					// This ensures playback starts from the correct position even after stop()
					console.log(`Play called with measure=${currentMeasure.value}, timestep=${currentTimestep.value}, time=${currentTime.value}`)

					// CRITICAL: jumpToStep moves the internal cursor, so we need to restore visual cursor position
					if (playbackManager.value && playbackManager.value.jumpToStep) {
						console.log(`Applying timestep ${currentTimestep.value} for playback`)
						playbackManager.value.jumpToStep(currentTimestep.value)

						// Restore cursor to correct visual position after jumpToStep
						await moveCursorToMeasure(currentMeasure.value)
					}

					// CRITICAL: Ensure cursor is visible
					if (osmd.value && osmd.value.cursor) {
						osmd.value.cursor.show()
					}
				}

				// Save the AudioContext time when playback starts for precise timing
				playbackStartTime.value = audioContext.value.currentTime
				// If resuming from pause, keep the current time as offset
				playbackStartOffset.value = currentTime.value

				console.log(`▶️ Starting playback from measure ${currentMeasure.value} at time ${currentTime.value.toFixed(2)}s`)
				playbackManager.value.play()
				isPlaying.value = true
			} catch (error) {
				console.error('Error starting playback:', error)
				showError(t('musicxmlviewer', 'Failed to start playback'))
			}
		}

		// Pause
		const pause = () => {
			if (!playbackManager.value) return
			
			try {
				playbackManager.value.pause()
				isPlaying.value = false
			} catch (error) {
				console.error('Error pausing playback:', error)
			}
		}

		// Toggle playback (play/pause) - used for keyboard shortcut
		const togglePlayback = async () => {
			if (isPlaying.value) {
				pause()
			} else {
				await play()
			}
		}

		// Stop playback
		const stop = () => {
			if (!playbackManager.value) return

			try {
				playbackManager.value.stop()
				isPlaying.value = false
				currentTime.value = 0
				progressPercent.value = 0
				playbackStartTime.value = 0
				playbackStartOffset.value = 0

				// Reset to beginning
				currentMeasure.value = 0
				currentTimestep.value = 0
				
				// Reset visual cursor to beginning
				if (osmd.value && osmd.value.cursor) {
					osmd.value.cursor.reset()
					osmd.value.cursor.show()
				}
				
				console.log('Playback stopped and reset to measure 0')
			} catch (error) {
				console.error('Error stopping playback:', error)
			}
		}

		// Toggle loop
		const toggleLoop = () => {
			loopEnabled.value = !loopEnabled.value
			console.log('Loop', loopEnabled.value ? 'enabled' : 'disabled')
		}

		// Close welcome screen
		const closeWelcome = () => {
			showWelcome.value = false
			// Store preference in localStorage
			localStorage.setItem('musicxmlviewer_welcome_shown', 'true')
			// Emit event to parent
			emit('welcome-closed')
		}

		// Move visual cursor to specific measure and return the timestep count
		const moveCursorToMeasure = async (targetMeasure) => {
			if (!osmd.value || !osmd.value.cursor) {
				console.warn('Cannot move cursor: OSMD or cursor not initialized')
				return 0
			}

			try {
				// Reset cursor to beginning
				osmd.value.cursor.reset()

				// If target is measure 0, we're already there after reset
				if (targetMeasure === 0) {
					osmd.value.cursor.show()
					console.log(`✓ Cursor at measure 0 (no steps needed)`)
					return 0
				}

				// OSMD cursor moves through timesteps (notes/chords), not measures
				// We need to find the first note of the target measure and move there
				const iterator = osmd.value.cursor.iterator

				// Skip to target measure by checking the measure number of current note
				let steps = 0
				const maxSteps = 10000 // Safety limit to prevent infinite loops

				while (!iterator.endReached && steps < maxSteps) {
					// CRITICAL: Check BEFORE moving the cursor
					const currentVoiceEntry = iterator.currentVoiceEntries
					if (currentVoiceEntry && currentVoiceEntry[0]) {
						const currentMeasureNumber = currentVoiceEntry[0].parentSourceStaffEntry?.verticalContainerParent?.parentMeasure?.measureNumber

						if (currentMeasureNumber !== undefined) {
							// OSMD measure numbers are 1-based, our targetMeasure is 0-based
							const currentMeasure0Based = currentMeasureNumber - 1

							if (currentMeasure0Based === targetMeasure) {
								// We've reached the exact target measure, stop here
								console.log(`✓ Cursor moved to measure ${targetMeasure} (after ${steps} steps, OSMD measure ${currentMeasureNumber})`)
								break
							}
						}
					}

					// Move to next timestep
					osmd.value.cursor.next()
					steps++
				}

				// CRITICAL: Always show cursor after moving
				osmd.value.cursor.show()

				// Return the timestep count for playback synchronization
				return steps

			} catch (error) {
				console.error('Error moving cursor:', error)
				// Always try to show cursor even if there's an error
				if (osmd.value && osmd.value.cursor) {
					osmd.value.cursor.show()
				}
				return 0
			}
		}


		// Navigate to specific measure
		const navigateToMeasure = async (measureIndex) => {
			if (!osmd.value) {
				console.warn('Cannot navigate: OSMD not initialized')
				return
			}

			try {
				// CRITICAL: Always stop playback (whether playing or paused) to reset internal state
				if (playbackManager.value) {
					const wasPlaying = isPlaying.value
					playbackManager.value.stop()
					isPlaying.value = false
					if (wasPlaying) {
						console.log('Stopped playback for navigation')
					} else {
						console.log('Reset paused playback for navigation')
					}
				}

				// Jump to measure WITHOUT auto-starting playback
				const oldMeasure = currentMeasure.value
				currentMeasure.value = Math.max(0, Math.min(measureIndex, totalMeasures.value - 1))
				console.log(`NavigateToMeasure: ${oldMeasure} → ${currentMeasure.value} (requested: ${measureIndex})`)

				// Move the visual cursor to the selected measure and get the timestep
				const timestep = await moveCursorToMeasure(currentMeasure.value)

				// Initialize playback manager if not already done
				if (!playbackManager.value) {
					await initializePlayback()
				}

				// CRITICAL: Save the timestep for playback synchronization
				// We will apply this timestep only when play() is called
				currentTimestep.value = timestep
				console.log(`Saved timestep: ${timestep} for measure ${currentMeasure.value}`)

				// CRITICAL: Calculate estimated time at current measure for progress bar
				// This ensures progress bar reflects the selected measure position
				const beatsPerMeasure = 4 // assumption
				const secondsPerBeat = 60 / tempo.value
				const estimatedTime = currentMeasure.value * beatsPerMeasure * secondsPerBeat

				currentTime.value = estimatedTime
				playbackStartOffset.value = estimatedTime
				playbackStartTime.value = 0

				// Update progress bar to reflect current position
				if (totalDuration.value > 0) {
					progressPercent.value = Math.min((currentTime.value / totalDuration.value) * 100, 100)
				}

				console.log(`✓ Navigation complete: measure ${currentMeasure.value}, timestep ${timestep}, estimated time ${estimatedTime.toFixed(2)}s`)
			} catch (error) {
				console.error('Error navigating to measure:', error)
			}
		}

		// Navigate to next measure
		const nextMeasure = async () => {
			console.log(`Next measure requested. Current: ${currentMeasure.value}, navigating to: ${currentMeasure.value + 1}`)
			await navigateToMeasure(currentMeasure.value + 1)
		}

		// Navigate to previous measure
		const prevMeasure = async () => {
			console.log(`Previous measure requested. Current: ${currentMeasure.value}, navigating to: ${currentMeasure.value - 1}`)
			await navigateToMeasure(currentMeasure.value - 1)
		}

		// Update tempo
		const updateTempo = () => {
			if (playbackManager.value) {
				try {
					playbackManager.value.setBpm(tempo.value)
					estimateDuration()
				} catch (error) {
					console.error('Error updating tempo:', error)
				}
			}
		}

		// Update volume
		const updateVolume = () => {
			try {
				// Calculate normalized volume (0-1)
				const normalizedVolume = volume.value / 100
				
				if (!playbackManager.value || !playbackManager.value.masterGain) {
					// If playback not initialized yet, volume will be set during initialization
					console.log('Volume will be set when playback is initialized:', volume.value + '%')
					return
				}
				
				// CRITICAL: Use .gain.value not .gain
				// Use smooth transition to avoid audio clicks
				const gainNode = playbackManager.value.masterGain
				const currentTime = audioContext.value.currentTime
				
				// Cancel any scheduled changes
				gainNode.gain.cancelScheduledValues(currentTime)
				
				// Set current value and ramp to new value smoothly (50ms transition)
				gainNode.gain.setValueAtTime(gainNode.gain.value, currentTime)
				gainNode.gain.linearRampToValueAtTime(normalizedVolume, currentTime + 0.05)
				
				console.log(`Volume smoothly ramping to ${volume.value}% (${normalizedVolume})`)
			} catch (error) {
				console.error('Error updating volume:', error)
			}
		}

		// Zoom in
		const zoomIn = () => {
			if (!osmd.value) return

			try {
				zoomLevel.value += 0.1
				osmd.value.zoom = zoomLevel.value

				// If playback is active, don't render to avoid disrupting cursor iteration
				// The zoom will be applied on next render cycle
				if (!isPlaying.value) {
					osmd.value.render()
					// Re-show cursor after zoom
					if (osmd.value.cursor) {
						osmd.value.cursor.show()
					}
				}
			} catch (error) {
				console.error('Error zooming in:', error)
			}
		}

		// Zoom out
		const zoomOut = () => {
			if (!osmd.value) return

			try {
				zoomLevel.value = Math.max(0.5, zoomLevel.value - 0.1)
				osmd.value.zoom = zoomLevel.value

				// If playback is active, don't render to avoid disrupting cursor iteration
				// The zoom will be applied on next render cycle
				if (!isPlaying.value) {
					osmd.value.render()
					// Re-show cursor after zoom
					if (osmd.value.cursor) {
						osmd.value.cursor.show()
					}
				}
			} catch (error) {
				console.error('Error zooming out:', error)
			}
		}

		// Share score
		const shareScore = async () => {
			try {
				// Check if we have a fileId
				if (!props.fileId) {
					showError(t('musicxmlviewer', 'Cannot share: file not found'))
					return
				}

				// Call API to create public share
				const response = await axios.post(generateUrl('/apps/mxlmscores/api/share/{fileId}', { fileId: props.fileId }))

				if (response.data && response.data.url) {
					const shareUrl = response.data.url

					// Copy to clipboard
					await navigator.clipboard.writeText(shareUrl)

					// Show success message with the URL
					showSuccess(t('musicxmlviewer', 'Public link copied to clipboard!') + '\n' + shareUrl)
					console.log('Share URL created:', shareUrl)
				} else {
					showError(t('musicxmlviewer', 'Failed to create share link'))
				}

			} catch (error) {
				console.error('Error sharing score:', error)
				if (error.response && error.response.data && error.response.data.error) {
					showError(t('musicxmlviewer', 'Failed to share: ') + error.response.data.error)
				} else {
					showError(t('musicxmlviewer', 'Failed to share score'))
				}
			}
		}

		// Keyboard shortcuts
		const handleKeyboard = (e) => {
			// Skip if typing in input fields
			if (e.target.matches('input, textarea')) return
			
			// Space: Play/Pause
			if (e.code === 'Space') {
				e.preventDefault()
				togglePlayback()
			}
			// Plus/Minus: Zoom
			if (e.key === '+' || e.key === '=') {
				e.preventDefault()
				zoomIn()
			}
			if (e.key === '-' || e.key === '_') {
				e.preventDefault()
				zoomOut()
			}
			// Left/Right Arrows: Navigate measures
			if (e.key === 'ArrowLeft') {
				e.preventDefault()
				prevMeasure()
			}
			if (e.key === 'ArrowRight') {
				e.preventDefault()
				nextMeasure()
			}
		}

		// Cleanup
		const cleanup = () => {
			console.log('Cleaning up MusicViewer...')
			stopProgressTracking()
			if (playbackManager.value) {
				try {
					playbackManager.value.stop()
				} catch (e) {
					// Ignore errors during cleanup
				}
			}
			if (audioContext.value) {
				audioContext.value.close()
			}
		}

		// Lifecycle hooks
		onMounted(async () => {
			await loadScore()
			window.addEventListener('keydown', handleKeyboard)
		})

		onBeforeUnmount(() => {
			console.log('MusicViewer unmounting')
			cleanup()
			window.removeEventListener('keydown', handleKeyboard)
		})

		return {
			osmdContainer,
			loading,
			isLoaded,
			isPlaying,
			isInitializing,
			tempo,
			volume,
			zoomLevel,
			currentTime,
			totalDuration,
			progressPercent,
			loopEnabled,
			showWelcome,
			currentMeasure,
			totalMeasures,
			// Translation strings
			welcomeTitle,
			quickTipsTitle,
			keyboardShortcutsTitle,
			playPauseText,
			navigateMeasuresText,
			zoomText,
			playbackControlsTitle,
			playbackControlsDesc,
			zoomTitle,
			zoomDesc,
			loopModeTitle,
			loopModeDesc,
			gotItText,
			// Functions
			play,
			pause,
			togglePlayback,
			stop,
			toggleLoop,
			closeWelcome,
			nextMeasure,
			prevMeasure,
			updateTempo,
			updateVolume,
			zoomIn,
			zoomOut,
			shareScore,
			formatTime,
		}
	},
}
</script>

<style scoped>
.music-viewer {
	display: flex;
	flex-direction: column;
	height: 100vh;
	min-height: 100vh;
	background-color: var(--color-main-background);
	overflow: hidden;
}

/* Compact playback controls */
.playback-controls {
	position: sticky;
	top: 0;
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 16px;
	padding: 12px 20px;
	background-color: rgba(var(--color-main-background-rgb), 0.98);
	backdrop-filter: blur(10px);
	-webkit-backdrop-filter: blur(10px);
	border-bottom: 1px solid var(--color-border);
	flex-wrap: nowrap;
	z-index: 100;
	box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
	min-height: calc(44px + 24px); /* 44px per il contenuto + 24px totale di padding (12px top + 12px bottom) */
	box-sizing: border-box;
}

.control-group {
	display: flex;
	gap: 8px;
}

.loop-active {
	background-color: var(--color-primary-element) !important;
	color: var(--color-primary-element-text) !important;
}

.loop-active:hover {
	background-color: var(--color-primary-element-hover) !important;
}

/* Progress section */
.progress-section {
	width: auto;
	min-width: 200px;
	max-width: 200px;
	display: flex;
	flex-direction: column;
	gap: 4px;
}

.progress-bar {
	height: 6px;
	background-color: var(--color-background-dark);
	border-radius: 3px;
	overflow: hidden;
	cursor: pointer;
}

.progress-fill {
	height: 100%;
	background: var(--color-primary-element);
	transition: width 0.1s ease;
	border-radius: 3px;
}

.time-display {
	display: flex;
	gap: 4px;
	font-size: 12px;
	color: var(--color-text-maxcontrast);
	justify-content: center;
}

.separator {
	opacity: 0.5;
}

.measure-separator {
	opacity: 0.5;
	margin: 0 4px;
}

.measure-display {
	font-weight: 500;
	color: var(--color-primary-element);
}

/* Tempo control */
.tempo-control {
	display: flex;
	align-items: center;
	gap: 8px;
	min-width: 200px;
	max-width: 200px;
}


.tempo-input,
.volume-input {
	width: 55px;
	padding: 4px 8px;
	border: 1px solid var(--color-border);
	border-radius: 3px;
	background-color: var(--color-main-background);
	color: var(--color-main-text);
	font-size: 13px;
	text-align: center;
}

.tempo-input:focus,
.volume-input:focus {
	outline: none;
	border-color: var(--color-primary-element);
}

.unit-label {
	font-size: 12px;
	color: var(--color-text-maxcontrast);
	font-weight: 500;
}

.tempo-slider {
	width: 100px;
}

/* Volume control */
.volume-control {
	display: flex;
	align-items: center;
	gap: 8px;
	min-width: 200px;
	max-width: 200px;
}


.volume-slider {
	width: 100px;
}

/* Zoom controls - same width as control-group */
.zoom-controls {
	display: flex;
	align-items: center;
	gap: 8px;
	flex: 0 0 auto;
}

/* Share control */
.share-control {
	display: flex;
	align-items: center;
}

.zoom-level {
	font-size: 13px;
	font-weight: 500;
	color: var(--color-main-text);
	min-width: 45px;
	text-align: center;
}

/* Remove padding from NcButton components */
.playback-controls :deep(.button-vue) {
	padding-left: 0 !important;
	padding-right: 0 !important;
}

/* Slider styles */
input[type="range"] {
	-webkit-appearance: none;
	appearance: none;
	height: 6px;
	background: var(--color-background-dark);
	border-radius: 3px;
	outline: none;
	transition: background 0.2s;
}

input[type="range"]:hover {
	background: var(--color-background-hover);
}

input[type="range"]::-webkit-slider-thumb {
	-webkit-appearance: none;
	appearance: none;
	width: 16px;
	height: 16px;
	background: var(--color-primary-element);
	border-radius: 50%;
	cursor: pointer;
	transition: transform 0.2s;
}

input[type="range"]::-webkit-slider-thumb:hover {
	transform: scale(1.2);
}

input[type="range"]::-moz-range-thumb {
	width: 16px;
	height: 16px;
	background: var(--color-primary-element);
	border: none;
	border-radius: 50%;
	cursor: pointer;
	transition: transform 0.2s;
}

input[type="range"]::-moz-range-thumb:hover {
	transform: scale(1.2);
}

input[type="range"]:disabled {
	opacity: 0.5;
	cursor: not-allowed;
}

/* Welcome Screen */
.welcome-screen {
	position: fixed;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	background-color: rgba(0, 0, 0, 0.8);
	display: flex;
	align-items: center;
	justify-content: center;
	z-index: 10000;
	padding: 20px;
}

.welcome-content {
	background-color: var(--color-main-background);
	border-radius: 8px;
	padding: 32px;
	max-width: 600px;
	max-height: 90vh;
	overflow-y: auto;
	box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
}

.welcome-content h2 {
	margin-top: 0;
	margin-bottom: 24px;
	color: var(--color-main-text);
	font-size: 24px;
	font-weight: 600;
}

.welcome-content h3 {
	margin-top: 0;
	margin-bottom: 16px;
	color: var(--color-main-text);
	font-size: 18px;
	font-weight: 500;
}

.quick-tips {
	margin-bottom: 24px;
}

.tip-item {
	display: flex;
	gap: 16px;
	margin-bottom: 20px;
	align-items: flex-start;
}

.tip-icon {
	font-size: 24px;
	flex-shrink: 0;
}

.tip-text {
	flex: 1;
}

.tip-text strong {
	display: block;
	margin-bottom: 8px;
	color: var(--color-main-text);
}

.tip-text p {
	margin: 0;
	color: var(--color-text-maxcontrast);
	line-height: 1.5;
}

.tip-text ul {
	margin: 8px 0 0 0;
	padding-left: 0;
	list-style: none;
}

.tip-text li {
	color: var(--color-text-maxcontrast);
	line-height: 1.8;
	display: flex;
	align-items: center;
	gap: 8px;
}

.tip-text kbd {
	display: inline-block;
	padding: 2px 8px;
	background-color: var(--color-background-dark);
	border: 1px solid var(--color-border);
	border-radius: 3px;
	font-family: monospace;
	font-size: 12px;
	color: var(--color-main-text);
	box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
}

/* Sheet viewer */
.sheet-viewer {
	flex: 1;
	overflow: auto;
	padding: 20px;
	background-color: #f5f5f5;
	min-height: 0;
}

.osmd-container {
	width: 100%;
	min-height: 800px;
	background-color: #ffffff;
	border-radius: 3px;
	padding: 0;
}

/* White background for the actual score SVG with subtle border */
.osmd-container svg {
	background-color: #ffffff !important;
	border-radius: 6px;
	padding: 0;
	box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
	border: 1px solid rgba(0, 0, 0, 0.1);
	cursor: pointer;
	transition: box-shadow 0.2s ease;
}

.osmd-container svg:hover {
	box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.loading-spinner {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	height: 400px;
	gap: 16px;
}

.loading-spinner p {
	color: var(--color-text-maxcontrast);
	font-size: 14px;
}

/* Responsive design */
@media (max-width: 1024px) {
	.playback-controls {
		gap: 12px;
		padding: 10px 16px;
	}

	.tempo-slider,
	.volume-slider {
		width: 80px;
	}
}

@media (max-width: 768px) {
	.playback-controls {
		flex-direction: column;
		align-items: stretch;
		gap: 12px;
	}

	.control-group,
	.progress-section,
	.tempo-control,
	.volume-control,
	.zoom-controls {
		width: 100%;
		justify-content: space-between;
	}

	.tempo-slider,
	.volume-slider {
		flex: 1;
	}
}
</style>
