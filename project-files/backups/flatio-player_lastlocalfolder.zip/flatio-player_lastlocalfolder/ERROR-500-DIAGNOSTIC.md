# 🚨 SOLUZIONE ERRORE 500: "Could not download app flatioplayer"

## 🔍 **DIAGNOSI**

L'errore `500 Internal Server Error` durante l'enable dell'app indica un **errore PHP fatale**. 

Basandomi sui log della console:
- `POST /index.php/settings/apps/enable 500`
- `APPS_API_FAILURE`

Le cause più probabili sono:
1. **Sintassi PHP** o **namespace** errato
2. **Permissions** file insufficienti
3. **Dipendenze PHP** mancanti (ext-posix, ext-xml)
4. **Errore nell'AppEnableListener**

---

## ⚡ **SOLUZIONI DA ESEGUIRE SUL SERVER**

### **Soluzione 1: Controlla Log PHP di Nextcloud**

```bash
# Accedi al server
ssh ottoniascoppio@cloud.ottoniascoppio.org

# Vai alla directory Nextcloud
cd /home/nicolog/public_html

# Controlla gli ultimi errori nel log
tail -50 data/nextcloud.log | grep -A 5 -B 5 flatioplayer

# Oppure cerca errori PHP generali
tail -100 data/nextcloud.log | grep -i "error\|fatal\|exception"
```

**Questo ti dirà esattamente quale file PHP sta causando l'errore 500.**

### **Soluzione 2: Verifica Struttura e Permissions**

```bash
# Verifica che la directory si chiami esattamente "flatioplayer"
ls -la /home/nicolog/public_html/apps/ | grep flatio

# Deve essere:
# drwxr-xr-x nicolog nicolog flatioplayer/

# Se ha nome diverso, rinomina
cd /home/nicolog/public_html/apps/
sudo mv flatio-player flatioplayer
# oppure
sudo mv musicxml-player flatioplayer

# Verifica permissions
ls -la flatioplayer/
ls -la flatioplayer/lib/
ls -la flatioplayer/appinfo/

# Fix permissions se necessari
sudo chown -R nicolog:nicolog flatioplayer/
sudo chmod -R 755 flatioplayer/
sudo find flatioplayer/ -type f -name "*.php" -exec chmod 644 {} \;
```

### **Soluzione 3: Verifica Dipendenze PHP**

```bash
# Controlla versione PHP
php -v
# Deve essere >= 8.1

# Verifica estensioni richieste
php -m | grep -E '(posix|xml|simplexml|json)'

# Se mancano, installa:
# Per Debian/Ubuntu
sudo apt-get install php-xml php-posix

# Per CentOS/RHEL  
sudo yum install php-xml php-posix

# Riavvia webserver
sudo systemctl restart apache2
# oppure
sudo systemctl restart nginx
```

### **Soluzione 4: Test Manuale Via OCC**

```bash
# Prova ad abilitare via command line per vedere l'errore esatto
cd /home/nicolog/public_html
sudo -u nicolog php occ app:enable flatioplayer

# Questo mostrerà l'errore PHP esatto
```

### **Soluzione 5: Controlla Autoload e Namespace**

```bash
# Verifica che composer autoload sia generato
ls -la /home/nicolog/public_html/apps/flatioplayer/vendor/

# Se manca, genera:
cd /home/nicolog/public_html/apps/flatioplayer/
composer dump-autoload

# Verifica che i namespace siano corretti
grep -r "namespace OCA" lib/ | head -10
# Tutti devono essere: namespace OCA\FlatioPlayer
```

---

## 🔧 **ERRORI COMUNI E FIX**

### **Errore 1: Class AppEnableListener Not Found**

```bash
# Verifica che il file esista
ls -la /home/nicolog/public_html/apps/flatioplayer/lib/Listener/AppEnableListener.php

# Se manca, il file potrebbe non essere stato estratto correttamente
# Reinstalla l'app completamente
```

### **Errore 2: Cannot Use OCP Classes**

Se il log mostra errori tipo "Class 'OCP\AppFramework\...' not found":

```bash
# Nextcloud potrebbe non avere le API necessarie
# Verifica versione Nextcloud
sudo -u nicolog php occ status

# L'app richiede Nextcloud 31+
# Se versione < 31, aggiorna Nextcloud
```

### **Errore 3: Permission Denied**

```bash
# Se il log mostra "Permission denied" su qualche file:

# Fix permissions complete
cd /home/nicolog/public_html/apps/flatioplayer
sudo chown -R nicolog:nicolog .
sudo chmod 755 .
sudo find . -type d -exec chmod 755 {} \;
sudo find . -type f -exec chmod 644 {} \;
```

### **Errore 4: Syntax Error in PHP File**

Se c'è un errore di sintassi PHP (improbabile ma possibile):

```bash
# Test sintassi di tutti i file PHP
cd /home/nicolog/public_html/apps/flatioplayer
find . -name "*.php" -exec php -l {} \; | grep -v "No syntax errors"

# Se trova errori, li mostrerà
```

---

## 📋 **CHECKLIST DIAGNOSTICA COMPLETA**

Esegui questi comandi IN ORDINE e inviami l'output:

```bash
# 1. Controlla directory app
ls -la /home/nicolog/public_html/apps/ | grep flatio

# 2. Controlla ID app nel file info.xml
cat /home/nicolog/public_html/apps/flatioplayer/appinfo/info.xml | grep "<id>"

# 3. Controlla log Nextcloud (ultimi 20 errori)
tail -20 /home/nicolog/public_html/data/nextcloud.log

# 4. Tenta enable via OCC (mostrerà errore esatto)
cd /home/nicolog/public_html
sudo -u nicolog php occ app:enable flatioplayer

# 5. Verifica versione PHP e estensioni
php -v
php -m | grep -E '(posix|xml|simplexml|json|dom)'

# 6. Verifica permissions file critici
ls -la /home/nicolog/public_html/apps/flatioplayer/lib/AppInfo/Application.php
ls -la /home/nicolog/public_html/apps/flatioplayer/lib/Listener/AppEnableListener.php
```

---

## 🎯 **FIX RAPIDO SE NON PUOI ACCEDERE AL SERVER**

Se non puoi accedere via SSH, tramite il pannello hosting:

1. **File Manager del Hosting**:
   - Vai in `/home/nicolog/public_html/apps/`
   - Rinomina directory in esattamente `flatioplayer`
   - Verifica permissions: 755 per directory, 644 per file PHP

2. **PHP Version nel Pannello**:
   - Assicurati che PHP sia >= 8.1
   - Abilita estensioni: posix, xml, simplexml, json

3. **Log Viewer del Pannello**:
   - Cerca "error log" o "PHP errors"
   - Guarda gli ultimi errori quando provi enable

4. **Ricarica Nextcloud**:
   - Vai in Maintenance Mode
   - Esci da Maintenance Mode
   - Riprova enable

---

## 📞 **PROSSIMI PASSI**

1. **Esegui i comandi della checklist** e inviami gli output
2. Specialmente importante:
   - `tail -20 /home/nicolog/public_html/data/nextcloud.log`
   - `sudo -u nicolog php occ app:enable flatioplayer`

Con questi output potrò identificare **esattamente** cosa causa l'errore 500 e darti il fix preciso!

---

## 💡 **WORKAROUND TEMPORANEO**

Se vuoi testare l'app velocemente senza risolvere l'auto-installation:

```bash
# Disabilita temporaneamente l'AppEnableListener
cd /home/nicolog/public_html/apps/flatioplayer/lib/AppInfo/
sudo nano Application.php

# Commenta la riga 43 (registrazione listener):
# // $context->registerEventListener(\OCP\App\Events\AppEnableEvent::class, \OCA\FlatioPlayer\Listener\AppEnableListener::class);

# Salva e riprova enable
```

Questo disabiliterà l'auto-installation ma permetterà all'app di attivarsi.
