<?php
/**
 * Routes configuration for Flat.io Player
 * Optimized for Nextcloud 31.0.7 compatibility with auto-installation
 */

return [
    'routes' => [
        // Main pages
        ['name' => 'page#index', 'url' => '/', 'verb' => 'GET'],
        
        // API endpoints
        ['name' => 'api#listFiles', 'url' => '/api/files', 'verb' => 'GET'],
        ['name' => 'api#getFile', 'url' => '/api/file/{fileId}', 'verb' => 'GET'],
        ['name' => 'api#validateFile', 'url' => '/api/validate/{fileId}', 'verb' => 'GET'],
        
        // Installation endpoints (admin only)
        ['name' => 'install#status', 'url' => '/api/install/status', 'verb' => 'GET'],
        ['name' => 'install#install', 'url' => '/api/install/run', 'verb' => 'POST'],
        ['name' => 'install#diagnostics', 'url' => '/api/install/diagnostics', 'verb' => 'GET'],
        
        // Settings endpoints
        ['name' => 'settings#getPersonal', 'url' => '/api/settings/personal', 'verb' => 'GET'],
        ['name' => 'settings#setPersonal', 'url' => '/api/settings/personal', 'verb' => 'POST'],
    ]
];
