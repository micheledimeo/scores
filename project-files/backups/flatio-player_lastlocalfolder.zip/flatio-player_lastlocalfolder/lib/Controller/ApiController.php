<?php

declare(strict_types=1);

namespace OCA\FlatioPlayer\Controller;

use OCP\IRequest;
use OCP\AppFramework\Http\DataResponse;
use OCP\AppFramework\Http\JSONResponse;
use OCP\AppFramework\Controller;
use OCP\Files\IRootFolder;
use OCP\IUserSession;
use OCP\AppFramework\Http\Attribute\NoAdminRequired;
use Psr\Log\LoggerInterface;

/**
 * API Controller for Flat.io Player
 * 
 * Handles file system operations with optimized caching
 * and validation for MusicXML files.
 */
class ApiController extends Controller {
    
    private IRootFolder $rootFolder;
    private IUserSession $userSession;
    private LoggerInterface $logger;
    private array $cache = [];

    public function __construct(
        string $appName,
        IRequest $request,
        IRootFolder $rootFolder,
        IUserSession $userSession,
        LoggerInterface $logger
    ) {
        parent::__construct($appName, $request);
        $this->rootFolder = $rootFolder;
        $this->userSession = $userSession;
        $this->logger = $logger;
    }

    /**
     * List all MusicXML files with caching
     */
    #[NoAdminRequired]
    public function listFiles(): DataResponse {
        try {
            $user = $this->userSession->getUser();
            if (!$user) {
                return new DataResponse(['error' => 'User not authenticated'], 401);
            }

            $cacheKey = 'musicxml_files_' . $user->getUID();
            
            // Check cache first (5 minute TTL)
            if (isset($this->cache[$cacheKey]) && 
                (time() - $this->cache[$cacheKey]['timestamp']) < 300) {
                return new DataResponse($this->cache[$cacheKey]['data']);
            }

            $userFolder = $this->rootFolder->getUserFolder($user->getUID());
            $files = $this->scanForMusicXMLFiles($userFolder);

            // Cache results
            $result = ['files' => $files, 'count' => count($files)];
            $this->cache[$cacheKey] = [
                'data' => $result,
                'timestamp' => time()
            ];

            return new DataResponse($result);

        } catch (\Exception $e) {
            $this->logger->error('Failed to list MusicXML files: ' . $e->getMessage(), [
                'app' => 'flatioplayer'
            ]);
            return new DataResponse(['error' => 'Failed to scan files'], 500);
        }
    }

    /**
     * Get specific file content with validation
     */
    #[NoAdminRequired] 
    public function getFile(int $fileId): DataResponse {
        try {
            $user = $this->userSession->getUser();
            if (!$user) {
                return new DataResponse(['error' => 'User not authenticated'], 401);
            }

            $userFolder = $this->rootFolder->getUserFolder($user->getUID());
            $files = $userFolder->getById($fileId);

            if (empty($files)) {
                return new DataResponse(['error' => 'File not found'], 404);
            }

            $file = $files[0];

            // Validate file size (max 50MB for shared server)
            if ($file->getSize() > 50 * 1024 * 1024) {
                return new DataResponse(['error' => 'File too large'], 413);
            }

            if (!$this->isMusicXMLFile($file)) {
                return new DataResponse(['error' => 'Invalid MusicXML file'], 400);
            }

            $content = $file->getContent();
            
            return new DataResponse([
                'content' => $content,
                'name' => $file->getName(),
                'path' => $file->getPath(),
                'size' => $file->getSize(),
                'mtime' => $file->getMTime()
            ]);

        } catch (\Exception $e) {
            $this->logger->error('Failed to get file content: ' . $e->getMessage(), [
                'app' => 'flatioplayer',
                'fileId' => $fileId
            ]);
            return new DataResponse(['error' => 'Failed to read file'], 500);
        }
    }

    /**
     * Validate MusicXML file structure
     */
    #[NoAdminRequired]
    public function validateFile(int $fileId): DataResponse {
        try {
            $user = $this->userSession->getUser();
            if (!$user) {
                return new DataResponse(['error' => 'User not authenticated'], 401);
            }

            $userFolder = $this->rootFolder->getUserFolder($user->getUID());
            $files = $userFolder->getById($fileId);

            if (empty($files)) {
                return new DataResponse(['error' => 'File not found'], 404);
            }

            $file = $files[0];
            $validation = $this->validateMusicXMLStructure($file);

            return new DataResponse($validation);

        } catch (\Exception $e) {
            $this->logger->error('Failed to validate file: ' . $e->getMessage(), [
                'app' => 'flatioplayer',
                'fileId' => $fileId
            ]);
            return new DataResponse(['error' => 'Validation failed'], 500);
        }
    }

    /**
     * Optimized file scanner with depth limiting
     */
    private function scanForMusicXMLFiles($folder, int $maxDepth = 5, int $currentDepth = 0): array {
        $files = [];
        
        if ($currentDepth >= $maxDepth) {
            return $files;
        }

        try {
            $nodes = $folder->getDirectoryListing();
            
            foreach ($nodes as $node) {
                if ($node->getType() === \OCP\Files\FileInfo::TYPE_FILE) {
                    if ($this->isMusicXMLFile($node)) {
                        $files[] = [
                            'id' => $node->getId(),
                            'name' => $node->getName(),
                            'path' => $node->getPath(),
                            'size' => $node->getSize(),
                            'mtime' => $node->getMTime(),
                            'etag' => $node->getEtag()
                        ];
                    }
                } elseif ($node->getType() === \OCP\Files\FileInfo::TYPE_FOLDER) {
                    // Recursive scan with depth control
                    $subFiles = $this->scanForMusicXMLFiles($node, $maxDepth, $currentDepth + 1);
                    $files = array_merge($files, $subFiles);
                }
            }
        } catch (\Exception $e) {
            // Log but continue - don't fail entire scan for one folder
            $this->logger->debug('Cannot access folder during scan: ' . $e->getMessage(), [
                'app' => 'flatioplayer'
            ]);
        }

        return $files;
    }

    /**
     * Enhanced MusicXML file detection
     */
    private function isMusicXMLFile(\OCP\Files\File $file): bool {
        // Check file extension first (fast)
        $extension = strtolower(pathinfo($file->getName(), PATHINFO_EXTENSION));
        if (!in_array($extension, ['mxml', 'musicxml', 'xml'])) {
            return false;
        }

        // For .xml files, check content (slower but necessary)
        if ($extension === 'xml') {
            try {
                // Read only first 2048 bytes for performance
                $handle = $file->fopen('r');
                if (!$handle) {
                    return false;
                }

                $content = fread($handle, 2048);
                fclose($handle);

                if (!$content) {
                    return false;
                }

                // Check for MusicXML signatures
                $patterns = [
                    '<score-partwise',
                    '<score-timewise',
                    'DOCTYPE score-partwise',
                    'DOCTYPE score-timewise',
                    'musicxml'
                ];

                foreach ($patterns as $pattern) {
                    if (stripos($content, $pattern) !== false) {
                        return true;
                    }
                }

                return false;
            } catch (\Exception $e) {
                return false;
            }
        }

        // .mxml and .musicxml are always considered MusicXML
        return true;
    }

    /**
     * Advanced MusicXML structure validation
     */
    private function validateMusicXMLStructure(\OCP\Files\File $file): array {
        try {
            $content = $file->getContent();
            
            // Parse XML structure
            $previousSetting = libxml_use_internal_errors(true);
            $xml = simplexml_load_string($content);
            libxml_use_internal_errors($previousSetting);

            if ($xml === false) {
                $errors = libxml_get_errors();
                return [
                    'valid' => false,
                    'error' => 'XML parsing failed',
                    'details' => array_map(fn($err) => $err->message, $errors)
                ];
            }

            $validation = [
                'valid' => true,
                'type' => $this->detectMusicXMLType($xml),
                'parts' => $this->countParts($xml),
                'measures' => $this->countMeasures($xml),
                'title' => $this->extractTitle($xml),
                'composer' => $this->extractComposer($xml)
            ];

            return $validation;

        } catch (\Exception $e) {
            return [
                'valid' => false,
                'error' => 'Validation failed: ' . $e->getMessage()
            ];
        }
    }

    private function detectMusicXMLType(\SimpleXMLElement $xml): string {
        if (isset($xml->{'score-partwise'})) {
            return 'partwise';
        } elseif (isset($xml->{'score-timewise'})) {
            return 'timewise';
        }
        return $xml->getName();
    }

    private function countParts(\SimpleXMLElement $xml): int {
        $partList = $xml->xpath('//score-part');
        return count($partList);
    }

    private function countMeasures(\SimpleXMLElement $xml): int {
        $measures = $xml->xpath('//measure');
        return count($measures);
    }

    private function extractTitle(\SimpleXMLElement $xml): ?string {
        $titles = $xml->xpath('//work-title | //movement-title');
        return !empty($titles) ? trim((string)$titles[0]) : null;
    }

    private function extractComposer(\SimpleXMLElement $xml): ?string {
        $composers = $xml->xpath('//creator[@type="composer"] | //creator[not(@type)]');
        return !empty($composers) ? trim((string)$composers[0]) : null;
    }
}
($fileData);

        } catch (\Exception $e) {
            \OC::$server->getLogger()->error('File API error: ' . $e->getMessage(), ['app' => 'flatioplayer']);
            return new JSONResponse(['error' => 'Failed to load file'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Validate MusicXML file
     * 
     * @NoAdminRequired
     */
    public function validate(int $fileId): JSONResponse {
        try {
            $user = $this->userSession->getUser();
            if (!$user) {
                return new JSONResponse(['error' => 'User not authenticated'], Response::HTTP_UNAUTHORIZED);
            }

            $userId = $user->getUID();
            $cacheKey = "validate_{$fileId}_{$userId}";

            // Try cache first
            $cachedResult = $this->cache->get($cacheKey);
            if ($cachedResult !== null) {
                return new JSONResponse($cachedResult);
            }

            // Validate file
            $validation = $this->validateMusicXMLFile($userId, $fileId);
            
            // Cache validation result (longer TTL for validation)
            $this->cache->set($cacheKey, $validation, self::CACHE_TTL * 2);

            return new JSONResponse($validation);

        } catch (\Exception $e) {
            \OC::$server->getLogger()->error('Validation API error: ' . $e->getMessage(), ['app' => 'flatioplayer']);
            return new JSONResponse(['error' => 'Validation failed'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Clear cache
     * 
     * @NoAdminRequired
     */
    public function clearCache(): JSONResponse {
        try {
            $user = $this->userSession->getUser();
            if (!$user) {
                return new JSONResponse(['error' => 'User not authenticated'], Response::HTTP_UNAUTHORIZED);
            }

            $userId = $user->getUID();
            
            // Clear user-specific cache entries
            $this->cache->remove("files_$userId");
            
            return new JSONResponse(['success' => true, 'message' => 'Cache cleared']);

        } catch (\Exception $e) {
            return new JSONResponse(['error' => 'Failed to clear cache'], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Scan for MusicXML files with optimized search
     */
    private function scanMusicXMLFiles(string $userId): array {
        $userFolder = $this->rootFolder->getUserFolder($userId);
        $files = [];

        try {
            // Search by MIME types and extensions for better performance
            $musicXMLFiles = $userFolder->searchByMime('text/xml');
            
            foreach ($musicXMLFiles as $file) {
                if ($file->getType() !== \OCP\Files\FileInfo::TYPE_FILE) {
                    continue;
                }

                // Quick extension check
                if (!$this->hasValidExtension($file->getName())) {
                    continue;
                }

                // Size check for performance
                if ($file->getSize() > self::MAX_FILE_SIZE) {
                    continue;
                }

                // Quick content validation
                if (!$this->quickValidateContent($file)) {
                    continue;
                }

                $files[] = [
                    'id' => $file->getId(),
                    'name' => $file->getName(),
                    'size' => $file->getSize(),
                    'mtime' => $file->getMTime(),
                    'path' => $userFolder->getRelativePath($file->getPath()),
                    'composer' => $this->extractComposer($file),
                    'title' => $this->extractTitle($file)
                ];
            }

        } catch (\Exception $e) {
            \OC::$server->getLogger()->warning('File scan error: ' . $e->getMessage(), ['app' => 'flatioplayer']);
        }

        // Sort by name for consistent ordering
        usort($files, fn($a, $b) => strcasecmp($a['name'], $b['name']));

        return $files;
    }

    /**
     * Get file data with content
     */
    private function getFileData(string $userId, int $fileId): ?array {
        try {
            $userFolder = $this->rootFolder->getUserFolder($userId);
            $files = $userFolder->getById($fileId);

            if (empty($files)) {
                return null;
            }

            $file = $files[0];
            
            if ($file->getType() !== \OCP\Files\FileInfo::TYPE_FILE) {
                return null;
            }

            // Size check
            if ($file->getSize() > self::MAX_FILE_SIZE) {
                throw new \Exception('File too large');
            }

            // Read content
            $content = $file->getContent();
            
            return [
                'id' => $file->getId(),
                'name' => $file->getName(),
                'size' => $file->getSize(),
                'mtime' => $file->getMTime(),
                'content' => $content,
                'metadata' => $this->extractMetadata($content)
            ];

        } catch (\Exception $e) {
            \OC::$server->getLogger()->error('Get file data error: ' . $e->getMessage(), ['app' => 'flatioplayer']);
            return null;
        }
    }

    /**
     * Validate MusicXML file structure
     */
    private function validateMusicXMLFile(string $userId, int $fileId): array {
        try {
            $fileData = $this->getFileData($userId, $fileId);
            
            if (!$fileData) {
                return ['valid' => false, 'error' => 'File not found'];
            }

            $content = $fileData['content'];
            
            // Basic XML validation
            libxml_use_internal_errors(true);
            $xml = simplexml_load_string($content);
            $xmlErrors = libxml_get_errors();
            libxml_clear_errors();

            if ($xml === false) {
                $errorMessages = array_map(fn($error) => trim($error->message), $xmlErrors);
                return [
                    'valid' => false, 
                    'error' => 'Invalid XML: ' . implode(', ', $errorMessages)
                ];
            }

            // MusicXML specific validation
            $rootName = $xml->getName();
            if (!in_array($rootName, ['score-partwise', 'score-timewise'])) {
                return [
                    'valid' => false,
                    'error' => 'Not a valid MusicXML file: missing score-partwise or score-timewise root'
                ];
            }

            // Additional structure checks
            if (!isset($xml->{'part-list'})) {
                return [
                    'valid' => false,
                    'error' => 'Invalid MusicXML: missing part-list'
                ];
            }

            return [
                'valid' => true,
                'format' => $rootName,
                'metadata' => $fileData['metadata']
            ];

        } catch (\Exception $e) {
            return [
                'valid' => false,
                'error' => 'Validation failed: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Quick extension validation
     */
    private function hasValidExtension(string $filename): bool {
        $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        return in_array($extension, self::SUPPORTED_EXTENSIONS);
    }

    /**
     * Quick content validation without full parsing
     */
    private function quickValidateContent($file): bool {
        try {
            // Read first 1KB for quick validation
            $handle = $file->fopen('r');
            if (!$handle) return false;

            $preview = fread($handle, 1024);
            fclose($handle);

            // Must contain MusicXML indicators
            return (strpos($preview, 'score-partwise') !== false || 
                   strpos($preview, 'score-timewise') !== false) &&
                   strpos($preview, '<?xml') !== false;

        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Extract composer from content (optimized)
     */
    private function extractComposer($file): ?string {
        try {
            // Read first 2KB to find composer info
            $handle = $file->fopen('r');
            if (!$handle) return null;

            $preview = fread($handle, 2048);
            fclose($handle);

            // Simple regex extraction
            if (preg_match('/<creator[^>]*type="composer"[^>]*>([^<]+)<\/creator>/i', $preview, $matches)) {
                return trim($matches[1]);
            }

            return null;

        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Extract title from content (optimized)
     */
    private function extractTitle($file): ?string {
        try {
            // Read first 2KB to find title info
            $handle = $file->fopen('r');
            if (!$handle) return null;

            $preview = fread($handle, 2048);
            fclose($handle);

            // Try work-title first, then movement-title
            if (preg_match('/<work-title[^>]*>([^<]+)<\/work-title>/i', $preview, $matches)) {
                return trim($matches[1]);
            }

            if (preg_match('/<movement-title[^>]*>([^<]+)<\/movement-title>/i', $preview, $matches)) {
                return trim($matches[1]);
            }

            return null;

        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Extract full metadata from content
     */
    private function extractMetadata(string $content): array {
        $metadata = [
            'title' => null,
            'composer' => null,
            'lyricist' => null,
            'copyright' => null,
            'software' => null,
            'encoding_date' => null
        ];

        try {
            // Work title
            if (preg_match('/<work-title[^>]*>([^<]+)<\/work-title>/i', $content, $matches)) {
                $metadata['title'] = trim($matches[1]);
            }

            // Movement title (fallback)
            if (!$metadata['title'] && preg_match('/<movement-title[^>]*>([^<]+)<\/movement-title>/i', $content, $matches)) {
                $metadata['title'] = trim($matches[1]);
            }

            // Composer
            if (preg_match('/<creator[^>]*type="composer"[^>]*>([^<]+)<\/creator>/i', $content, $matches)) {
                $metadata['composer'] = trim($matches[1]);
            }

            // Lyricist
            if (preg_match('/<creator[^>]*type="lyricist"[^>]*>([^<]+)<\/creator>/i', $content, $matches)) {
                $metadata['lyricist'] = trim($matches[1]);
            }

            // Copyright
            if (preg_match('/<rights[^>]*>([^<]+)<\/rights>/i', $content, $matches)) {
                $metadata['copyright'] = trim($matches[1]);
            }

            // Software
            if (preg_match('/<software[^>]*>([^<]+)<\/software>/i', $content, $matches)) {
                $metadata['software'] = trim($matches[1]);
            }

            // Encoding date
            if (preg_match('/<encoding-date[^>]*>([^<]+)<\/encoding-date>/i', $content, $matches)) {
                $metadata['encoding_date'] = trim($matches[1]);
            }

        } catch (\Exception $e) {
            \OC::$server->getLogger()->warning('Metadata extraction failed: ' . $e->getMessage(), ['app' => 'flatioplayer']);
        }

        return $metadata;
    }
}
