<?php

declare(strict_types=1);

namespace OCA\FlatioPlayer\Controller;

use OCP\AppFramework\Controller;
use OCP\AppFramework\Http\TemplateResponse;
use OCP\AppFramework\Http\ContentSecurityPolicy;
use OCP\IRequest;
use OCP\Util;

/**
 * Page Controller for Flat.io Player
 * 
 * Handles main page rendering with optimized CSP headers
 * for Flat.io integration in Nextcloud 31.0.7.
 */
class PageController extends Controller {

    public function __construct(
        string $appName,
        IRequest $request
    ) {
        parent::__construct($appName, $request);
    }

    /**
     * Main app page
     * 
     * @NoAdminRequired
     * @NoCSRFRequired
     */
    public function index(): TemplateResponse {
        // Add app scripts and styles
        Util::addScript($this->appName, 'musicxml-validator');
        Util::addScript($this->appName, 'flatio-embed');
        Util::addScript($this->appName, 'flatio-player');
        Util::addScript($this->appName, 'flatio-auto-installer');
        Util::addStyle($this->appName, 'app');

        // Create response with main template
        $response = new TemplateResponse($this->appName, 'main', [
            'app_name' => $this->appName,
            'app_version' => '1.0.0'
        ]);

        // Add CSP header for Flat.io integration
        $csp = new ContentSecurityPolicy();
        $csp->addAllowedScriptDomain('https://embed.flat.io');
        $csp->addAllowedFrameDomain('https://embed.flat.io');
        $csp->addAllowedConnectDomain('https://embed.flat.io');
        $csp->addAllowedWorkerSrcDomain('https://embed.flat.io');
        $csp->allowInlineStyle();

        $response->setContentSecurityPolicy($csp);

        return $response;
    }
}
