<?php

declare(strict_types=1);

namespace OCA\FlatioPlayer\Service;

use Psr\Log\LoggerInterface;

/**
 * Installation Detection Service
 * 
 * Centralized service for detecting Nextcloud installation environment
 * and determining optimal file ownership settings.
 */
class InstallationService {

    private LoggerInterface $logger;

    public function __construct(LoggerInterface $logger) {
        $this->logger = $logger;
    }

    /**
     * Detect Nextcloud installation path and file owner
     */
    public function detectInstallationInfo(): array {
        // Get Nextcloud root path
        $nextcloudPath = \OC::$SERVERROOT;
        $appPath = $nextcloudPath . '/apps/flatioplayer';
        
        $owner = null;
        $group = null;
        
        // Method 1: Check app directory owner
        if (file_exists($appPath)) {
            $stat = stat($appPath);
            if ($stat !== false) {
                $owner = posix_getpwuid($stat['uid'])['name'] ?? null;
                $group = posix_getgrgid($stat['gid'])['name'] ?? null;
                $this->logger->debug('Flat.io Player: Owner from app directory - ' . $owner . ':' . $group, ['app' => 'flatioplayer']);
            }
        }
        
        // Method 2: Check Nextcloud config.php owner
        if (!$owner) {
            $configPath = $nextcloudPath . '/config/config.php';
            if (file_exists($configPath)) {
                $stat = stat($configPath);
                if ($stat !== false) {
                    $owner = posix_getpwuid($stat['uid'])['name'] ?? null;
                    $group = posix_getgrgid($stat['gid'])['name'] ?? null;
                    $this->logger->debug('Flat.io Player: Owner from config.php - ' . $owner . ':' . $group, ['app' => 'flatioplayer']);
                }
            }
        }
        
        // Method 3: Check data directory owner
        if (!$owner) {
            $dataPath = \OC::$server->getConfig()->getSystemValue('datadirectory', $nextcloudPath . '/data');
            if (file_exists($dataPath)) {
                $stat = stat($dataPath);
                if ($stat !== false) {
                    $owner = posix_getpwuid($stat['uid'])['name'] ?? null;
                    $group = posix_getgrgid($stat['gid'])['name'] ?? null;
                    $this->logger->debug('Flat.io Player: Owner from data directory - ' . $owner . ':' . $group, ['app' => 'flatioplayer']);
                }
            }
        }
        
        // Method 4: Detect common hosting patterns
        if (!$owner) {
            $pathParts = explode('/', $nextcloudPath);
            
            // Pattern: /home/username/domains/... (cloud.ottoniascoppio.org)
            if (count($pathParts) >= 3 && $pathParts[1] === 'home') {
                $potentialOwner = $pathParts[2];
                if (posix_getpwnam($potentialOwner) !== false) {
                    $owner = $potentialOwner;
                    $group = $potentialOwner;
                    $this->logger->debug('Flat.io Player: Owner from path pattern - ' . $owner . ':' . $group, ['app' => 'flatioplayer']);
                }
            }
            
            // Pattern: /var/www/...
            if (!$owner && in_array('www', $pathParts)) {
                $owner = 'www-data';
                $group = 'www-data';
                $this->logger->debug('Flat.io Player: Owner from www pattern - ' . $owner . ':' . $group, ['app' => 'flatioplayer']);
            }
        }
        
        // Fallback
        if (!$owner) {
            $owner = 'www-data';
            $group = 'www-data';
            $this->logger->warning('Flat.io Player: Using fallback owner - ' . $owner . ':' . $group, ['app' => 'flatioplayer']);
        }
        
        return [
            'nextcloud_path' => $nextcloudPath,
            'app_path' => $appPath,
            'owner' => $owner,
            'group' => $group
        ];
    }

    /**
     * Check current installation status
     */
    public function checkCurrentStatus(array $installInfo): array {
        $appPath = $installInfo['app_path'];
        $owner = $installInfo['owner'];
        
        $status = [
            'app_exists' => is_dir($appPath),
            'critical_files_exist' => true,
            'permissions_correct' => true,
            'owner_correct' => true,
            'properly_configured' => false
        ];
        
        // Check critical files
        $criticalFiles = [
            'appinfo/info.xml',
            'lib/AppInfo/Application.php',
            'composer.json'
        ];
        
        foreach ($criticalFiles as $file) {
            if (!file_exists($appPath . '/' . $file)) {
                $status['critical_files_exist'] = false;
                break;
            }
        }
        
        // Check ownership
        if ($status['app_exists']) {
            $stat = stat($appPath);
            if ($stat !== false) {
                $actualOwner = posix_getpwuid($stat['uid'])['name'] ?? null;
                if ($actualOwner !== $owner) {
                    $status['owner_correct'] = false;
                }
            }
        }
        
        // Check permissions
        if ($status['app_exists'] && !is_readable($appPath)) {
            $status['permissions_correct'] = false;
        }
        
        $status['properly_configured'] = $status['app_exists'] && 
                                       $status['critical_files_exist'] && 
                                       $status['permissions_correct'] && 
                                       $status['owner_correct'];
        
        return $status;
    }

    /**
     * Setup correct file permissions
     */
    public function setupPermissions(array $installInfo): void {
        $appPath = $installInfo['app_path'];
        $owner = $installInfo['owner'];
        $group = $installInfo['group'];
        
        try {
            // Set ownership recursively
            $this->chownRecursive($appPath, $owner, $group);
            
            // Set directory permissions (755)
            $this->chmodRecursive($appPath, 0755, 0644);
            
            $this->logger->info('Flat.io Player: Permissions set successfully', [
                'app' => 'flatioplayer',
                'owner' => $owner . ':' . $group
            ]);
            
        } catch (\Exception $e) {
            $this->logger->error('Flat.io Player: Permission setup failed: ' . $e->getMessage(), ['app' => 'flatioplayer']);
            throw $e;
        }
    }

    /**
     * Setup required directories
     */
    public function setupDirectories(array $installInfo): void {
        $appPath = $installInfo['app_path'];
        
        // Directories that must exist
        $requiredDirs = [
            $appPath . '/css',
            $appPath . '/js', 
            $appPath . '/templates',
            $appPath . '/lib',
            $appPath . '/img',
            $appPath . '/l10n'
        ];
        
        foreach ($requiredDirs as $dir) {
            if (!is_dir($dir)) {
                if (mkdir($dir, 0755, true)) {
                    $this->logger->debug('Flat.io Player: Created directory: ' . $dir, ['app' => 'flatioplayer']);
                    chown($dir, $installInfo['owner']);
                    chgrp($dir, $installInfo['group']);
                }
            }
        }
    }

    /**
     * Verify installation is correct
     */
    public function verifyInstallation(array $installInfo): bool {
        $appPath = $installInfo['app_path'];
        
        // Critical files that must exist
        $criticalFiles = [
            $appPath . '/appinfo/info.xml',
            $appPath . '/lib/AppInfo/Application.php',
            $appPath . '/composer.json'
        ];
        
        foreach ($criticalFiles as $file) {
            if (!file_exists($file)) {
                return false;
            }
            
            // Check if file is readable
            if (!is_readable($file)) {
                return false;
            }
        }
        
        return true;
    }

    /**
     * Recursively change ownership
     */
    private function chownRecursive(string $path, string $owner, string $group): void {
        if (!file_exists($path)) {
            return;
        }
        
        // Change ownership of the path itself
        chown($path, $owner);
        chgrp($path, $group);
        
        // If it's a directory, recurse
        if (is_dir($path)) {
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($path, \RecursiveDirectoryIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::SELF_FIRST
            );
            
            foreach ($iterator as $file) {
                chown($file->getPathname(), $owner);
                chgrp($file->getPathname(), $group);
            }
        }
    }

    /**
     * Recursively set permissions
     */
    private function chmodRecursive(string $path, int $dirPerm, int $filePerm): void {
        if (!file_exists($path)) {
            return;
        }
        
        if (is_dir($path)) {
            chmod($path, $dirPerm);
            
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($path, \RecursiveDirectoryIterator::SKIP_DOTS),
                \RecursiveIteratorIterator::SELF_FIRST
            );
            
            foreach ($iterator as $file) {
                if ($file->isDir()) {
                    chmod($file->getPathname(), $dirPerm);
                } else {
                    chmod($file->getPathname(), $filePerm);
                }
            }
        } else {
            chmod($path, $filePerm);
        }
    }
}
