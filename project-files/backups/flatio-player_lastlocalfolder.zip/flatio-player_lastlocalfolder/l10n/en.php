<?php
$TRANSLATIONS = array(
    "Flat.io Player" => "Flat.io Player",
    "Professional music notation" => "Professional music notation",
    "Music Library" => "Music Library",
    "Refresh" => "Refresh",
    "No music files found" => "No music files found",
    "Upload MusicXML files (.mxml, .musicxml, .xml) to get started" => "Upload MusicXML files (.mxml, .musicxml, .xml) to get started",
    "Loading files..." => "Loading files...",
    "Welcome to Flat.io Player" => "Welcome to Flat.io Player",
    "Professional music notation powered by Flat.io" => "Professional music notation powered by Flat.io",
    "Select a music file from your library" => "Select a music file from your library",
    "View professional sheet music" => "View professional sheet music",
    "Play with high-quality audio" => "Play with high-quality audio",
    "Advanced playback controls" => "Advanced playback controls",
    "Choose a file to begin" => "Choose a file to begin",
    "Loading score..." => "Loading score...",
    "Preparing professional notation" => "Preparing professional notation",
    "Unable to load score" => "Unable to load score",
    "Try again" => "Try again",
    "No score loaded" => "No score loaded",
    "Play" => "Play",
    "Pause" => "Pause",
    "Stop" => "Stop",
    "Volume" => "Volume"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";