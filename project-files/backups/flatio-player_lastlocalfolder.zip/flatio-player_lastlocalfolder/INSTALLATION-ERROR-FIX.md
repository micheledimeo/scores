# 🚨 FIX: Errore "Could not download app musicxmlplayerflat"

## 🔍 **ANALISI ERRORE**

Il messaggio `Could not download app musicxmlplayerflat` indica una **discrepanza nell'ID app**:

- **ID Corretto**: `flatioplayer` (definito in info.xml)
- **ID Rilevato da Nextcloud**: `musicxmlplayerflat`
- **Causa**: Directory sbagliata o cache vecchia

---

## ✅ **SOLUZIONI IMMEDIATE**

### **Soluzione 1: Verifica Directory (PRINCIPALE)**

Il nome della directory DEVE corrispondere esattamente all'ID dell'app:

```bash
# ❌ SBAGLIATO - Directory con nome diverso
/path/to/nextcloud/apps/flatio-player/     # Contiene trattino
/path/to/nextcloud/apps/musicxml-player/   # Nome completamente diverso
/path/to/nextcloud/apps/musicxmlplayer/    # Vecchio nome

# ✅ CORRETTO - Directory con nome identico all'ID
/path/to/nextcloud/apps/flatioplayer/      # Corrisponde a <id>flatioplayer</id>
```

**Fix immediato per cloud.ottoniascoppio.org:**
```bash
# 1. Verifica directory attuale
ls -la /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/ | grep flatio

# 2. Se la directory ha nome sbagliato, rinominala
cd /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/
sudo mv flatio-player flatioplayer
# oppure
sudo mv musicxml-player flatioplayer
# oppure  
sudo mv musicxmlplayer flatioplayer

# 3. Verifica che il nome sia corretto
ls -la flatioplayer/
```

### **Soluzione 2: Pulisci Cache Nextcloud**

```bash
# Pulisci cache app
sudo -u ottoniascoppio php /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/occ app:list --refresh

# Pulisci cache generale
sudo -u ottoniascoppio php /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/occ maintenance:repair

# Ricarica webserver
sudo systemctl reload apache2
```

### **Soluzione 3: Rimozione Completa e Reinstallazione**

Se le soluzioni precedenti non funzionano:

```bash
# 1. Disabilita e rimuovi app esistente (se presente)
cd /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/
sudo rm -rf flatio-player musicxml-player musicxmlplayer flatioplayer

# 2. Installazione pulita
sudo tar -xzf /tmp/flatio-player-v1.0.0.tar.gz
sudo mv flatio-player flatioplayer

# 3. Fix permissions
sudo chown -R ottoniascoppio:ottoniascoppio flatioplayer
sudo chmod -R 755 flatioplayer
sudo find flatioplayer -name "*.php" -exec chmod 644 {} \;

# 4. Pulisci cache
sudo -u ottoniascoppio php ../occ app:list --refresh
```

---

## 🔧 **DIAGNOSI AVANZATA**

### **Controlla ID App Effettivo**

```bash
# Verifica che l'ID nell'info.xml sia corretto
cat /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/flatioplayer/appinfo/info.xml | grep -A 1 "<id>"

# Output atteso:
# <id>flatioplayer</id>
```

### **Controlla Directory Apps**

```bash
# Lista tutte le directory app
ls -la /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/ | grep -E "(flatio|musicxml)"

# Non dovrebbero esserci directory multiple o con nomi sbagliati
```

### **Controlla Log Nextcloud**

```bash
# Monitora log durante l'enable
tail -f /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/data/nextcloud.log | grep -E "(flatio|musicxml)"

# Poi prova a abilitare l'app dal browser
```

---

## 📋 **CHECKLIST INSTALLAZIONE CORRETTA**

### **✅ Pre-Installazione**
- [ ] Directory app si chiama **esattamente** `flatioplayer`
- [ ] Non ci sono altre directory simili (flatio-player, musicxml-player, ecc.)
- [ ] File `appinfo/info.xml` contiene `<id>flatioplayer</id>`
- [ ] Permissions corretti (ottoniascoppio:ottoniascoppio)

### **✅ Installazione**
```bash
# Percorso corretto
/home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/flatioplayer/

# Struttura attesa
flatioplayer/
├── appinfo/info.xml    # Contiene <id>flatioplayer</id>
├── composer.json
├── css/
├── js/
├── lib/
└── templates/
```

### **✅ Post-Installazione**
- [ ] Cache Nextcloud pulita con `occ app:list --refresh`
- [ ] Webserver riavviato/ricaricato
- [ ] App visibile in `occ app:list | grep flatioplayer`
- [ ] Nessun errore nei log

---

## 🚀 **INSTALLAZIONE AUTOMATICA CORRETTA**

Una volta risolto il problema del nome directory, l'**auto-installazione** dovrebbe funzionare perfettamente:

```bash
# 1. Directory corretta
/home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/flatioplayer/

# 2. Enable app dal pannello admin Nextcloud
# → L'AppEnableListener si attiva automaticamente
# → Rileva: ottoniascoppio:ottoniascoppio  
# → Imposta: permissions 755/644
# → Configura: tutto automaticamente

# 3. Verifica successo
sudo -u ottoniascoppio php ../occ app:list | grep flatioplayer
# Output: - flatioplayer: Flat.io Player
```

---

## ⚠️ **ERRORI COMUNI**

### **❌ Directory Nome Sbagliato**
```bash
# SBAGLIATO
apps/flatio-player/        # Contiene trattino (-)
apps/musicxml-player/      # Nome completamente diverso
apps/FlatioPlayer/         # Case sensitive - deve essere minuscolo

# CORRETTO  
apps/flatioplayer/         # Identico a <id>flatioplayer</id>
```

### **❌ Cache Non Pulita**
Dopo qualsiasi modifica alla directory o ai file dell'app:
```bash
# SEMPRE pulire cache
sudo -u ottoniascoppio php occ app:list --refresh
```

### **❌ Permissions Sbagliati**
```bash
# Verifica owner
ls -la apps/ | grep flatioplayer
# Deve essere: drwxr-xr-x ottoniascoppio ottoniascoppio flatioplayer

# Fix se necessario
sudo chown -R ottoniascoppio:ottoniascoppio apps/flatioplayer/
```

---

## 🎯 **RISULTATO ATTESO**

Dopo la risoluzione, dovresti vedere:

1. **Browser Admin Panel**: 
   - App "Flat.io Player" nella lista "Your apps"
   - Click "Enable" funziona senza errori
   - Banner di successo auto-installazione

2. **Menu Nextcloud**:
   - "Flat.io Player" appare nel menu principale
   - Click apre l'interfaccia senza errori

3. **OCC Command**:
   ```bash
   sudo -u ottoniascoppio php occ app:list | grep flatioplayer
   # Output: - flatioplayer: Flat.io Player
   ```

---

## 📞 **Se il Problema Persiste**

Se dopo aver seguito tutti i passi l'errore persiste:

1. **Invia output** di questi comandi:
```bash
ls -la /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/ | grep -E "(flatio|musicxml)"
cat /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/*/appinfo/info.xml | grep -A 1 "<id>"
tail -20 /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/data/nextcloud.log
```

2. **Verifica versione** Nextcloud:
```bash
sudo -u ottoniascoppio php occ status
```

La causa più probabile è il **nome directory sbagliato** - assicurati che sia esattamente `flatioplayer` senza trattini o variazioni! 🎯
