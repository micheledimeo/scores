/**
 * MusicXML Validator - Optimized for Production
 * Fast validation with minimal memory footprint
 */

'use strict';

class MusicXMLValidator {
    constructor() {
        this.config = {
            maxFileSize: 50 * 1024 * 1024, // 50MB
            timeout: 5000,
            debug: false
        };

        // Optimized patterns for fast validation
        this.patterns = {
            // Primary MusicXML root elements
            scorePartwise: /<score-partwise[^>]*>/i,
            scoreTimewise: /<score-timewise[^>]*>/i,
            
            // XML declaration and encoding
            xmlDeclaration: /<\?xml[^>]*>/i,
            
            // Essential MusicXML elements for validation
            partList: /<part-list[^>]*>/i,
            scorePart: /<score-part[^>]*>/i,
            part: /<part[^>]*>/i,
            measure: /<measure[^>]*>/i,
            
            // Common invalid patterns (quick rejection)
            htmlTags: /<(html|body|div|span|p)[^>]*>/i,
            jsonPattern: /^\s*[\{\[]/,
            
            // DOCTYPE validation
            musicxmlDoctypes: [
                /<!DOCTYPE\s+score-partwise/i,
                /<!DOCTYPE\s+score-timewise/i
            ]
        };

        // Logging helper
        this.log = {
            info: (msg) => this.config.debug && console.info('XV:', msg),
            warn: (msg) => this.config.debug && console.warn('XV:', msg),
            error: (msg) => console.error('XV:', msg)
        };

        this.log.info('MusicXML Validator initialized');
    }

    /**
     * Validate file with optimized checks
     */
    async validateFile(file) {
        if (!file) {
            this.log.error('No file provided');
            return false;
        }

        try {
            // Quick size check
            if (file.size > this.config.maxFileSize) {
                this.log.warn(`File too large: ${file.size} bytes`);
                return false;
            }

            // Quick extension check
            if (!this.isValidExtension(file.name)) {
                this.log.warn('Invalid file extension');
                return false;
            }

            // Get file content
            const content = await this.getFileContent(file);
            
            // Fast validation checks
            return this.validateContent(content);

        } catch (error) {
            this.log.error('Validation failed:', error);
            return false;
        }
    }

    /**
     * Fast extension validation
     */
    isValidExtension(filename) {
        if (!filename) return false;
        
        const ext = filename.toLowerCase().split('.').pop();
        return ['xml', 'mxml', 'musicxml'].includes(ext);
    }

    /**
     * Get file content with timeout
     */
    async getFileContent(file) {
        // If file has URL/path, fetch from server
        if (file.id || file.url) {
            return this.fetchFileContent(file);
        }
        
        // If file is a File object, read directly
        if (file instanceof File) {
            return this.readFileContent(file);
        }
        
        throw new Error('Unable to read file content');
    }

    /**
     * Fetch file content from server
     */
    async fetchFileContent(file) {
        const url = file.url || OC.generateUrl(`/apps/flatioplayer/api/file/${file.id}`);
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), this.config.timeout);

        try {
            const response = await fetch(url, {
                headers: { 'requesttoken': OC.requestToken },
                signal: controller.signal
            });

            clearTimeout(timeoutId);

            if (!response.ok) {
                throw new Error(`Fetch failed: ${response.status}`);
            }

            const data = await response.json();
            return data.content || data.data || '';

        } catch (error) {
            clearTimeout(timeoutId);
            throw new Error(`Content fetch failed: ${error.message}`);
        }
    }

    /**
     * Read file content directly
     */
    async readFileContent(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = (e) => resolve(e.target.result);
            reader.onerror = () => reject(new Error('File read failed'));
            
            // Set timeout
            const timeoutId = setTimeout(() => {
                reader.abort();
                reject(new Error('File read timeout'));
            }, this.config.timeout);

            reader.onloadend = () => clearTimeout(timeoutId);
            reader.readAsText(file);
        });
    }

    /**
     * Fast content validation with early exits
     */
    validateContent(content) {
        if (!content || typeof content !== 'string') {
            this.log.warn('Empty or invalid content');
            return false;
        }

        // Early rejection checks (fastest)
        if (this.quickRejectChecks(content)) {
            return false;
        }

        // Core MusicXML validation
        if (this.validateMusicXMLStructure(content)) {
            this.log.info('Valid MusicXML file detected');
            return true;
        }

        this.log.warn('Content failed MusicXML validation');
        return false;
    }

    /**
     * Quick rejection tests for non-MusicXML content
     */
    quickRejectChecks(content) {
        const trimmed = content.trim();
        
        // Empty content
        if (trimmed.length === 0) {
            this.log.warn('Empty content');
            return true;
        }

        // JSON content
        if (this.patterns.jsonPattern.test(trimmed)) {
            this.log.warn('JSON content detected');
            return true;
        }

        // HTML content
        if (this.patterns.htmlTags.test(trimmed)) {
            this.log.warn('HTML content detected');
            return true;
        }

        // Must start with XML declaration or root element
        if (!trimmed.startsWith('<?xml') && !trimmed.startsWith('<score-')) {
            this.log.warn('Invalid XML start');
            return true;
        }

        return false;
    }

    /**
     * Core MusicXML structure validation
     */
    validateMusicXMLStructure(content) {
        // Must have valid root element
        const hasValidRoot = this.patterns.scorePartwise.test(content) || 
                           this.patterns.scoreTimewise.test(content);
        
        if (!hasValidRoot) {
            this.log.warn('Missing MusicXML root element');
            return false;
        }

        // Must have essential elements
        const requiredElements = [
            this.patterns.partList,
            this.patterns.part
        ];

        for (const pattern of requiredElements) {
            if (!pattern.test(content)) {
                this.log.warn('Missing required MusicXML element');
                return false;
            }
        }

        // Should have measures (most MusicXML files do)
        if (!this.patterns.measure.test(content)) {
            this.log.warn('No measures found - may be empty score');
            // Don't reject - empty scores are valid
        }

        return true;
    }

    /**
     * Extract metadata from MusicXML content
     */
    extractMetadata(content) {
        const metadata = {
            title: null,
            composer: null,
            lyricist: null,
            copyright: null,
            parts: 0,
            measures: 0
        };

        if (!content) return metadata;

        try {
            // Extract work title
            const workTitle = content.match(/<work-title[^>]*>([^<]+)<\/work-title>/i);
            if (workTitle) metadata.title = workTitle[1].trim();

            // Extract movement title (fallback)
            if (!metadata.title) {
                const movementTitle = content.match(/<movement-title[^>]*>([^<]+)<\/movement-title>/i);
                if (movementTitle) metadata.title = movementTitle[1].trim();
            }

            // Extract composer
            const composer = content.match(/<creator[^>]*type="composer"[^>]*>([^<]+)<\/creator>/i);
            if (composer) metadata.composer = composer[1].trim();

            // Extract lyricist
            const lyricist = content.match(/<creator[^>]*type="lyricist"[^>]*>([^<]+)<\/creator>/i);
            if (lyricist) metadata.lyricist = lyricist[1].trim();

            // Extract copyright
            const copyright = content.match(/<rights[^>]*>([^<]+)<\/rights>/i);
            if (copyright) metadata.copyright = copyright[1].trim();

            // Count parts (performance optimization: only count matches)
            const partMatches = content.match(/<score-part[^>]*>/gi);
            metadata.parts = partMatches ? partMatches.length : 0;

            // Count measures (first part only for performance)
            const firstPartMatch = content.match(/<part[^>]*id="[^"]*"[^>]*>(.*?)<\/part>/is);
            if (firstPartMatch) {
                const measureMatches = firstPartMatch[1].match(/<measure[^>]*>/gi);
                metadata.measures = measureMatches ? measureMatches.length : 0;
            }

        } catch (error) {
            this.log.warn('Metadata extraction failed:', error);
        }

        return metadata;
    }

    /**
     * Validate specific MusicXML version
     */
    validateVersion(content) {
        if (!content) return null;

        try {
            // Check for version attribute
            const versionMatch = content.match(/<score-(?:partwise|timewise)[^>]*version="([^"]+)"/i);
            if (versionMatch) {
                return versionMatch[1];
            }

            // Check DOCTYPE for version
            const doctypeMatch = content.match(/<!DOCTYPE[^>]*"[^"]*musicxml[^"]*(\d+\.\d+)[^"]*"/i);
            if (doctypeMatch) {
                return doctypeMatch[1];
            }

            return 'unknown';

        } catch (error) {
            this.log.warn('Version detection failed:', error);
            return null;
        }
    }

    /**
     * Quick validation without full content parsing
     */
    quickValidate(filename, contentPreview) {
        // Extension check
        if (!this.isValidExtension(filename)) {
            return false;
        }

        // Quick content check if available
        if (contentPreview) {
            return !this.quickRejectChecks(contentPreview) && 
                   (this.patterns.scorePartwise.test(contentPreview) || 
                    this.patterns.scoreTimewise.test(contentPreview));
        }

        // Filename only validation
        return true;
    }

    /**
     * Batch validate multiple files
     */
    async validateBatch(files) {
        const results = [];
        const maxConcurrent = 3; // Limit concurrent validations

        for (let i = 0; i < files.length; i += maxConcurrent) {
            const batch = files.slice(i, i + maxConcurrent);
            const batchPromises = batch.map(async (file, index) => {
                try {
                    const isValid = await this.validateFile(file);
                    return { file, isValid, index: i + index };
                } catch (error) {
                    this.log.error(`Batch validation error for ${file.name}:`, error);
                    return { file, isValid: false, index: i + index, error: error.message };
                }
            });

            const batchResults = await Promise.all(batchPromises);
            results.push(...batchResults);
        }

        return results;
    }

    /**
     * Get validator statistics
     */
    getStats() {
        return {
            maxFileSize: this.config.maxFileSize,
            timeout: this.config.timeout,
            supportedExtensions: ['xml', 'mxml', 'musicxml'],
            supportedFormats: ['score-partwise', 'score-timewise']
        };
    }
}

// Make available globally
if (typeof window !== 'undefined') {
    window.MusicXMLValidator = MusicXMLValidator;
}

// Export for Node.js environments
if (typeof module !== 'undefined' && module.exports) {
    module.exports = MusicXMLValidator;
}
