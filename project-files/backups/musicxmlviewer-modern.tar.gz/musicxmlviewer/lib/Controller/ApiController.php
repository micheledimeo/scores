<?php
declare(strict_types=1);

namespace OCA\MusicXmlViewer\Controller;

use OCP\AppFramework\Controller;
use OCP\AppFramework\Http;
use OCP\AppFramework\Http\DataResponse;
use OCP\AppFramework\Http\DataDisplayResponse;
use OCP\Files\IRootFolder;
use OCP\Files\NotFoundException;
use OCP\IRequest;

class ApiController extends Controller {
    private IRootFolder $rootFolder;
    private ?string $userId;

    public function __construct(
        string $appName,
        IRequest $request,
        IRootFolder $rootFolder,
        ?string $userId
    ) {
        parent::__construct($appName, $request);
        $this->rootFolder = $rootFolder;
        $this->userId = $userId;
    }

    /**
     * @NoAdminRequired
     */
    public function getFile(int $fileId): DataResponse {
        try {
            if ($this->userId === null) {
                return new DataResponse(['error' => 'User not logged in'], Http::STATUS_UNAUTHORIZED);
            }

            $userFolder = $this->rootFolder->getUserFolder($this->userId);
            $files = $userFolder->getById($fileId);
            
            if (count($files) === 0) {
                return new DataResponse(['error' => 'File not found'], Http::STATUS_NOT_FOUND);
            }
            
            $file = $files[0];
            
            if (!($file instanceof \OCP\Files\File)) {
                return new DataResponse(['error' => 'Not a file'], Http::STATUS_BAD_REQUEST);
            }

            $content = $file->getContent();
            $mimeType = $file->getMimeType();
            
            return new DataResponse([
                'content' => base64_encode($content),
                'mimeType' => $mimeType,
                'name' => $file->getName(),
                'size' => $file->getSize()
            ]);
            
        } catch (NotFoundException $e) {
            return new DataResponse(['error' => 'File not found'], Http::STATUS_NOT_FOUND);
        } catch (\Exception $e) {
            return new DataResponse(['error' => $e->getMessage()], Http::STATUS_INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * @NoAdminRequired
     */
    public function listFiles(): DataResponse {
        try {
            if ($this->userId === null) {
                return new DataResponse(['error' => 'User not logged in'], Http::STATUS_UNAUTHORIZED);
            }

            $userFolder = $this->rootFolder->getUserFolder($this->userId);
            
            // Estensioni supportate per file MusicXML
            $supportedExtensions = ['xml', 'musicxml', 'mxl', 'mei', 'gp', 'gpx', 'gp3', 'gp4', 'gp5'];
            
            $musicFiles = $this->searchMusicFiles($userFolder, $supportedExtensions);
            
            return new DataResponse($musicFiles);
            
        } catch (\Exception $e) {
            return new DataResponse(['error' => $e->getMessage()], Http::STATUS_INTERNAL_SERVER_ERROR);
        }
    }

    private function searchMusicFiles($folder, array $extensions, string $path = ''): array {
        $files = [];
        
        foreach ($folder->getDirectoryListing() as $node) {
            $relativePath = $path . '/' . $node->getName();
            
            if ($node instanceof \OCP\Files\Folder) {
                $files = array_merge(
                    $files,
                    $this->searchMusicFiles($node, $extensions, $relativePath)
                );
            } elseif ($node instanceof \OCP\Files\File) {
                $extension = strtolower(pathinfo($node->getName(), PATHINFO_EXTENSION));
                
                if (in_array($extension, $extensions)) {
                    $files[] = [
                        'id' => $node->getId(),
                        'name' => $node->getName(),
                        'path' => $relativePath,
                        'size' => $node->getSize(),
                        'mimeType' => $node->getMimeType(),
                        'modifiedTime' => $node->getMTime()
                    ];
                }
            }
        }
        
        return $files;
    }
}
