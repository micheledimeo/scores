<template>
	<NcContent app-name="musicxmlviewer">
		<NcAppNavigation>
			<NcAppNavigationNew
				:text="t('musicxmlviewer', 'Upload MusicXML file')"
				@click="showFileUpload">
				<template #icon>
					<Plus :size="20" />
				</template>
			</NcAppNavigationNew>

			<div class="file-list">
				<NcAppNavigationCaption :title="t('musicxmlviewer', 'Your Music Files')" />
				<NcAppNavigationItem
					v-for="file in musicFiles"
					:key="file.id"
					:title="file.name"
					:class="{ 'active': currentFile && currentFile.id === file.id }"
					@click="loadFile(file.id)">
					<template #icon>
						<FileMusic :size="20" />
					</template>
				</NcAppNavigationItem>
			</div>
		</NcAppNavigation>

		<NcAppContent>
			<div class="viewer-container">
				<div v-if="!currentFile" class="empty-content">
					<div class="empty-content__icon">
						<FileMusic :size="64" />
					</div>
					<h2>{{ t('musicxmlviewer', 'No file selected') }}</h2>
					<p>{{ t('musicxmlviewer', 'Select a file from the sidebar or upload a new one') }}</p>
				</div>

				<div v-else-if="loading" class="loading-content">
					<NcLoadingIcon :size="64" />
					<p>{{ t('musicxmlviewer', 'Loading file...') }}</p>
				</div>

				<MusicViewer
					v-else-if="currentFile && currentFile.content"
					:file-content="currentFile.content"
					:file-name="currentFile.name" />
			</div>
		</NcAppContent>
	</NcContent>
</template>

<script>
import { ref, onMounted } from 'vue'
import axios from '@nextcloud/axios'
import { generateUrl } from '@nextcloud/router'
import { showError, showSuccess } from '@nextcloud/dialogs'
import { translate as t } from '@nextcloud/l10n'

import { NcContent, NcAppContent, NcAppNavigation, NcAppNavigationNew, NcAppNavigationItem, NcAppNavigationCaption, NcLoadingIcon } from '@nextcloud/vue'

import Plus from 'vue-material-design-icons/Plus.vue'
import FileMusic from 'vue-material-design-icons/FileMusic.vue'

import MusicViewer from './MusicViewer.vue'

export default {
	name: 'App',
	components: {
		NcContent,
		NcAppContent,
		NcAppNavigation,
		NcAppNavigationNew,
		NcAppNavigationItem,
		NcAppNavigationCaption,
		NcLoadingIcon,
		Plus,
		FileMusic,
		MusicViewer,
	},
	setup() {
		const musicFiles = ref([])
		const currentFile = ref(null)
		const loading = ref(false)

		const loadFiles = async () => {
			try {
				const response = await axios.get(generateUrl('/apps/musicxmlviewer/api/files'))
				musicFiles.value = response.data
			} catch (error) {
				showError(t('musicxmlviewer', 'Failed to load music files'))
				console.error(error)
			}
		}

		const loadFile = async (fileId) => {
			try {
				loading.value = true
				const response = await axios.get(generateUrl('/apps/musicxmlviewer/api/file/{fileId}', { fileId }))
				currentFile.value = {
					id: fileId,
					name: response.data.name,
					content: response.data.content,
					mimeType: response.data.mimeType,
					size: response.data.size
				}
			} catch (error) {
				showError(t('musicxmlviewer', 'Failed to load file'))
				console.error(error)
			} finally {
				loading.value = false
			}
		}

		const showFileUpload = () => {
			// Integrazione con file picker di Nextcloud
			if (window.OC && window.OC.dialogs) {
				window.OC.dialogs.filepicker(
					t('musicxmlviewer', 'Select MusicXML file'),
					(path) => {
						// Gestione del file selezionato
						showSuccess(t('musicxmlviewer', 'File selected: {path}', { path }))
						loadFiles() // Ricarica la lista
					},
					false,
					['xml', 'musicxml', 'mxl', 'mei'],
					true
				)
			} else {
				showError(t('musicxmlviewer', 'File picker not available'))
			}
		}

		onMounted(() => {
			loadFiles()
		})

		return {
			musicFiles,
			currentFile,
			loading,
			loadFile,
			showFileUpload,
			t,
		}
	},
}
</script>

<style scoped lang="scss">
.viewer-container {
	height: 100%;
	display: flex;
	flex-direction: column;
}

.empty-content,
.loading-content {
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	height: 100%;
	padding: 2rem;
	text-align: center;
}

.empty-content__icon {
	opacity: 0.5;
	margin-bottom: 1rem;
}

.empty-content h2,
.loading-content p {
	margin-top: 1rem;
}

.empty-content p {
	color: var(--color-text-maxcontrast);
}

.file-list {
	margin-top: 1rem;
}

:deep(.app-navigation-entry.active) {
	background-color: var(--color-primary-element-light);
}
</style>
