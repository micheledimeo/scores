<?php
return [
    'routes' => [
        ['name' => 'page#index', 'url' => '/', 'verb' => 'GET'],
        ['name' => 'api#getFile', 'url' => '/api/file/{fileId}', 'verb' => 'GET'],
        ['name' => 'api#listFiles', 'url' => '/api/files', 'verb' => 'GET'],
    ]
];
