// Advanced MusicXML Audio Parser
class MusicXMLAudioParser {
    constructor() {
        this.notes = [];
        this.tempo = 120;
        this.timeSignature = { numerator: 4, denominator: 4 };
        this.keySignature = 'C';
        this.measures = [];
    }

    parseXML(xmlContent) {
        try {
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(xmlContent, 'text/xml');
            
            console.log('🎼 Parsing MusicXML for audio playback...');
            
            // Parse basic info
            this.parseBasicInfo(xmlDoc);
            
            // Parse all parts
            const parts = xmlDoc.querySelectorAll('part');
            parts.forEach((part, partIndex) => {
                this.parsePart(part, partIndex);
            });
            
            console.log(`✅ Parsed ${this.notes.length} notes from ${parts.length} parts`);
            return this.notes;
            
        } catch (error) {
            console.error('❌ Error parsing MusicXML:', error);
            return [];
        }
    }

    parseBasicInfo(xmlDoc) {
        // Parse tempo
        const tempoNode = xmlDoc.querySelector('sound[tempo]');
        if (tempoNode) {
            this.tempo = parseInt(tempoNode.getAttribute('tempo'));
        }
        
        // Parse time signature
        const timeNode = xmlDoc.querySelector('time');
        if (timeNode) {
            const beats = timeNode.querySelector('beats')?.textContent;
            const beatType = timeNode.querySelector('beat-type')?.textContent;
            if (beats && beatType) {
                this.timeSignature = { numerator: parseInt(beats), denominator: parseInt(beatType) };
            }
        }
        
        // Parse key signature
        const keyNode = xmlDoc.querySelector('key');
        if (keyNode) {
            const fifths = keyNode.querySelector('fifths')?.textContent;
            if (fifths) {
                this.keySignature = this.fifthsToKey(parseInt(fifths));
            }
        }
        
        console.log(`🎵 Tempo: ${this.tempo} BPM, Time: ${this.timeSignature.numerator}/${this.timeSignature.denominator}, Key: ${this.keySignature}`);
    }

    parsePart(partElement, partIndex) {
        const measures = partElement.querySelectorAll('measure');
        let currentTime = 0;
        
        measures.forEach((measure, measureIndex) => {
            const measureNotes = this.parseMeasure(measure, measureIndex, currentTime, partIndex);
            this.notes.push(...measureNotes);
            
            // Calculate measure duration
            const quarterNotesInMeasure = this.timeSignature.numerator * (4 / this.timeSignature.denominator);
            const measureDuration = (quarterNotesInMeasure * 60) / this.tempo;
            currentTime += measureDuration;
        });
    }

    parseMeasure(measureElement, measureIndex, startTime, partIndex) {
        const notes = [];
        const noteElements = measureElement.querySelectorAll('note');
        let currentBeat = 0;
        
        noteElements.forEach(noteElement => {
            const noteData = this.parseNote(noteElement, measureIndex, startTime, currentBeat, partIndex);
            if (noteData) {
                notes.push(noteData);
                currentBeat += noteData.duration;
            }
        });
        
        return notes;
    }

    parseNote(noteElement, measureIndex, measureStartTime, currentBeat, partIndex) {
        // Skip if it's a rest
        if (noteElement.querySelector('rest')) {
            const duration = this.parseDuration(noteElement);
            return { type: 'rest', duration };
        }
        
        // Parse pitch
        const pitch = noteElement.querySelector('pitch');
        if (!pitch) return null;
        
        const step = pitch.querySelector('step')?.textContent;
        const octave = parseInt(pitch.querySelector('octave')?.textContent);
        const alter = parseInt(pitch.querySelector('alter')?.textContent || '0');
        
        if (!step || isNaN(octave)) return null;
        
        // Parse duration
        const duration = this.parseDuration(noteElement);
        const durationSeconds = (duration * 60) / (this.tempo * (this.timeSignature.denominator / 4));
        
        // Assicurati che la durata sia valida
        const validDurationSeconds = isNaN(durationSeconds) || durationSeconds <= 0 ? 0.5 : durationSeconds;
        
        // Calculate timing
        const beatDuration = 60 / this.tempo;
        const noteStartTime = measureStartTime + (currentBeat * beatDuration * (4 / this.timeSignature.denominator));
        
        // Assicurati che il timing sia valido
        const validStartTime = isNaN(noteStartTime) ? 0 : noteStartTime;
        
        // Parse dynamics
        const dynamics = this.parseDynamics(noteElement);
        
        // Convert to MIDI note
        const midiNote = this.pitchToMidi(step, octave, alter);
        
        return {
            type: 'note',
            pitch: step + alter + octave,
            midi: midiNote,
            octave,
            duration,
            durationSeconds: validDurationSeconds,
            startTime: validStartTime,
            endTime: validStartTime + validDurationSeconds,
            measure: measureIndex,
            part: partIndex,
            dynamics,
            velocity: this.dynamicsToVelocity(dynamics)
        };
    }

    parseDuration(noteElement) {
        const durationElement = noteElement.querySelector('duration');
        const typeElement = noteElement.querySelector('type');
        
        if (durationElement) {
            return parseInt(durationElement.textContent);
        } else if (typeElement) {
            // Convert note type to duration divisions
            const noteType = typeElement.textContent;
            const divisions = {
                'whole': 4,
                'half': 2,
                'quarter': 1,
                'eighth': 0.5,
                'sixteenth': 0.25,
                'thirty-second': 0.125
            };
            return divisions[noteType] || 1;
        }
        
        return 1; // Default quarter note
    }

    parseDynamics(noteElement) {
        // Look for dynamics in current measure
        const measure = noteElement.closest('measure');
        const dynamicsElement = measure?.querySelector('dynamics');
        
        if (dynamicsElement) {
            const dynamicTypes = ['pp', 'p', 'mp', 'mf', 'f', 'ff'];
            for (const type of dynamicTypes) {
                if (dynamicsElement.querySelector(type)) {
                    return type;
                }
            }
        }
        
        return 'mf'; // Default mezzo-forte
    }

    dynamicsToVelocity(dynamics) {
        const velocityMap = {
            'pp': 30,
            'p': 50,
            'mp': 70,
            'mf': 90,
            'f': 110,
            'ff': 127
        };
        return velocityMap[dynamics] || 90;
    }

    pitchToMidi(step, octave, alter = 0) {
        const noteValues = { 'C': 0, 'D': 2, 'E': 4, 'F': 5, 'G': 7, 'A': 9, 'B': 11 };
        const baseNote = noteValues[step];
        return (octave + 1) * 12 + baseNote + alter;
    }

    fifthsToKey(fifths) {
        const keys = ['C', 'G', 'D', 'A', 'E', 'B', 'F#', 'C#'];
        const flats = ['C', 'F', 'Bb', 'Eb', 'Ab', 'Db', 'Gb', 'Cb'];
        
        if (fifths >= 0) {
            return keys[Math.min(fifths, keys.length - 1)];
        } else {
            return flats[Math.min(Math.abs(fifths), flats.length - 1)];
        }
    }

    // Get notes for specific time range
    getNotesInRange(startTime, endTime) {
        return this.notes.filter(note => 
            note.type === 'note' && 
            note.startTime >= startTime && 
            note.startTime < endTime
        );
    }

    // Get total duration
    getTotalDuration() {
        if (this.notes.length === 0) return 60; // Default 1 minute
        
        const maxTime = Math.max(...this.notes.map(note => {
            const endTime = note.endTime || note.startTime;
            return isNaN(endTime) ? 0 : endTime;
        }));
        
        // Se ancora NaN, usa durata predefinita
        return isNaN(maxTime) || maxTime <= 0 ? 60 : maxTime;
    }
}

// Rendi la classe disponibile globalmente
window.MusicXMLAudioParser = MusicXMLAudioParser;
