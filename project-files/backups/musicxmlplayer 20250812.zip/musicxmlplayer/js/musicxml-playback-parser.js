/**
 * Enhanced MusicXML Parser for Real Playback
 * Extracts notes, timing, and musical structure from MusicXML
 */

class MusicXMLPlaybackParser {
    constructor() {
        this.divisions = 1; // Quarter note divisions
        this.tempo = 120; // Default BPM
        this.timeSignature = { beats: 4, beatType: 4 };
        this.keySignature = 0; // Number of sharps/flats
    }

    parseScore(xmlContent) {
        try {
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(xmlContent, 'text/xml');
            
            // Check for parsing errors
            const parserError = xmlDoc.querySelector('parsererror');
            if (parserError) {
                throw new Error('XML parsing failed: ' + parserError.textContent);
            }

            const scorePartwise = xmlDoc.querySelector('score-partwise');
            if (!scorePartwise) {
                throw new Error('Not a valid MusicXML score-partwise document');
            }

            // Extract global information
            this.extractGlobalInfo(xmlDoc);

            // Parse all parts
            const parts = this.parseParts(xmlDoc);
            
            console.log('🎼 Parsed MusicXML:', {
                tempo: this.tempo,
                timeSignature: this.timeSignature,
                keySignature: this.keySignature,
                divisions: this.divisions,
                parts: parts.length,
                totalNotes: parts.reduce((sum, part) => sum + part.notes.length, 0)
            });

            return {
                tempo: this.tempo,
                timeSignature: this.timeSignature,
                keySignature: this.keySignature,
                divisions: this.divisions,
                parts: parts
            };

        } catch (error) {
            console.error('❌ MusicXML parsing failed:', error);
            throw error;
        }
    }

    extractGlobalInfo(xmlDoc) {
        // Extract tempo from metronome marking
        const metronome = xmlDoc.querySelector('metronome');
        if (metronome) {
            const perMinute = metronome.querySelector('per-minute');
            if (perMinute) {
                this.tempo = parseInt(perMinute.textContent) || 120;
            }
        }

        // Extract tempo from direction/sound
        const sound = xmlDoc.querySelector('sound[tempo]');
        if (sound) {
            this.tempo = parseInt(sound.getAttribute('tempo')) || 120;
        }
    }

    parseParts(xmlDoc) {
        const parts = [];
        const partElements = xmlDoc.querySelectorAll('part');

        partElements.forEach((partElement, partIndex) => {
            const partId = partElement.getAttribute('id');
            const partName = this.getPartName(xmlDoc, partId);
            
            const notes = this.parsePartNotes(partElement);
            
            parts.push({
                id: partId,
                name: partName,
                index: partIndex,
                notes: notes
            });
        });

        return parts;
    }

    getPartName(xmlDoc, partId) {
        const scorePartList = xmlDoc.querySelector('part-list');
        if (scorePartList) {
            const scorePart = scorePartList.querySelector(`score-part[id="${partId}"]`);
            if (scorePart) {
                const partName = scorePart.querySelector('part-name');
                return partName ? partName.textContent : 'Unknown Part';
            }
        }
        return 'Part ' + partId;
    }

    parsePartNotes(partElement) {
        const notes = [];
        let currentTime = 0;
        
        const measures = partElement.querySelectorAll('measure');
        
        measures.forEach((measure, measureIndex) => {
            // Update attributes for this measure
            this.updateAttributesFromMeasure(measure);
            
            const measureNotes = this.parseMeasureNotes(measure, measureIndex, currentTime);
            notes.push(...measureNotes);
            
            // Update current time based on measure duration
            const measureDuration = this.getMeasureDuration(measure);
            currentTime += measureDuration;
        });

        return notes;
    }

    updateAttributesFromMeasure(measure) {
        const attributes = measure.querySelector('attributes');
        if (attributes) {
            // Update divisions
            const divisions = attributes.querySelector('divisions');
            if (divisions) {
                this.divisions = parseInt(divisions.textContent) || 1;
            }

            // Update time signature
            const time = attributes.querySelector('time');
            if (time) {
                const beats = time.querySelector('beats');
                const beatType = time.querySelector('beat-type');
                if (beats && beatType) {
                    this.timeSignature = {
                        beats: parseInt(beats.textContent),
                        beatType: parseInt(beatType.textContent)
                    };
                }
            }

            // Update key signature
            const key = attributes.querySelector('key');
            if (key) {
                const fifths = key.querySelector('fifths');
                if (fifths) {
                    this.keySignature = parseInt(fifths.textContent) || 0;
                }
            }
        }
    }

    parseMeasureNotes(measure, measureIndex, measureStartTime) {
        const notes = [];
        let currentMeasureTime = 0;

        const noteElements = measure.querySelectorAll('note');
        
        noteElements.forEach((noteElement, noteIndex) => {
            const noteData = this.parseNoteElement(noteElement, measureIndex, measureStartTime + currentMeasureTime);
            
            if (noteData) {
                notes.push(noteData);
                
                // Only advance time for non-chord notes
                if (!noteData.isChord) {
                    currentMeasureTime += noteData.durationInDivisions;
                }
            }
        });

        return notes;
    }

    parseNoteElement(noteElement, measureIndex, startTime) {
        // Check if it's a rest
        const rest = noteElement.querySelector('rest');
        if (rest) {
            const duration = this.getNoteDuration(noteElement);
            return {
                type: 'rest',
                measureIndex: measureIndex,
                startTime: startTime,
                durationInDivisions: duration,
                durationInSeconds: this.divisionsToSeconds(duration)
            };
        }

        // Check if it's part of a chord
        const chord = noteElement.querySelector('chord');
        const isChord = !!chord;

        // Get pitch information
        const pitch = noteElement.querySelector('pitch');
        if (!pitch) return null;

        const step = pitch.querySelector('step').textContent;
        const octave = parseInt(pitch.querySelector('octave').textContent);
        const alter = pitch.querySelector('alter');
        const alteration = alter ? parseInt(alter.textContent) : 0;

        // Get duration
        const duration = this.getNoteDuration(noteElement);
        const durationInSeconds = this.divisionsToSeconds(duration);

        // Get velocity (dynamics)
        const velocity = this.getNoteVelocity(noteElement);

        // Convert to our note format
        const noteName = this.createNoteName(step, octave, alteration);

        console.log(`🎵 Parsed note: ${noteName}, duration: ${duration} divisions (${durationInSeconds.toFixed(3)}s), velocity: ${velocity}`);

        return {
            type: 'note',
            measureIndex: measureIndex,
            startTime: startTime,
            durationInDivisions: duration,
            durationInSeconds: durationInSeconds,
            pitch: {
                step: step,
                octave: octave,
                alteration: alteration
            },
            noteName: noteName,
            velocity: velocity,
            isChord: isChord
        };
    }

    getNoteDuration(noteElement) {
        const duration = noteElement.querySelector('duration');
        return duration ? parseInt(duration.textContent) : this.divisions;
    }

    getNoteVelocity(noteElement) {
        // Check for dynamics markings
        const dynamics = noteElement.querySelector('dynamics');
        if (dynamics) {
            // Map dynamics to velocity values
            if (dynamics.querySelector('pp')) return 0.3;
            if (dynamics.querySelector('p')) return 0.4;
            if (dynamics.querySelector('mp')) return 0.5;
            if (dynamics.querySelector('mf')) return 0.6;
            if (dynamics.querySelector('f')) return 0.7;
            if (dynamics.querySelector('ff')) return 0.8;
            if (dynamics.querySelector('fff')) return 0.9;
        }
        
        return 0.7; // Default velocity
    }

    createNoteName(step, octave, alteration) {
        let noteName = step;
        
        if (alteration > 0) {
            // Sharp
            noteName += '#'.repeat(alteration);
        } else if (alteration < 0) {
            // Flat - convert to flat notation
            noteName += 'b'.repeat(Math.abs(alteration));
        }
        
        return noteName + octave;
    }

    getMeasureDuration(measure) {
        // Calculate total duration of measure in divisions
        const notes = measure.querySelectorAll('note');
        let maxTime = 0;
        let currentTime = 0;

        notes.forEach(note => {
            const chord = note.querySelector('chord');
            if (!chord) {
                const duration = this.getNoteDuration(note);
                currentTime += duration;
                maxTime = Math.max(maxTime, currentTime);
            }
        });

        // If no notes, use time signature
        if (maxTime === 0) {
            maxTime = this.divisions * this.timeSignature.beats * (4 / this.timeSignature.beatType);
        }

        return maxTime;
    }

    divisionsToSeconds(divisions) {
        // Convert divisions to seconds based on tempo
        // divisions per quarter note, tempo in quarter notes per minute
        const quarterNotesPerSecond = this.tempo / 60;
        const secondsPerQuarterNote = 1 / quarterNotesPerSecond;
        const secondsPerDivision = secondsPerQuarterNote / this.divisions;
        return divisions * secondsPerDivision;
    }

    // Create a playback sequence that combines all parts
    createPlaybackSequence(parsedScore) {
        const sequence = [];
        
        // Combine all parts into a single sequence
        parsedScore.parts.forEach((part, partIndex) => {
            console.log(`🎼 Processing part ${partIndex + 1}: ${part.name} (${part.notes.length} notes)`);
            
            part.notes.forEach(note => {
                if (note.type === 'note') {
                    sequence.push({
                        noteName: note.noteName,
                        startTime: note.startTime * (60 / this.tempo / this.divisions),
                        duration: note.durationInSeconds,
                        velocity: note.velocity * (partIndex === 0 ? 1.0 : 0.8), // Slightly quieter for harmony parts
                        measureIndex: note.measureIndex,
                        partIndex: partIndex,
                        partName: part.name,
                        isChord: note.isChord
                    });
                }
            });
        });

        // Sort by start time to ensure proper playback order
        sequence.sort((a, b) => a.startTime - b.startTime);
        
        console.log(`🎵 Created playback sequence: ${sequence.length} notes from ${parsedScore.parts.length} parts`);
        
        return sequence;
    }
}

// Export for global use
window.MusicXMLPlaybackParser = MusicXMLPlaybackParser;
