// MusicXML Player - Simplified Layout Version
class MusicXMLPlayer {
    constructor() {
        this.osmd = null;
        this.currentFile = null;
        this.currentTempo = 120;
        this.audioEngine = null;
        this.isPlaying = false;
        this.cursor = null;
        this.animationFrame = null;
        this.parsedScore = null; // Stores parsed MusicXML data
        this.playbackSequence = null; // Stores playback sequence
        this.parser = null; // MusicXML parser instance
        this.visualCursor = null; // Visual cursor for playback
        this.currentNoteIndex = 0; // Track current note in sequence
        
        // Initialize translations first
        this.initializeTranslations();
        
        // Then detect language
        this.currentLanguage = this.detectLanguage();
    }

    initializeTranslations() {
        // Localization strings
        this.translations = {
            en: {
                welcomeTitle: "Welcome to MusicXML Player",
                quickGuide: "Quick Start Guide:",
                selectFile: "Select a music file from the library on the left",
                viewSheet: "View your sheet music with professional rendering", 
                playAudio: "Play audio with synchronized score highlighting",
                controlPlayback: "Control playback with professional transport controls",
                adjustTempo: "Adjust tempo and volume for practice sessions",
                chooseFile: "Choose a file from the library to begin your musical journey ✨"
            },
            it: {
                welcomeTitle: "Benvenuto in MusicXML Player",
                quickGuide: "Guida Rapida:",
                selectFile: "Seleziona un file musicale dalla libreria a sinistra",
                viewSheet: "Visualizza il tuo spartito con rendering professionale",
                playAudio: "Riproduci l'audio con evidenziazione sincronizzata dello spartito",
                controlPlayback: "Controlla la riproduzione con controlli di trasporto professionali",
                adjustTempo: "Regola tempo e volume per le sessioni di pratica",
                chooseFile: "Scegli un file dalla libreria per iniziare il tuo viaggio musicale ✨"
            },
            es: {
                welcomeTitle: "Bienvenido a MusicXML Player",
                quickGuide: "Guía Rápida:",
                selectFile: "Selecciona un archivo musical de la biblioteca de la izquierda",
                viewSheet: "Ve tu partitura con renderizado profesional",
                playAudio: "Reproduce audio con resaltado sincronizado de la partitura",
                controlPlayback: "Controla la reproducción con controles de transporte profesionales",
                adjustTempo: "Ajusta tempo y volumen para sesiones de práctica",
                chooseFile: "Elige un archivo de la biblioteca para comenzar tu viaje musical ✨"
            },
            de: {
                welcomeTitle: "Willkommen bei MusicXML Player",
                quickGuide: "Schnellstartanleitung:",
                selectFile: "Wählen Sie eine Musikdatei aus der Bibliothek links",
                viewSheet: "Betrachten Sie Ihre Noten mit professionellem Rendering",
                playAudio: "Audio mit synchronisierter Noten-Hervorhebung abspielen",
                controlPlayback: "Wiedergabe mit professionellen Transport-Kontrollen steuern",
                adjustTempo: "Tempo und Lautstärke für Übungssitzungen anpassen",
                chooseFile: "Wählen Sie eine Datei aus der Bibliothek, um Ihre musikalische Reise zu beginnen ✨"
            }
        };
        
        console.log('🌍 Translations initialized with languages:', Object.keys(this.translations));
    }

    detectLanguage() {
        // Get browser language
        const browserLang = navigator.language || navigator.userLanguage || 'en';
        const langCode = browserLang.split('-')[0].toLowerCase();
        
        // Check if we have translation for this language
        if (this.translations[langCode]) {
            console.log('🌍 Detected language:', langCode, '(' + browserLang + ')');
            return langCode;
        }
        
        // Fallback to English
        console.log('🌍 Language not supported:', langCode, '- using English');
        return 'en';
    }

    getTranslation(key) {
        // Safety check
        if (!this.translations || !this.currentLanguage) {
            console.warn('⚠️ Translations not initialized, returning key:', key);
            return key;
        }
        
        return this.translations[this.currentLanguage]?.[key] || 
               this.translations['en']?.[key] || 
               key;
    }

    localizeWelcomeGuide() {
        try {
            console.log('🌍 Localizing welcome guide to:', this.currentLanguage);
            
            // Update welcome title
            const welcomeTitle = document.getElementById('welcome-title');
            if (welcomeTitle) {
                welcomeTitle.textContent = this.getTranslation('welcomeTitle');
            }
            
            // Update quick guide title
            const quickGuideTitle = document.getElementById('quick-guide-title');
            if (quickGuideTitle) {
                quickGuideTitle.textContent = this.getTranslation('quickGuide');
            }
            
            // Update guide steps
            const guideElements = [
                { id: 'guide-select-file', key: 'selectFile' },
                { id: 'guide-view-sheet', key: 'viewSheet' },
                { id: 'guide-play-audio', key: 'playAudio' },
                { id: 'guide-control-playback', key: 'controlPlayback' },
                { id: 'guide-adjust-tempo', key: 'adjustTempo' }
            ];
            
            guideElements.forEach(element => {
                const domElement = document.getElementById(element.id);
                if (domElement) {
                    domElement.textContent = this.getTranslation(element.key);
                }
            });
            
            // Update choose file text
            const chooseFile = document.getElementById('guide-choose-file');
            if (chooseFile) {
                chooseFile.textContent = this.getTranslation('chooseFile');
            }
            
            console.log('✅ Welcome guide localized successfully');
            
        } catch (error) {
            console.warn('⚠️ Localization failed:', error);
        }
    }

    setupLanguageSelector() {
        const languageSelector = document.getElementById('language-selector');
        if (!languageSelector) {
            console.warn('⚠️ Language selector not found in DOM');
            return;
        }
        
        if (!this.translations || !this.currentLanguage) {
            console.warn('⚠️ Translations not initialized, skipping language selector setup');
            return;
        }
        
        // Set current language as selected
        languageSelector.value = this.currentLanguage;
        
        // Add change event listener
        languageSelector.addEventListener('change', (e) => {
            const newLanguage = e.target.value;
            if (this.translations[newLanguage]) {
                this.currentLanguage = newLanguage;
                this.localizeWelcomeGuide();
                console.log('🌍 Language changed to:', newLanguage);
                
                // Save preference to localStorage
                try {
                    localStorage.setItem('musicxml-player-language', newLanguage);
                } catch (error) {
                    console.warn('Could not save language preference:', error);
                }
            }
        });
        
        console.log('✅ Language selector initialized');
    }

    detectLanguage() {
        // Safety check - ensure translations are initialized
        if (!this.translations) {
            console.warn('⚠️ Translations not initialized, defaulting to English');
            return 'en';
        }
        
        // Check for saved preference first
        try {
            const savedLang = localStorage.getItem('musicxml-player-language');
            if (savedLang && this.translations[savedLang]) {
                console.log('🌍 Using saved language preference:', savedLang);
                return savedLang;
            }
        } catch (error) {
            console.warn('Could not load language preference:', error);
        }
        
        // Get browser language
        const browserLang = navigator.language || navigator.userLanguage || 'en';
        const langCode = browserLang.split('-')[0].toLowerCase();
        
        // Check if we have translation for this language
        if (this.translations[langCode]) {
            console.log('🌍 Detected browser language:', langCode, '(' + browserLang + ')');
            return langCode;
        }
        
        // Fallback to English
        console.log('🌍 Language not supported:', langCode, '- using English');
        return 'en';
    }

    async initializeSimpleAudio() {
        try {
            // Initialize Simple Audio Engine (replaces Tone.js)
            if (typeof SimpleAudioEngine !== 'undefined') {
                console.log('🎹 Initializing Simple Audio Engine...');
                this.audioEngine = new SimpleAudioEngine();
                const success = await this.audioEngine.initialize();
                if (success) {
                    console.log('✅ Simple Audio Engine configured successfully');
                } else {
                    console.error('❌ Simple Audio Engine initialization failed');
                }
            } else {
                console.error('❌ SimpleAudioEngine class not available - check if script is loaded');
            }
        } catch (error) {
            console.error('❌ Simple Audio Engine initialization failed:', error);
        }
    }

    async init() {
        try {
            console.log('🎼 Initializing Advanced MusicXML Player...');
            
            // Check dependencies
            console.log('🔍 Checking dependencies:');
            console.log('- SimpleAudioEngine:', typeof SimpleAudioEngine !== 'undefined' ? '✅' : '❌');
            console.log('- MusicXMLPlaybackParser:', typeof MusicXMLPlaybackParser !== 'undefined' ? '✅' : '❌');
            console.log('- OpenSheetMusicDisplay:', typeof window.opensheetmusicdisplay !== 'undefined' ? '✅' : '❌');
            
            // Initialize Simple Audio Engine with CSP-safe configuration
            await this.initializeSimpleAudio();
            
            // Initialize MusicXML parser
            if (typeof MusicXMLPlaybackParser !== 'undefined') {
                this.parser = new MusicXMLPlaybackParser();
                console.log('✅ MusicXML Playback Parser initialized');
            } else {
                console.warn('⚠️ MusicXML Playback Parser not available');
            }
            
            // Initialize simplified layout
            this.initializeHomeLayout();
            
            this.loadUserPreferences();
            await this.loadFileList();
            this.setupEventListeners();
            this.setupKeyboardShortcuts();
            
            // Show welcome guide initially
            this.showWelcomeGuide(true);
            this.showScoreContainer(false);
            
            // Debug: Check if score-area exists
            const scoreArea = document.getElementById('score-area');
            console.log('🔍 Score area check at init:', scoreArea ? 'Found' : 'NOT FOUND');
            if (scoreArea) {
                console.log('📊 Score area element:', scoreArea);
            }
            
            // Localize the welcome guide
            this.localizeWelcomeGuide();
            
            // Setup language selector
            this.setupLanguageSelector();
            
            console.log('✨ Advanced MusicXML Player initialized successfully');
            
            // Make test method available globally for debugging
            window.testCursor = () => {
                if (this.testCursor) {
                    this.testCursor();
                } else {
                    console.log('❌ testCursor method not available');
                }
            };
            
            // Add emergency cursor creation
            window.createCursor = () => {
                console.log('🚨 Emergency cursor creation...');
                if (this.createVisualCursor) {
                    this.createVisualCursor();
                } else {
                    console.log('❌ createVisualCursor method not available');
                }
            };
            
            console.log('🧪 Debug: Type "testCursor()" or "createCursor()" in console');
            
        } catch (error) {
            console.error('❌ Error initializing player:', error);
            this.showNotification('⚠️ Failed to initialize player', 'error');
        }
    }

    initializeHomeLayout() {
        // Hide only Nextcloud sidebar (NOT header)
        const navigation = document.getElementById('app-navigation');
        if (navigation) {
            navigation.style.display = 'none';
        }
        
        // Make content full width but preserve header
        const content = document.getElementById('app-content');
        if (content) {
            content.style.marginLeft = '0';
            content.style.width = '100%';
        }
    }

    async loadFileList() {
        try {
            console.log('🔍 Loading file list...');
            const url = OC.generateUrl('/apps/musicxmlplayer/files');
            console.log('API URL:', url);
            
            const response = await fetch(url);
            console.log('Response status:', response.status, response.statusText);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            console.log('API Response:', data);
            console.log('Files loaded:', data.files?.length, 'files');
            
            // Handle different response formats
            const files = data.files || data || [];
            
            // Update files list in the column
            const filesContainer = document.getElementById('files-list-container');
            const emptyFiles = document.getElementById('empty-files');
            
            if (!filesContainer) {
                console.error('❌ Files container not found');
                return;
            }
            
            filesContainer.innerHTML = '';
            
            if (files.length === 0) {
                console.log('📂 No MusicXML files found');
                if (emptyFiles) emptyFiles.style.display = 'block';
                return;
            }
            
            if (emptyFiles) emptyFiles.style.display = 'none';
            
            console.log('✅ Rendering', files.length, 'files');
            
            // Add files to list
            files.forEach(file => {
                const item = document.createElement('div');
                item.className = 'file-list-item';
                item.style.cssText = `
                    background: #ffffff;
                    border: 1px solid rgba(226, 232, 240, 0.8);
                    border-radius: 8px;
                    padding: 12px 14px;
                    cursor: pointer;
                    transition: all 0.2s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                    color: #374151;
                    font-weight: 500;
                    font-size: 13px;
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
                    margin-bottom: 6px;
                `;
                
                item.innerHTML = `
                    <div style="
                        width: 32px;
                        height: 32px;
                        background: linear-gradient(135deg, #f97316 0%, #ea580c 100%);
                        border-radius: 6px;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        font-size: 14px;
                        flex-shrink: 0;
                    ">🎵</div>
                    <div style="flex: 1; min-width: 0;">
                        <div style="
                            font-weight: 600;
                            color: #1e293b;
                            white-space: nowrap;
                            overflow: hidden;
                            text-overflow: ellipsis;
                            font-size: 13px;
                        " title="${file.name}">${file.name}</div>
                        <div style="
                            font-size: 11px;
                            color: #94a3b8;
                            margin-top: 2px;
                        ">MusicXML</div>
                    </div>
                `;
                
                // Add hover effects
                item.addEventListener('mouseenter', () => {
                    item.style.backgroundColor = '#f8fafc';
                    item.style.transform = 'translateX(4px)';
                    item.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.08)';
                    item.style.borderColor = 'rgba(99, 102, 241, 0.3)';
                });
                
                item.addEventListener('mouseleave', () => {
                    if (!item.classList.contains('active')) {
                        item.style.backgroundColor = '#ffffff';
                        item.style.transform = 'translateX(0)';
                        item.style.boxShadow = '0 1px 3px rgba(0, 0, 0, 0.05)';
                        item.style.borderColor = 'rgba(226, 232, 240, 0.8)';
                    }
                });
                
                // Add click handler
                item.addEventListener('click', () => {
                    console.log('🎵 Loading file:', file.name);
                    // Remove active class from other items
                    document.querySelectorAll('.file-list-item').forEach(i => {
                        i.classList.remove('active');
                        i.style.background = '#ffffff';
                        i.style.color = '#374151';
                        i.style.transform = 'translateX(0)';
                        i.style.borderColor = 'rgba(226, 232, 240, 0.8)';
                    });
                    
                    // Add active class to clicked item
                    item.classList.add('active');
                    item.style.background = 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)';
                    item.style.color = 'white';
                    item.style.borderColor = 'rgba(99, 102, 241, 0.5)';
                    item.style.transform = 'translateX(6px)';
                    
                    this.loadFile(file);
                });
                
                filesContainer.appendChild(item);
            });
            
            console.log('✅ Files populated in list:', files.length, 'files');
            
        } catch (error) {
            console.error('❌ Error loading file list:', error);
            const filesContainer = document.getElementById('files-list-container');
            if (filesContainer) {
                filesContainer.innerHTML = `
                    <div style="
                        text-align: center; 
                        padding: 20px; 
                        color: #ef4444;
                        background: #fef2f2;
                        border-radius: 8px;
                        border: 1px solid #fecaca;
                    ">
                        <div style="font-size: 24px; margin-bottom: 10px;">⚠️</div>
                        <div style="font-weight: 600; margin-bottom: 5px;">Error loading files</div>
                        <div style="font-size: 12px; color: #991b1b;">${error.message}</div>
                    </div>
                `;
            }
        }
    }

    setupEventListeners() {
        // No special event listeners needed for file list
        // Click handlers are added during file list population
    }

    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            switch(e.key) {
                case ' ':
                    e.preventDefault();
                    if (this.isPlaying) {
                        this.pausePlayback();
                    } else {
                        this.startPlayback();
                    }
                    break;
                case 'Escape':
                    this.closeOverlay();
                    break;
            }
        });
    }

    async loadFile(file) {
        try {
            console.log('Loading file:', file);
            this.currentFile = file;
            
            // Hide welcome guide FIRST and show score container
            this.showWelcomeGuide(false);
            this.showScoreContainer(true);
            
            this.showLoading(true);
            this.updateBreadcrumb(file.name);
            
            // Use the correct API endpoint for file content
            const response = await fetch(OC.generateUrl('/apps/musicxmlplayer/file/{fileId}', {fileId: file.id}));
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            console.log('File data received');
            
            // Load score directly in the score container
            console.log('📱 Loading score in score container');
            await this.loadScoreInContainer(data.content, file.name);
            
        } catch (error) {
            console.error('Error loading file:', error);
            this.showLoading(false);
            this.showNotification('Error loading file: ' + error.message, 'error');
            
            // Show welcome guide again if error
            this.showWelcomeGuide(true);
            this.showScoreContainer(false);
        }
    }

    async loadScoreInContainer(xmlContent, filename) {
        try {
            console.log('🎼 Loading score with OSMD Cursor API...');
            
            // Clean up previous OSMD instance
            if (this.osmd) {
                try {
                    this.osmd.clear();
                    this.osmd = null;
                } catch (e) {
                    console.warn('Error cleaning up previous OSMD instance:', e);
                }
            }
            
            // Get the existing OSMD container
            const container = document.getElementById('osmd-container');
            if (!container) {
                console.error('OSMD container not found');
                return;
            }
            
            // Clear existing content
            container.innerHTML = '';
            
            // Set up container styles
            container.style.cssText = `
                width: 100% !important;
                height: calc(100vh - 140px) !important;
                background: #ffffff !important;
                padding: 20px !important;
                overflow: auto !important;
                box-sizing: border-box !important;
                display: block !important;
            `;
            
            // Check OSMD library
            if (typeof window.opensheetmusicdisplay === 'undefined') {
                console.error('OpenSheetMusicDisplay library not loaded');
                return;
            }
            
            console.log('✅ OSMD library loaded, creating instance with cursor...');
            
            // Create OSMD instance with OFFICIAL CURSOR SUPPORT
            this.osmd = new window.opensheetmusicdisplay.OpenSheetMusicDisplay(container, {
                autoResize: true,
                backend: 'svg',
                drawTitle: true,
                drawComposer: true,
                drawCredits: false,
                drawPartNames: true,
                coloringMode: 0,
                pageFormat: 'Endless',
                pageBackgroundColor: '#FFFFFF',
                renderSingleHorizontalStaffline: false,
                
                // OFFICIAL CURSOR CONFIGURATION
                cursorsOptions: [{
                    type: 0, // Standard cursor
                    color: '#ef4444', // Red color
                    alpha: 0.8,
                    follow: true
                }]
            });
            
            console.log('✅ OSMD instance created with cursor, loading XML...');
            
            // Load and render
            await this.osmd.load(xmlContent);
            console.log('✅ XML loaded, rendering score...');
            
            // Parse for playback
            await this.parseMusicXMLForPlayback(xmlContent);
            
            // Set zoom and render
            this.osmd.zoom = 1.1;
            await this.osmd.render();
            console.log('✅ Score rendered successfully!');
            
            // Initialize OSMD cursor system
            this.initializeOSMDCursor();
            
            // Setup playback synchronization
            this.setupPlaybackWithOSMDCursor();
            
            // Create transport controls
            if (!document.querySelector('.transport-controls')) {
                console.log('🎛️ Creating transport controls...');
                this.createTransportControls();
            }
            
            // Initialize OSMD cursor system
            this.initializeOSMDCursor();
            
            // Setup playback synchronization
            this.setupPlaybackWithOSMDCursor();
            
            // Initialize audio engine if needed
            await this.initializeAdvancedAudio();
            
            // Re-initialize Simple Audio Engine if not available
            if (!this.audioEngine || !this.audioEngine.isInitialized) {
                console.log('🎹 Re-initializing Simple Audio Engine...');
                await this.initializeSimpleAudio();
            }
            
            // Don't create transport controls here - wait until first file is loaded
            
            this.showLoading(false);
            
        } catch (error) {
            console.error('❌ Error loading score in container:', error);
            this.showLoading(false);
            this.showNotification('Error rendering score: ' + error.message, 'error');
        }
    }

    // Initialize OSMD's built-in cursor system
    initializeOSMDCursor() {
        try {
            console.log('🎯 Initializing OSMD cursor system...');
            
            if (this.osmd && this.osmd.cursor) {
                console.log('✅ OSMD cursor available');
                
                // Reset cursor to beginning
                this.osmd.cursor.reset();
                
                // Show the cursor
                this.osmd.cursor.show();
                
                // Store reference
                this.cursor = this.osmd.cursor;
                
                console.log('✅ OSMD cursor initialized and visible');
                
            } else if (this.osmd && this.osmd.Sheet) {
                // Try alternative cursor initialization
                console.log('🔄 Trying alternative cursor initialization...');
                
                // Create cursor using Sheet's iterator
                this.cursor = this.osmd.Sheet.getIterator();
                if (this.cursor) {
                    this.cursor.reset();
                    console.log('✅ Alternative cursor created');
                }
                
            } else {
                console.warn('⚠️ OSMD cursor not available in this version');
                // Keep existing custom cursor as fallback
                console.log('🔄 Using existing custom cursor system');
            }
            
        } catch (error) {
            console.error('❌ OSMD cursor initialization failed:', error);
            console.log('🔄 Falling back to existing cursor system');
        }
    }

    // Setup playback synchronization with OSMD cursor
    setupPlaybackWithOSMDCursor() {
        console.log('🎵 Setting up playback with OSMD cursor sync...');
        
        // Check for OSMD PlaybackManager
        if (this.osmd && this.osmd.PlaybackManager) {
            console.log('🎹 Using OSMD PlaybackManager');
            this.playbackManager = this.osmd.PlaybackManager;
            this.setupOSMDPlaybackEvents();
        } else {
            console.log('🎹 Enhancing custom playback with OSMD cursor sync');
            this.setupCustomPlaybackWithOSMDSync();
        }
    }

    // Setup custom playback with OSMD cursor synchronization
    setupCustomPlaybackWithOSMDSync() {
        console.log('🔄 Enhancing custom playback with OSMD cursor sync');
        
        // Store original playback method
        if (this.startPlayback && !this.originalStartPlayback) {
            this.originalStartPlayback = this.startPlayback;
            
            // Enhance existing playback with OSMD cursor sync
            this.startPlayback = this.startPlaybackWithOSMDSync.bind(this);
        }
    }

    // Enhanced playback with OSMD cursor synchronization
    async startPlaybackWithOSMDSync() {
        console.log('🎵 Starting playback with OSMD cursor sync...');
        
        try {
            // Initialize OSMD cursor at the beginning
            if (this.cursor && this.cursor.reset) {
                this.cursor.reset();
                console.log('🎯 OSMD cursor reset to beginning');
            }
            
            // Start the original playback system
            if (this.originalStartPlayback) {
                await this.originalStartPlayback();
            } else {
                console.warn('⚠️ Original startPlayback method not found');
            }
            
        } catch (error) {
            console.error('❌ Playback with OSMD sync failed:', error);
        }
    }

    // Update OSMD cursor position during playback (called from existing playback system)
    updateOSMDCursorPosition(currentTime) {
        if (!this.cursor) return;
        
        try {
            // Find current position in the score
            const noteIndex = this.findNoteIndexAtTime(currentTime);
            
            if (noteIndex >= 0 && this.cursor.move) {
                // Use OSMD's move method if available
                this.cursor.move(Math.floor(noteIndex / 4), noteIndex % 4);
                console.log(`🎯 OSMD cursor moved to index ${noteIndex} (time ${currentTime.toFixed(2)}s)`);
            } else if (this.cursor.next) {
                // Alternative: use iterative movement
                this.moveOSMDCursorIteratively(currentTime);
            }
            
        } catch (error) {
            console.warn('⚠️ OSMD cursor update failed:', error);
        }
    }

    // Find note index at specific time
    findNoteIndexAtTime(currentTime) {
        if (!this.playbackSequence) return -1;
        
        for (let i = 0; i < this.playbackSequence.length; i++) {
            const note = this.playbackSequence[i];
            const noteTime = note.startTime || 0;
            
            // Find the note closest to current time
            if (Math.abs(noteTime - currentTime) < 0.1) {
                return i;
            }
        }
        
        return -1;
    }

    // Move OSMD cursor iteratively to match playback time
    moveOSMDCursorIteratively(targetTime) {
        if (!this.cursor || !this.cursor.next) return;
        
        // This is a simplified approach - in practice you'd need more sophisticated timing
        const estimatedBeats = Math.floor(targetTime * 2); // Rough estimate: 2 beats per second
        
        // Reset and move forward
        this.cursor.reset();
        for (let i = 0; i < estimatedBeats && this.cursor.hasNext; i++) {
            this.cursor.next();
        }
    }

    async parseMusicXMLForPlayback(xmlContent) {
        try {
            if (!this.parser) {
                console.warn('⚠️ MusicXML parser not available');
                return;
            }

            console.log('🎼 Parsing MusicXML for playback...');
            
            // Parse the score
            this.parsedScore = this.parser.parseScore(xmlContent);
            
            // Create playback sequence
            this.playbackSequence = this.parser.createPlaybackSequence(this.parsedScore);
            
            // Update tempo in audio engine
            if (this.audioEngine) {
                this.audioEngine.setTempo(this.parsedScore.tempo);
                this.currentTempo = this.parsedScore.tempo;
            }
            
            console.log('✅ MusicXML parsed for playback:', {
                notes: this.playbackSequence.length,
                tempo: this.parsedScore.tempo,
                parts: this.parsedScore.parts.length
            });
            
            // Update tempo display if available
            const tempoInput = document.querySelector('.tempo-input');
            if (tempoInput) {
                tempoInput.value = this.parsedScore.tempo.toString();
            }
            
        } catch (error) {
            console.error('❌ Failed to parse MusicXML for playback:', error);
            this.showNotification('⚠️ Could not parse score for playback', 'error');
        }
    }

    initializePlaybackCursor() {
        console.log('🎯 initializePlaybackCursor called');
        
        if (!this.osmd) {
            console.warn('⚠️ OSMD not available for cursor');
            return;
        }
        
        try {
            // Create a simple visual cursor instead of relying on OSMD's complex cursor
            console.log('🎯 About to call createVisualCursor...');
            this.createVisualCursor();
            console.log('✅ Visual playback cursor initialized successfully');
        } catch (error) {
            console.error('❌ Cursor initialization failed:', error);
        }
    }

    createVisualCursor() {
        console.log('🎯 Creating visual cursor...');
        
        // Remove existing cursor
        const existingCursor = document.querySelector('.visual-playback-cursor');
        if (existingCursor) {
            existingCursor.remove();
            console.log('🗑️ Removed existing cursor');
        }

        // Find score container
        const scoreContainer = document.getElementById('score-container');
        console.log('📍 Score container found:', scoreContainer ? 'YES' : 'NO');
        
        if (!scoreContainer) {
            console.error('❌ Score container not found - cannot create cursor');
            console.log('🔍 Available containers:', {
                'score-area': !!document.getElementById('score-area'),
                'score-container': !!document.getElementById('score-container'),
                'containers with score': document.querySelectorAll('[id*="score"]').length
            });
            
            // Try to use score-area as fallback
            const scoreArea = document.getElementById('score-area');
            if (scoreArea) {
                console.log('🔄 Using score-area as fallback...');
                this.createCursorInContainer(scoreArea);
                return;
            }
            return;
        }

        this.createPreciseCursor(scoreContainer);
    }

    // Get basic score geometry (simplified approach)
    getScoreGeometry() {
        const info = {
            staffCount: 2, // Default for Bella Ciao
            firstMeasureX: 210, // Measured position for first beat
            staffHeight: 45,
            staffSpacing: 85,
            systemTop: 160,
            totalScoreWidth: 1000
        };

        // Try to get basic info from OSMD if available
        try {
            if (this.osmd && this.osmd.graphic) {
                console.log('📊 Using OSMD for basic staff count');
                
                // Get number of staves (most reliable OSMD info)
                if (this.osmd.graphic.MusicSystems && this.osmd.graphic.MusicSystems.length > 0) {
                    const firstSystem = this.osmd.graphic.MusicSystems[0];
                    if (firstSystem.StaffLines) {
                        info.staffCount = firstSystem.StaffLines.length;
                        console.log(`✅ OSMD detected ${info.staffCount} staves`);
                    }
                }
            }
        } catch (error) {
            console.warn('⚠️ OSMD basic info failed, using defaults');
        }

        console.log('📊 Score geometry:', info);
        return info;
    }

    createPreciseCursor(container) {
        console.log('🎯 Creating precise cursor...');
        
        // Get precise score dimensions
        const scoreInfo = this.getScoreGeometry();
        
        // Calculate precise cursor dimensions
        const cursorHeight = this.calculateInitialCursorHeight(scoreInfo);
        const cursorTop = scoreInfo.systemTop;
        const cursorLeft = scoreInfo.firstMeasureX;
        
        // Create visual cursor line
        const cursor = document.createElement('div');
        cursor.className = 'visual-playback-cursor';
        cursor.id = 'playback-cursor';
        
        // Precise styling based on actual score geometry
        cursor.style.cssText = `
            position: absolute !important;
            top: ${cursorTop}px !important;
            left: ${cursorLeft}px !important;
            width: 2px !important;
            height: ${cursorHeight}px !important;
            background: linear-gradient(to bottom, #ef4444 0%, #dc2626 50%, #b91c1c 100%) !important;
            border-radius: 1px !important;
            z-index: 99999 !important;
            pointer-events: none !important;
            opacity: 0.7 !important;
            transition: left 0.05s ease-out, height 0.2s ease-out !important;
            box-shadow: 0 0 4px rgba(239, 68, 68, 0.8) !important;
            display: block !important;
        `;

        // Add to score container
        container.appendChild(cursor);
        this.visualCursor = cursor;
        
        // Store score geometry for movement calculations
        this.scoreGeometry = scoreInfo;
        
        console.log('✅ Precise cursor created:', {
            position: `${cursorLeft}px, ${cursorTop}px`,
            height: `${cursorHeight}px`,
            staffCount: scoreInfo.staffCount
        });
    }

    // Calculate initial cursor height based on TOTAL number of staves (FIXED HEIGHT)
    calculateInitialCursorHeight(scoreInfo) {
        const staffHeight = 40; // Height of one staff
        const staffSpacing = scoreInfo.staffSpacing || 80; // Space between staves from OSMD
        
        // ALWAYS cover ALL staves in the score (fixed height, not dynamic)
        const totalStaves = scoreInfo.staffCount;
        
        if (totalStaves <= 1) {
            return staffHeight; // Single staff
        } else {
            // Multiple staves: cover all staves plus spacing
            const totalHeight = (totalStaves * staffHeight) + ((totalStaves - 1) * staffSpacing);
            console.log(`📏 Fixed cursor height: ${totalHeight}px for ${totalStaves} staves`);
            return totalHeight;
        }
    }

    // Simple but precise cursor positioning (no complex OSMD calculations)
    calculatePreciseCursorPosition(note, index) {
        const currentTime = note.startTime || 0;
        const totalDuration = this.getSequenceDuration();
        
        // Simple musical progress (0.0 to 1.0) - REAL TIME, NO ACCELERATION
        const musicalProgress = totalDuration > 0 ? currentTime / totalDuration : 0;
        
        // Get score container for width calculation
        const scoreContainer = document.getElementById('score-container');
        const containerWidth = scoreContainer ? scoreContainer.offsetWidth : 1000;
        
        // Simple layout calculation
        const firstBeatX = this.scoreGeometry.firstMeasureX || 210; // Where first beat starts
        const endMargin = 50; // Space at end
        const availableWidth = Math.max(600, containerWidth - firstBeatX - endMargin); // Space for music
        
        // Calculate position: start + (progress * available_space)
        const cursorLeft = firstBeatX + (musicalProgress * availableWidth);
        
        console.log(`🎯 Simple positioning: ${currentTime.toFixed(2)}s/${totalDuration.toFixed(2)}s = ${(musicalProgress*100).toFixed(1)}% → ${cursorLeft.toFixed(1)}px`);
        
        return {
            left: Math.max(firstBeatX, cursorLeft), // Never go before first beat
            top: this.scoreGeometry.systemTop || 160,
            progress: musicalProgress,
            time: currentTime
        };
    }


    // SIMPLIFIED: Precise cursor positioning
    positionCursorByNote(note, index) {
        if (!this.visualCursor) {
            console.warn('⚠️ Visual cursor not available');
            return;
        }
        
        if (!this.scoreGeometry) {
            console.warn('⚠️ Score geometry not available - initializing...');
            this.scoreGeometry = this.getScoreGeometry();
        }

        try {
            // Calculate position using simple but accurate method
            const cursorPosition = this.calculatePreciseCursorPosition(note, index);
            
            // Fixed height for all staves
            const fixedHeight = this.calculateInitialCursorHeight(this.scoreGeometry);
            
            // Update cursor
            this.updateCursorWithFixedHeight(cursorPosition, fixedHeight, note, index);
            
        } catch (error) {
            console.error('❌ Cursor positioning failed:', error);
            
            // Emergency fallback: simple proportional movement
            this.fallbackCursorPositioning(note, index);
        }
    }
    
    // Emergency fallback positioning
    fallbackCursorPositioning(note, index) {
        const currentTime = note.startTime || 0;
        const totalDuration = this.getSequenceDuration() || 96;
        const progress = currentTime / totalDuration;
        
        const left = 210 + (progress * 800); // Simple calculation
        
        this.visualCursor.style.setProperty('left', `${left}px`, 'important');
        this.visualCursor.style.setProperty('opacity', '0.9', 'important');
        
        console.log(`🆘 FALLBACK cursor: ${note.noteName} → ${left.toFixed(1)}px`);
    }

    // Update cursor position with FIXED height (never changes)
    updateCursorWithFixedHeight(position, height, note, index) {
        // Force update with precise values
        this.visualCursor.style.setProperty('left', `${position.left.toFixed(1)}px`, 'important');
        this.visualCursor.style.setProperty('top', `${position.top}px`, 'important');
        this.visualCursor.style.setProperty('height', `${height}px`, 'important'); // ALWAYS SAME HEIGHT
        this.visualCursor.style.setProperty('opacity', '0.9', 'important');
        this.visualCursor.style.setProperty('display', 'block', 'important');
        
        // Add subtle animation for active cursor
        this.visualCursor.style.animation = 'cursor-pulse 1.5s ease-in-out infinite';
        
        // Force browser reflow for immediate update
        this.visualCursor.offsetHeight;
        
        // Detailed logging for debugging
        console.log(`🎯 PRECISE cursor: ${note.noteName} at ${position.time.toFixed(2)}s → ${position.left.toFixed(1)}px (${(position.progress * 100).toFixed(1)}%) | Fixed H:${height}px`);
    }

    // Get total duration of the sequence
    getSequenceDuration() {
        if (!this.playbackSequence || this.playbackSequence.length === 0) {
            return 100; // Default fallback
        }

        // Find the latest end time (startTime + duration) of any note
        let maxEndTime = 0;
        this.playbackSequence.forEach(note => {
            const endTime = (note.startTime || 0) + (note.duration || 1);
            if (endTime > maxEndTime) {
                maxEndTime = endTime;
            }
        });

        return Math.max(maxEndTime, 10); // At least 10 seconds
    }

    // Get height based on number of active parts at current time
    getActivePartsHeight(currentNote, currentIndex) {
        if (!this.playbackSequence) {
            return 100; // Default height
        }

        // Find all unique parts (instruments) that are active around this time
        const currentTime = currentNote.startTime || 0;
        const timeWindow = 0.5; // Look at notes within 0.5 seconds

        const activeParts = new Set();
        
        this.playbackSequence.forEach(note => {
            const noteTime = note.startTime || 0;
            if (Math.abs(noteTime - currentTime) <= timeWindow) {
                activeParts.add(note.partName || 'Unknown');
            }
        });

        // Calculate height: approximately 100px per staff/part
        const staffHeight = 100;
        const numActiveParts = Math.max(1, activeParts.size);
        const totalHeight = numActiveParts * staffHeight;

        console.log(`📏 Active parts at time ${currentTime.toFixed(2)}s:`, Array.from(activeParts), `→ Height: ${totalHeight}px`);
        
        return Math.min(totalHeight, 500); // Cap at 500px max
    }

    animateVisualCursor(progress) {
        if (!this.visualCursor) return;

        try {
            const scoreContainer = document.getElementById('score-container');
            if (!scoreContainer) return;

            // Get the actual music notation area (exclude margins)
            const containerWidth = scoreContainer.clientWidth;
            const effectiveWidth = containerWidth - 40; // Account for margins
            const cursorPosition = 20 + (progress / 100) * effectiveWidth; // Start at left margin

            this.visualCursor.style.left = `${cursorPosition}px`;
            this.visualCursor.style.opacity = '0.9';
            this.visualCursor.style.height = '100%';

            // Add smooth movement
            this.visualCursor.style.transition = 'left 0.2s ease-out';

            // Pulsing effect for visibility
            this.visualCursor.style.animation = 'cursor-pulse 1.5s ease-in-out infinite';

        } catch (error) {
            console.warn('⚠️ Cursor animation failed:', error);
        }
    }

    resetVisualCursor() {
        if (this.visualCursor && this.scoreGeometry) {
            // Reset to precise first measure position
            const firstMeasureX = this.scoreGeometry.firstMeasureX || 200;
            const systemTop = this.scoreGeometry.systemTop || 150;
            const initialHeight = this.calculateInitialCursorHeight(this.scoreGeometry);
            
            this.visualCursor.style.setProperty('left', `${firstMeasureX}px`, 'important');
            this.visualCursor.style.setProperty('top', `${systemTop}px`, 'important');
            this.visualCursor.style.setProperty('height', `${initialHeight}px`, 'important');
            this.visualCursor.style.setProperty('opacity', '0.3', 'important');
            this.visualCursor.style.animation = '';
            this.visualCursor.style.setProperty('display', 'block', 'important');
            this.visualCursor.style.setProperty('visibility', 'visible', 'important');
            
            console.log(`🔄 Precise cursor reset: ${firstMeasureX}px, ${systemTop}px, ${initialHeight}px height`);
        }
    }

    // Get total duration of the musical sequence
    getSequenceDuration() {
        if (!this.playbackSequence || this.playbackSequence.length === 0) {
            return 1; // Fallback to prevent division by zero
        }
        
        // Find the note with the latest end time
        let maxEndTime = 0;
        for (const note of this.playbackSequence) {
            const startTime = note.startTime || 0;
            const duration = note.duration || 0.5;
            const endTime = startTime + duration;
            if (endTime > maxEndTime) {
                maxEndTime = endTime;
            }
        }
        
        return Math.max(1, maxEndTime); // Ensure minimum duration of 1 second
    }

    // Start continuous cursor tracking during playback
    startCursorTracking() {
        // Stop any existing tracking
        this.stopCursorTracking();
        
        if (!this.visualCursor || !this.audioEngine) return;
        
        console.log('🎯 Starting continuous cursor tracking...');
        this.cursorTrackingStartTime = Date.now() / 1000; // Store start time in seconds
        
        // Update cursor position every 50ms for smooth movement
        this.cursorTrackingInterval = setInterval(() => {
            if (!this.isPlaying || !this.visualCursor) {
                this.stopCursorTracking();
                return;
            }
            
            try {
                // Calculate elapsed time since playback started
                const currentTime = (Date.now() / 1000) - this.cursorTrackingStartTime;
                const totalDuration = this.getSequenceDuration();
                const progress = Math.min(1.0, Math.max(0.0, currentTime / totalDuration));
                
                // Get current score position (updates with scroll)
                const scoreContainer = document.getElementById('score-container');
                if (!scoreContainer) return;
                
                const currentScoreRect = scoreContainer.getBoundingClientRect();
                const scoreLeft = currentScoreRect.left;
                const scoreWidth = currentScoreRect.width;
                const effectiveWidth = scoreWidth - 80;
                
                // Calculate new position
                const cursorLeft = scoreLeft + 40 + (progress * effectiveWidth);
                const cursorTop = currentScoreRect.top + 100;
                
                // Update position smoothly
                this.visualCursor.style.setProperty('left', `${cursorLeft}px`, 'important');
                this.visualCursor.style.setProperty('top', `${cursorTop}px`, 'important');
                
            } catch (error) {
                console.warn('⚠️ Cursor tracking error:', error);
                this.stopCursorTracking();
            }
        }, 50); // Update every 50ms for smooth movement
    }

    // Stop continuous cursor tracking
    stopCursorTracking() {
        if (this.cursorTrackingInterval) {
            clearInterval(this.cursorTrackingInterval);
            this.cursorTrackingInterval = null;
            console.log('⏹️ Cursor tracking stopped');
        }
    }

    // Test method to manually show/hide cursor
    testCursor() {
        console.log('🧪 Testing cursor visibility...');
        if (!this.visualCursor) {
            console.log('❌ No cursor element found');
            this.createVisualCursor(); // Try to recreate
            return;
        }
        
        console.log('🔍 Current cursor styles:', {
            opacity: this.visualCursor.style.opacity,
            display: this.visualCursor.style.display,
            visibility: this.visualCursor.style.visibility,
            left: this.visualCursor.style.left,
            zIndex: this.visualCursor.style.zIndex
        });
        
        // Force show cursor in red for 5 seconds
        this.visualCursor.style.opacity = '1';
        this.visualCursor.style.background = 'red';
        this.visualCursor.style.width = '10px';
        this.visualCursor.style.zIndex = '99999';
        this.visualCursor.style.display = 'block';
        this.visualCursor.style.visibility = 'visible';
        
        console.log('🔴 Cursor should now be visible as RED line');
        
        setTimeout(() => {
            if (this.visualCursor) {
                this.visualCursor.style.background = 'linear-gradient(to bottom, #10b981 0%, #059669 50%, #047857 100%)';
                this.visualCursor.style.width = '5px';
                this.visualCursor.style.opacity = '0.2';
                console.log('🟢 Cursor restored to normal green state');
            }
        }, 5000);
    }

    highlightCurrentNote(noteIndex) {
        if (!this.playbackCursor || !this.osmd) return;
        
        try {
            // Reset cursor to beginning if needed
            if (noteIndex === 0) {
                this.playbackCursor.reset();
                this.currentNoteIndex = 0;
            }
            
            // Simple cursor advancement - move forward one step per note
            while (this.currentNoteIndex < noteIndex && this.currentNoteIndex < this.playbackSequence.length) {
                try {
                    // Try different OSMD cursor advancement methods
                    if (this.playbackCursor.next) {
                        this.playbackCursor.next();
                    } else if (this.playbackCursor.Iterator && this.playbackCursor.Iterator.moveToNext) {
                        this.playbackCursor.Iterator.moveToNext();
                    } else {
                        // If cursor methods not available, just break
                        break;
                    }
                    this.currentNoteIndex++;
                } catch (cursorError) {
                    console.warn('⚠️ Cursor movement failed:', cursorError.message);
                    break;
                }
            }
            
            // Update display (don't re-render entire score for performance)
            // this.osmd.render(); // Commented out to avoid performance issues
            
        } catch (error) {
            console.warn('⚠️ Note highlighting failed:', error);
            // Disable cursor for this session if it keeps failing
            this.playbackCursor = null;
        }
    }

    resetPlaybackCursor() {
        if (this.playbackCursor) {
            try {
                this.playbackCursor.reset();
                this.currentNoteIndex = 0;
                // Only re-render if really needed
                // this.osmd.render();
                console.log('🔄 Playback cursor reset');
            } catch (error) {
                console.warn('⚠️ Cursor reset failed:', error);
            }
        }
    }

    updatePlaybackProgress(note, index) {
        // Enhanced visual feedback with cursor animation only
        try {
            // Calculate progress percentage
            const progress = Math.round((index / this.playbackSequence.length) * 100);
            
            // Update browser title
            if (document.title) {
                document.title = `🎵 ${progress}% - ${note.noteName} - MusicXML Player`;
            }
            
            // Animate visual cursor
            this.animateVisualCursor(progress);
            
            // Remove popup indicator - not needed anymore
            
        } catch (error) {
            console.warn('⚠️ Progress update failed:', error);
        }
    }

    addSimpleProgressIndicator(note, index, progress) {
        try {
            // Remove previous indicator
            const existingIndicator = document.querySelector('.progress-indicator');
            if (existingIndicator) {
                existingIndicator.remove();
            }
            
            // Add a more compact progress indicator
            const scoreContainer = document.getElementById('score-container');
            if (scoreContainer) {
                const progressBar = document.createElement('div');
                progressBar.className = 'progress-indicator';
                progressBar.style.cssText = `
                    position: absolute;
                    top: 15px;
                    right: 20px;
                    background: rgba(16, 185, 129, 0.15);
                    border: 2px solid #10b981;
                    border-radius: 8px;
                    padding: 6px 10px;
                    color: #10b981;
                    font-weight: 600;
                    font-size: 11px;
                    z-index: 1001;
                    pointer-events: none;
                    box-shadow: 0 2px 8px rgba(16, 185, 129, 0.3);
                    backdrop-filter: blur(5px);
                    min-width: 120px;
                    text-align: center;
                `;
                
                progressBar.innerHTML = `
                    <div style="margin-bottom: 2px;">🎵 ${note.noteName} (M${note.measureIndex + 1})</div>
                    <div style="font-size: 10px; opacity: 0.8;">${progress}% • ${index + 1}/${this.playbackSequence.length}</div>
                `;
                
                scoreContainer.appendChild(progressBar);
                
                // Auto-remove after a short time
                setTimeout(() => {
                    if (progressBar.parentNode) {
                        progressBar.remove();
                    }
                }, 1500);
            }
        } catch (error) {
            console.warn('⚠️ Visual indicator failed:', error);
        }
    }

    updateTempoAndRecalculate(newTempo) {
        this.currentTempo = newTempo;
        
        // Update audio engine tempo
        if (this.audioEngine) {
            this.audioEngine.setTempo(newTempo);
        }
        
        // Re-parse sequence with new tempo if score is loaded
        if (this.parsedScore && this.parser) {
            // Update tempo in parsed score
            this.parsedScore.tempo = newTempo;
            this.parser.tempo = newTempo; // Update parser tempo
            
            // Recreate playback sequence with new timing
            this.playbackSequence = this.parser.createPlaybackSequence(this.parsedScore);
            
            console.log('🎵 Tempo updated to', newTempo, 'BPM, sequence recalculated');
            
            // Update time display if available
            const timeDisplay = document.querySelector('.time-display');
            if (timeDisplay && this.playbackSequence) {
                // timeDisplay.textContent = `Ready: ${this.playbackSequence.length} notes @ ${newTempo} BPM`;
            }
            
            // Update tempo input
            const tempoInput = document.querySelector('.tempo-input');
            if (tempoInput) {
                tempoInput.value = newTempo.toString();
            }
        }
    }

    async initializeAdvancedAudio() {
        try {
            // Use Simple Audio Engine instead of Tone.js
            if (this.audioEngine && this.audioEngine.isInitialized) {
                console.log('🎹 Advanced audio engine ready');
                return true;
            } else {
                console.warn('⚠️ Audio engine not properly initialized, attempting to initialize...');
                await this.initializeSimpleAudio();
                if (this.audioEngine && this.audioEngine.isInitialized) {
                    console.log('🎹 Advanced audio engine now ready');
                    return true;
                } else {
                    console.error('❌ Failed to initialize audio engine');
                    return false;
                }
            }
        } catch (error) {
            console.warn('⚠️ Advanced audio initialization failed:', error);
            return false;
        }
    }

    createTransportControls() {
        // Remove existing controls
        const existingControls = document.querySelector('.transport-controls');
        if (existingControls) {
            existingControls.remove();
        }

        // Create transport controls
        const controls = document.createElement('div');
        controls.className = 'transport-controls';
        
        const controlsGroup = document.createElement('div');
        controlsGroup.className = 'controls-group';
        
        // Playback controls
        const playbackControls = document.createElement('div');
        playbackControls.className = 'playback-controls';
        
        const playButton = document.createElement('button');
        playButton.className = 'control-button primary';
        playButton.innerHTML = '▶️';
        playButton.title = 'Play/Pause';
        
        playButton.addEventListener('click', () => {
            if (this.isPlaying) {
                this.pausePlayback();
                playButton.innerHTML = '▶️';
            } else {
                this.startPlayback();
                playButton.innerHTML = '⏸️';
            }
        });
        
        playbackControls.appendChild(playButton);
        
        // Time display (hidden for cleaner interface)
        const timeDisplay = document.createElement('div');
        timeDisplay.className = 'time-display';
        timeDisplay.textContent = '';
        timeDisplay.style.display = 'none'; // Hide the time display
        timeDisplay.title = 'Playback progress and timing information';
        
        // Volume and tempo controls
        const volumeTempoControls = document.createElement('div');
        volumeTempoControls.className = 'volume-tempo-controls';
        
        // Tempo control group
        const tempoGroup = document.createElement('div');
        tempoGroup.className = 'control-group';
        
        const tempoLabel = document.createElement('span');
        tempoLabel.className = 'control-label';
        tempoLabel.textContent = 'Tempo';
        
        // Editable tempo input
        const tempoInput = document.createElement('input');
        tempoInput.type = 'number';
        tempoInput.min = '60';
        tempoInput.max = '200';
        tempoInput.step = '10';
        tempoInput.value = this.currentTempo.toString();
        tempoInput.className = 'tempo-input';
        tempoInput.title = 'Enter tempo (60-200 BPM)';
        
        tempoInput.addEventListener('change', (e) => {
            const newTempo = parseInt(e.target.value);
            if (newTempo >= 60 && newTempo <= 200) {
                console.log('🎛️ Tempo input changed to:', newTempo, 'BPM');
                this.updateTempoAndRecalculate(newTempo);
                
                // Apply tempo change in real-time if playing
                if (this.isPlaying && this.audioEngine && this.audioEngine.updateSequenceTempo) {
                    console.log('🔄 Applying real-time tempo change...');
                    this.audioEngine.updateSequenceTempo(newTempo);
                } else {
                    console.log('⏸️ Not playing or audio engine not ready for real-time tempo change');
                }
            } else {
                e.target.value = this.currentTempo.toString();
                this.showNotification('⚠️ Tempo must be between 60-200 BPM', 'error');
            }
        });
        
        tempoInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.target.blur(); // Trigger change event
            }
        });
        
        // Tempo buttons
        const tempoMinus = document.createElement('button');
        tempoMinus.className = 'control-button small';
        tempoMinus.innerHTML = '−';
        tempoMinus.title = 'Decrease tempo';
        tempoMinus.addEventListener('click', () => {
            const newTempo = Math.max(60, this.currentTempo - 10);
            tempoInput.value = newTempo.toString();
            this.updateTempoAndRecalculate(newTempo);
            
            // Apply tempo change in real-time if playing
            if (this.isPlaying && this.audioEngine && this.audioEngine.updateSequenceTempo) {
                this.audioEngine.updateSequenceTempo(newTempo);
            }
        });
        
        const tempoPlus = document.createElement('button');
        tempoPlus.className = 'control-button small';
        tempoPlus.innerHTML = '+';
        tempoPlus.title = 'Increase tempo';
        tempoPlus.addEventListener('click', () => {
            const newTempo = Math.min(200, this.currentTempo + 10);
            tempoInput.value = newTempo.toString();
            this.updateTempoAndRecalculate(newTempo);
            
            // Apply tempo change in real-time if playing
            if (this.isPlaying && this.audioEngine && this.audioEngine.updateSequenceTempo) {
                this.audioEngine.updateSequenceTempo(newTempo);
            }
        });
        
        tempoGroup.appendChild(tempoLabel);
        tempoGroup.appendChild(tempoMinus);
        tempoGroup.appendChild(tempoInput);
        tempoGroup.appendChild(tempoPlus);
        
        // Volume control group
        const volumeGroup = document.createElement('div');
        volumeGroup.className = 'control-group';
        
        const volumeLabel = document.createElement('span');
        volumeLabel.className = 'control-label';
        volumeLabel.textContent = 'Volume';
        
        // Editable volume input
        const volumeInput = document.createElement('input');
        volumeInput.type = 'number';
        volumeInput.min = '0';
        volumeInput.max = '100';
        volumeInput.step = '5';
        volumeInput.value = '70';
        volumeInput.className = 'volume-input';
        volumeInput.title = 'Enter volume (0-100%)';
        
        volumeInput.addEventListener('change', (e) => {
            const volume = parseInt(e.target.value);
            if (volume >= 0 && volume <= 100) {
                if (this.audioEngine) {
                    this.audioEngine.setVolume(volume / 100);
                }
                volumeSlider.value = volume.toString();
            } else {
                e.target.value = volumeSlider.value;
                this.showNotification('⚠️ Volume must be between 0-100%', 'error');
            }
        });
        
        volumeInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.target.blur(); // Trigger change event
            }
        });
        
        const volumeSlider = document.createElement('input');
        volumeSlider.type = 'range';
        volumeSlider.min = '0';
        volumeSlider.max = '100';
        volumeSlider.value = '70';
        volumeSlider.className = 'volume-slider';
        
        volumeSlider.addEventListener('input', (e) => {
            const volume = parseInt(e.target.value);
            volumeInput.value = volume.toString();
            if (this.audioEngine) {
                this.audioEngine.setVolume(volume / 100);
            }
        });
        
        const volumePercent = document.createElement('span');
        volumePercent.className = 'volume-percent';
        volumePercent.textContent = '%';
        
        volumeGroup.appendChild(volumeLabel);
        volumeGroup.appendChild(volumeInput);
        volumeGroup.appendChild(volumePercent);
        volumeGroup.appendChild(volumeSlider);
        
        volumeTempoControls.appendChild(tempoGroup);
        volumeTempoControls.appendChild(volumeGroup);
        
        controlsGroup.appendChild(playbackControls);
        // timeDisplay removed for cleaner interface
        controlsGroup.appendChild(volumeTempoControls);
        
        controls.appendChild(controlsGroup);
        
        // Append to score area instead of body to limit scope
        const scoreArea = document.getElementById('score-area');
        console.log('🔍 Looking for score-area element:', scoreArea);
        
        if (scoreArea) {
            // Remove any existing transport controls first
            const existingControls = scoreArea.querySelector('.transport-controls');
            if (existingControls) {
                existingControls.remove();
                console.log('🗑️ Removed existing transport controls');
            }
            
            scoreArea.appendChild(controls);
            scoreArea.style.position = 'relative';
            console.log('🎛️ Transport controls attached to score area');
            console.log('📊 Score area dimensions:', scoreArea.getBoundingClientRect());
        } else {
            // Fallback to body if score area not found
            document.body.appendChild(controls);
            console.log('🎛️ Transport controls attached to body (fallback - score-area not found)');
        }
        
        console.log('🎛️ Transport controls created');
    }

    async startPlayback() {
        try {
            if (this.audioEngine && this.audioEngine.isInitialized) {
                this.isPlaying = true;
                
                // Play actual MusicXML sequence if available
                if (this.playbackSequence && this.playbackSequence.length > 0) {
                    console.log('🎹 Starting MusicXML playback with', this.playbackSequence.length, 'notes...');
                    
                    await this.audioEngine.playSequence(
                        this.playbackSequence,
                        (note, index) => {
                            // Note highlighting callback
                            console.log(`🎵 Playing: ${note.noteName} from ${note.partName} (measure ${note.measureIndex + 1})`);
                            
                            // Update OSMD cursor position
                            const currentTime = note.startTime || 0;
                            this.updateOSMDCursorPosition(currentTime);
                            
                            // Show cursor at first note
                            if (index === 0) {
                                console.log('🎯 First note - showing cursor');
                                if (this.visualCursor) {
                                    this.visualCursor.style.opacity = '0.9';
                                    this.visualCursor.style.display = 'block';
                                    this.visualCursor.style.visibility = 'visible';
                                    console.log('👁️ Cursor visibility forced ON');
                                }
                            }
                            
                            // Position cursor based on current note
                            this.positionCursorByNote(note, index);
                            
                            // Update browser title for progress tracking
                            const progress = Math.round((index / this.playbackSequence.length) * 100);
                            document.title = `🎵 ${progress}% - ${note.noteName} (M${note.measureIndex + 1}) - MusicXML Player`;
                            
                            // Update time display (but hidden)
                            const timeDisplay = document.querySelector('.time-display');
                            if (timeDisplay) {
                                const progress = `${index + 1}/${this.playbackSequence.length}`;
                                const measure = `M${note.measureIndex + 1}`;
                                const time = `${(note.startTime || 0).toFixed(1)}s`;
                                // timeDisplay.textContent = `Playing: ${progress} (${measure}) - ${time}`;
                            }
                        },
                        () => {
                            // Sequence end callback
                            this.isPlaying = false;
                            const playButton = document.querySelector('.control-button.primary');
                            if (playButton) {
                                playButton.innerHTML = '▶️';
                            }
                            
                            // Reset cursor and display
                            this.resetVisualCursor();
                            const timeDisplay = document.querySelector('.time-display');
                            if (timeDisplay && this.playbackSequence) {
                                // timeDisplay.textContent = `Ready: ${this.playbackSequence.length} notes`;
                            }
                            
                            this.showNotification('🎵 Playback completed', 'success');
                        }
                    );
                } else {
                    // No MusicXML loaded, show message
                    console.log('🎹 No MusicXML loaded');
                    this.showNotification('⚠️ Please load a MusicXML file first', 'error');
                    this.isPlaying = false;
                    return;
                }
                
                console.log('🎵 Playback started');
                this.showNotification('🎵 Playback started', 'success');
            } else {
                console.warn('Audio engine not ready - attempting to initialize...');
                
                // Try to initialize audio engine
                await this.initializeSimpleAudio();
                
                if (this.audioEngine && this.audioEngine.isInitialized) {
                    // Retry playback
                    this.startPlayback();
                } else {
                    this.showNotification('⚠️ Audio engine failed to initialize. Try refreshing the page.', 'error');
                }
            }
        } catch (error) {
            console.error('Playback failed:', error);
            this.showNotification('⚠️ Playback failed: ' + error.message, 'error');
        }
    }

    async pausePlayback() {
        this.isPlaying = false;
        
        // Stop sequence playback
        if (this.audioEngine) {
            this.audioEngine.stopSequence();
        }
        
        // Stop cursor tracking
        this.stopCursorTracking();
        
        // Reset OSMD cursor
        if (this.cursor && this.cursor.reset) {
            this.cursor.reset();
            console.log('🎯 OSMD cursor reset on pause');
        }
        
        // Reset visual cursor
        this.resetVisualCursor();
        
        // Reset visual indicators
        const progressIndicator = document.querySelector('.progress-indicator');
        if (progressIndicator) {
            progressIndicator.remove();
        }
        
        // Reset title
        document.title = 'MusicXML Player';
        
        // Reset time display
        const timeDisplay = document.querySelector('.time-display');
        if (timeDisplay && this.playbackSequence) {
            // timeDisplay.textContent = `Ready: ${this.playbackSequence.length} notes`;
        }
        
        console.log('⏸️ Playback paused');
        this.showNotification('⏸️ Playback paused', 'info');
    }

    // Layout management methods - FIXED Z-INDEX
    showWelcomeGuide(show = true) {
        const welcomeGuide = document.getElementById('welcome-guide');
        const scoreContainer = document.getElementById('score-container');
        
        console.log('showWelcomeGuide:', show);
        
        if (show) {
            if (welcomeGuide) {
                welcomeGuide.style.display = 'flex';
                welcomeGuide.style.visibility = 'visible';
                welcomeGuide.style.opacity = '1';
                welcomeGuide.style.zIndex = '100';
                welcomeGuide.classList.remove('hidden');
            }
            if (scoreContainer) {
                scoreContainer.style.display = 'none';
                scoreContainer.style.visibility = 'hidden';
                scoreContainer.style.opacity = '0';
                scoreContainer.style.zIndex = '-1';
                scoreContainer.classList.remove('visible');
            }
        } else {
            if (welcomeGuide) {
                welcomeGuide.style.display = 'none';
                welcomeGuide.style.visibility = 'hidden';
                welcomeGuide.style.opacity = '0';
                welcomeGuide.style.zIndex = '-1';
                welcomeGuide.classList.add('hidden');
            }
        }
    }

    showScoreContainer(show = true) {
        const scoreContainer = document.getElementById('score-container');
        const welcomeGuide = document.getElementById('welcome-guide');
        
        console.log('showScoreContainer:', show);
        
        if (show) {
            if (scoreContainer) {
                scoreContainer.style.display = 'block';
                scoreContainer.style.visibility = 'visible';
                scoreContainer.style.opacity = '1';
                scoreContainer.style.zIndex = '50';
                scoreContainer.classList.add('visible');
            }
            if (welcomeGuide) {
                welcomeGuide.style.display = 'none';
                welcomeGuide.style.visibility = 'hidden';
                welcomeGuide.style.opacity = '0';
                welcomeGuide.style.zIndex = '-1';
                welcomeGuide.classList.add('hidden');
            }
        } else {
            if (scoreContainer) {
                scoreContainer.style.display = 'none';
                scoreContainer.style.visibility = 'hidden';
                scoreContainer.style.opacity = '0';
                scoreContainer.style.zIndex = '-1';
                scoreContainer.classList.remove('visible');
            }
        }
    }

    closeOverlay() {
        // Return to welcome guide
        this.showWelcomeGuide(true);
        this.showScoreContainer(false);
        
        // Remove active state from file items
        document.querySelectorAll('.file-list-item').forEach(item => {
            item.classList.remove('active');
            item.style.background = '#ffffff';
            item.style.color = '#374151';
            item.style.transform = 'translateX(0)';
            item.style.borderColor = 'rgba(226, 232, 240, 0.8)';
        });
        
        // Clean up audio
        if (this.audioEngine) {
            this.audioEngine.stopSequence(); // Stop any playing sequence
            this.audioEngine.dispose();
        }
        
        // Clear parsed data
        this.parsedScore = null;
        this.playbackSequence = null;
        this.visualCursor = null;
        this.currentNoteIndex = 0;
        
        // Remove transport controls
        const controls = document.querySelector('.transport-controls');
        if (controls) {
            controls.remove();
        }
    }

    showLoading(show) {
        const loading = document.getElementById('loading');
        if (loading) {
            if (show) {
                loading.classList.remove('hidden');
                loading.style.display = 'block';
            } else {
                loading.classList.add('hidden');
                loading.style.display = 'none';
            }
        }
    }

    updateBreadcrumb(filename) {
        console.log('Current file:', filename);
    }

    loadUserPreferences() {
        try {
            const prefs = localStorage.getItem('musicxml-player-prefs');
            if (prefs) {
                const preferences = JSON.parse(prefs);
                this.currentTempo = preferences.lastTempo || 120;
            }
        } catch (e) {
            console.warn('Could not load preferences:', e);
        }
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed !important;
            top: 80px !important;
            right: 20px !important;
            padding: 12px 20px !important;
            border-radius: 8px !important;
            color: white !important;
            font-weight: 600 !important;
            z-index: 10000 !important;
            transition: all 0.3s ease !important;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2) !important;
            background: ${type === 'error' ? '#ff6b6b' : type === 'success' ? '#48bb78' : '#667eea'} !important;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
}

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    if (window.OCA && window.OCA.MusicXMLPlayer) {
        console.warn('MusicXMLPlayer already initialized');
        return;
    }
    
    const player = new MusicXMLPlayer();
    player.init();
    
    // Store reference globally
    if (!window.OCA) window.OCA = {};
    window.OCA.MusicXMLPlayer = player;
});
