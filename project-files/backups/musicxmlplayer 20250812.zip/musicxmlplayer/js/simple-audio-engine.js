/**
 * Simple Audio Engine - Piano Synthesizer
 * Alternative to Tone.js using native Web Audio API
 * Lightweight solution for MusicXML playback
 */

class SimpleAudioEngine {
    constructor() {
        this.audioContext = null;
        this.masterGain = null;
        this.activeNotes = new Map(); // Track playing notes
        this.isInitialized = false;
        this.volume = 0.7;
        this.tempo = 120; // BPM
        this.currentSequence = null; // Track current playback sequence
        
        // Piano frequency mapping (A4 = 440Hz)
        this.noteFrequencies = this.generateNoteFrequencies();
    }

    async initialize() {
        try {
            // Don't create AudioContext until first user interaction
            console.log('🎹 Simple Audio Engine ready (will initialize on first play)');
            this.isInitialized = true;
            return true;
            
        } catch (error) {
            console.error('❌ Failed to initialize audio engine:', error);
            return false;
        }
    }

    async ensureAudioContext() {
        if (!this.audioContext) {
            try {
                // Create audio context on first use (after user gesture)
                this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
                
                // Create master gain node for volume control
                this.masterGain = this.audioContext.createGain();
                this.masterGain.gain.setValueAtTime(this.volume, this.audioContext.currentTime);
                this.masterGain.connect(this.audioContext.destination);
                
                // Resume context if suspended (browser policy)
                if (this.audioContext.state === 'suspended') {
                    await this.audioContext.resume();
                }
                
                console.log('🎹 AudioContext created successfully');
                return true;
                
            } catch (error) {
                console.error('❌ Failed to create AudioContext:', error);
                return false;
            }
        }
        return true;
    }

    generateNoteFrequencies() {
        const frequencies = {};
        const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
        
        // Generate frequencies for octaves 0-8
        for (let octave = 0; octave <= 8; octave++) {
            for (let note = 0; note < 12; note++) {
                const noteName = noteNames[note] + octave;
                // A4 (440Hz) is our reference point
                const semitoneFromA4 = (octave - 4) * 12 + (note - 9);
                const frequency = 440 * Math.pow(2, semitoneFromA4 / 12);
                frequencies[noteName] = frequency;
                
                // Add flat equivalents for common flat notes
                const flatEquivalents = {
                    'C#': 'Db', 'D#': 'Eb', 'F#': 'Gb', 'G#': 'Ab', 'A#': 'Bb'
                };
                
                if (flatEquivalents[noteNames[note]]) {
                    const flatName = flatEquivalents[noteNames[note]] + octave;
                    frequencies[flatName] = frequency;
                }
            }
        }
        
        console.log('🎹 Generated frequencies for', Object.keys(frequencies).length, 'note names');
        
        // Debug: Show some flat notes for verification
        const testFlats = ['Bb4', 'Eb4', 'Ab4', 'Db4', 'Gb4'];
        console.log('🎵 Flat notes test:', testFlats.map(note => 
            `${note}: ${frequencies[note] ? frequencies[note].toFixed(2) + 'Hz' : 'MISSING'}`
        ).join(', '));
        
        return frequencies;
    }

    createPianoTone(frequency, startTime, duration) {
        if (!this.isInitialized) return null;

        // Ensure AudioContext is created (lazy initialization)
        if (!this.audioContext) {
            console.warn('AudioContext not ready - call ensureAudioContext() first');
            return null;
        }

        // Create oscillator for the fundamental frequency
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();

        // Piano-like sound using multiple oscillators (additive synthesis)
        oscillator.type = 'triangle'; // Warmer than sine, less harsh than square
        oscillator.frequency.setValueAtTime(frequency, startTime);

        // Create envelope (ADSR) for piano-like attack and decay
        // Scale envelope timing based on note duration
        const minAttack = 0.01;
        const maxAttack = 0.05;
        const attackTime = Math.min(maxAttack, Math.max(minAttack, duration * 0.1));
        
        const minDecay = 0.05;
        const maxDecay = 0.5;
        const decayTime = Math.min(maxDecay, Math.max(minDecay, duration * 0.3));
        
        const sustainLevel = duration < 0.5 ? 0.6 : 0.3; // Higher sustain for short notes
        const releaseTime = Math.min(0.5, duration * 0.2);

        // Set up precise envelope with linear ramps for reliability
        gainNode.gain.setValueAtTime(0, startTime);
        gainNode.gain.linearRampToValueAtTime(0.8, startTime + attackTime);
        gainNode.gain.linearRampToValueAtTime(sustainLevel, startTime + attackTime + decayTime);
        gainNode.gain.setValueAtTime(sustainLevel, startTime + duration - releaseTime);
        gainNode.gain.linearRampToValueAtTime(0, startTime + duration);

        // Connect nodes
        oscillator.connect(gainNode);
        gainNode.connect(this.masterGain);

        // Schedule start and stop with precise timing
        oscillator.start(startTime);
        oscillator.stop(startTime + duration);

        console.log(`🎹 Created tone: ${frequency.toFixed(2)}Hz, duration: ${duration.toFixed(3)}s`);

        return { oscillator, gainNode };
    }

    async playNote(noteName, velocity = 0.7, duration = 1.0) {
        if (!this.isInitialized) {
            console.warn('Audio engine not initialized');
            return;
        }

        // Ensure AudioContext is ready (lazy initialization)
        const contextReady = await this.ensureAudioContext();
        if (!contextReady) {
            console.warn('Failed to initialize AudioContext');
            return;
        }

        const frequency = this.noteFrequencies[noteName];
        if (!frequency) {
            console.warn(`Unknown note: ${noteName}`);
            return;
        }

        const startTime = this.audioContext.currentTime;
        
        // Use the duration as-is since it's already calculated correctly by the parser
        // The parser already handles tempo conversion in divisionsToSeconds()
        const actualDuration = Math.max(0.05, duration); // Minimum 50ms duration

        // Create the note with precise timing
        const noteData = this.createPianoTone(frequency, startTime, actualDuration);
        if (noteData) {
            // Store active note for potential early stopping
            const noteId = `${noteName}_${startTime}`;
            this.activeNotes.set(noteId, noteData);

            // Clean up after note ends (use actual duration)
            setTimeout(() => {
                this.activeNotes.delete(noteId);
            }, actualDuration * 1000 + 100);
        }
    }

    playChord(noteNames, velocity = 0.7, duration = 1.0) {
        noteNames.forEach(noteName => {
            this.playNote(noteName, velocity * 0.8, duration); // Slightly quieter for chords
        });
    }

    // Precise timing version of playNote
    playNoteAtTime(noteName, velocity = 0.7, duration = 1.0, audioTime = null) {
        if (!this.isInitialized) {
            console.warn('Audio engine not initialized');
            return;
        }

        if (!this.audioContext) {
            console.warn('AudioContext not ready');
            return;
        }

        const frequency = this.noteFrequencies[noteName];
        if (!frequency) {
            console.warn(`Unknown note: ${noteName}`);
            return;
        }

        // Use provided audio time or current time
        const startTime = audioTime || this.audioContext.currentTime;
        const actualDuration = Math.max(0.05, duration); // Minimum 50ms duration

        // Create the note with precise timing
        const noteData = this.createPianoTone(frequency, startTime, actualDuration);
        if (noteData) {
            // Store active note for potential early stopping
            const noteId = `${noteName}_${startTime}`;
            this.activeNotes.set(noteId, noteData);

            // Clean up after note ends (use actual duration)
            setTimeout(() => {
                this.activeNotes.delete(noteId);
            }, actualDuration * 1000 + 100);
            
            console.log(`🎹 Scheduled precise note: ${noteName} at ${startTime.toFixed(3)}s, duration: ${actualDuration.toFixed(3)}s`);
        }
    }

    stopNote(noteName) {
        // Find and stop specific note
        for (const [noteId, noteData] of this.activeNotes.entries()) {
            if (noteId.startsWith(noteName)) {
                try {
                    noteData.gainNode.gain.exponentialRampToValueAtTime(
                        0.01, 
                        this.audioContext.currentTime + 0.1
                    );
                    this.activeNotes.delete(noteId);
                } catch (e) {
                    // Note might have already stopped
                }
            }
        }
    }

    stopAllNotes() {
        for (const [noteId, noteData] of this.activeNotes.entries()) {
            try {
                noteData.gainNode.gain.exponentialRampToValueAtTime(
                    0.01, 
                    this.audioContext.currentTime + 0.1
                );
            } catch (e) {
                // Note might have already stopped
            }
        }
        this.activeNotes.clear();
    }

    setVolume(volume) {
        this.volume = Math.max(0, Math.min(1, volume));
        if (this.masterGain) {
            this.masterGain.gain.setTargetAtTime(
                this.volume, 
                this.audioContext.currentTime, 
                0.1
            );
        }
    }

    setTempo(bpm) {
        this.tempo = Math.max(60, Math.min(200, bpm));
    }

    getVolume() {
        return this.volume;
    }

    getTempo() {
        return this.tempo;
    }

    // Convert MusicXML note info to our format
    parseMusicXMLNote(xmlNote) {
        // Extract note information from MusicXML
        const step = xmlNote.querySelector('step')?.textContent || 'C';
        const octave = parseInt(xmlNote.querySelector('octave')?.textContent || '4');
        const alter = parseInt(xmlNote.querySelector('alter')?.textContent || '0');
        
        // Handle sharps/flats
        let noteName = step + octave;
        if (alter > 0) {
            noteName = step + '#' + octave;
        } else if (alter < 0) {
            // Convert flat to equivalent sharp
            const flatToSharp = {
                'Db': 'C#', 'Eb': 'D#', 'Gb': 'F#', 'Ab': 'G#', 'Bb': 'A#'
            };
            const flatName = step + 'b';
            if (flatToSharp[flatName]) {
                noteName = flatToSharp[flatName] + octave;
            }
        }
        
        return noteName;
    }

    // Play a sequence of notes from parsed MusicXML data
    async playSequence(sequence, onNoteStart = null, onSequenceEnd = null) {
        if (!this.isInitialized) {
            await this.initialize();
        }

        // Ensure AudioContext is ready
        const contextReady = await this.ensureAudioContext();
        if (!contextReady) {
            console.warn('Cannot play sequence - AudioContext failed');
            return;
        }

        console.log('🎵 Starting sequence playback:', sequence.length, 'notes from', 
                   [...new Set(sequence.map(n => n.partName))].join(', '));
        
        // Stop any currently playing sequence
        this.stopSequence();
        
        this.currentSequence = {
            notes: sequence,
            startTime: Date.now() / 1000, // Convert to seconds for consistency
            scheduledNotes: [],
            isPlaying: true,
            timeGroups: this.groupNotesByTime(sequence), // Store groups for tempo changes
            originalTempo: 120, // Store original tempo
            onNoteStart: onNoteStart
        };

        // Group notes by start time to handle simultaneous notes/chords
        const noteGroups = this.currentSequence.timeGroups;
        
        console.log(`🎼 Grouped into ${noteGroups.length} time points for playback`);

        // Schedule all note groups with precise audio timing
        const audioStartTime = this.audioContext.currentTime + 0.1; // Small buffer
        this.currentSequence.audioStartTime = audioStartTime;
        
        console.log(`🎼 Scheduling ${noteGroups.length} time points with audio-precise timing`);
        console.log(`🕐 Audio start time: ${audioStartTime.toFixed(3)}s, current time: ${this.audioContext.currentTime.toFixed(3)}s`);

        noteGroups.forEach((group, groupIndex) => {
            const audioTime = audioStartTime + group.startTime;
            const delayMs = (audioTime - this.audioContext.currentTime) * 1000;
            
            console.log(`📅 Group ${groupIndex}: notes at ${group.startTime.toFixed(3)}s, audio time: ${audioTime.toFixed(3)}s, delay: ${delayMs.toFixed(1)}ms`);
            
            // Use setTimeout for callbacks, but audio timing is handled by Web Audio API
            const scheduledNote = setTimeout(() => {
                if (this.currentSequence && this.currentSequence.isPlaying) {
                    // Log timing precision
                    const actualAudioTime = this.audioContext.currentTime;
                    const expectedAudioTime = audioStartTime + group.startTime;
                    const timingError = Math.abs(actualAudioTime - expectedAudioTime) * 1000;
                    
                    if (timingError > 5) { // Log if more than 5ms off
                        console.warn(`⏱️ Timing drift: ${timingError.toFixed(1)}ms for group ${groupIndex}`);
                    }
                    
                    // Play all notes in this time group with precise audio timing
                    group.notes.forEach((note, noteIndex) => {
                        // Use the calculated audio time, not current time
                        this.playNoteAtTime(note.noteName, note.velocity, note.duration, expectedAudioTime);
                        
                        // Callback for first note in group (for highlighting)
                        if (noteIndex === 0 && onNoteStart) {
                            onNoteStart(note, groupIndex);
                        }
                    });
                    
                    if (group.notes.length > 1) {
                        console.log(`🎵 Playing chord: ${group.notes.map(n => n.noteName).join(', ')} (time: ${group.startTime.toFixed(2)}s)`);
                    } else {
                        console.log(`🎵 Playing note: ${group.notes[0].noteName} from ${group.notes[0].partName} (time: ${group.startTime.toFixed(2)}s)`);
                    }
                }
            }, delayMs);
            
            this.currentSequence.scheduledNotes.push(scheduledNote);
        });

        // Schedule sequence end callback
        if (sequence.length > 0) {
            const lastNote = sequence[sequence.length - 1];
            const sequenceEndTime = lastNote.startTime + lastNote.duration;
            
            setTimeout(() => {
                if (this.currentSequence && this.currentSequence.isPlaying) {
                    console.log('🎵 Sequence playback completed');
                    this.currentSequence.isPlaying = false;
                    
                    if (onSequenceEnd) {
                        onSequenceEnd();
                    }
                }
            }, sequenceEndTime * 1000);
        }
    }

    // Group notes that should play simultaneously
    groupNotesByTime(sequence) {
        const groups = [];
        const timeThreshold = 0.05; // 50ms tolerance for simultaneous notes
        
        sequence.forEach(note => {
            // Find existing group with similar start time
            let existingGroup = groups.find(group => 
                Math.abs(group.startTime - note.startTime) < timeThreshold
            );
            
            if (existingGroup) {
                existingGroup.notes.push(note);
            } else {
                groups.push({
                    startTime: note.startTime,
                    notes: [note]
                });
            }
        });
        
        // Sort groups by start time
        groups.sort((a, b) => a.startTime - b.startTime);
        
        return groups;
    }

    stopSequence() {
        if (this.currentSequence) {
            console.log('⏹️ Stopping current sequence');
            this.currentSequence.isPlaying = false;
            
            // Clear all scheduled notes
            this.currentSequence.scheduledNotes.forEach(timeout => {
                clearTimeout(timeout);
            });
            
            this.currentSequence = null;
        }
        
        // Stop all currently playing notes
        this.stopAllNotes();
    }

    isSequencePlaying() {
        return this.currentSequence && this.currentSequence.isPlaying;
    }

    updateSequenceTempo(newTempo) {
        if (!this.currentSequence || !this.currentSequence.isPlaying) {
            console.log('🎵 No active sequence to update tempo');
            return;
        }
        
        try {
            console.log('🎵 Updating sequence tempo to', newTempo, 'BPM in real-time');
            
            // Calculate current playback position in seconds
            const currentTimeSeconds = Date.now() / 1000;
            const elapsedTime = currentTimeSeconds - this.currentSequence.startTime;
            const originalTempo = this.currentSequence.originalTempo || 120;
            
            console.log(`🕒 Elapsed time: ${elapsedTime.toFixed(2)}s, original tempo: ${originalTempo}`);
            
            // Cancel all scheduled timeouts
            if (this.currentSequence.scheduledNotes) {
                console.log(`⏸️ Cancelling ${this.currentSequence.scheduledNotes.length} scheduled notes`);
                this.currentSequence.scheduledNotes.forEach(timeout => {
                    clearTimeout(timeout);
                });
                this.currentSequence.scheduledNotes = [];
            }
            
            // Find which notes haven't played yet based on elapsed time
            const remainingGroups = this.currentSequence.timeGroups.filter(group => {
                return group.startTime > elapsedTime;
            });
            
            console.log(`🎵 Found ${remainingGroups.length} remaining note groups to reschedule`);
            
            // Reschedule remaining notes with new tempo
            remainingGroups.forEach((group, index) => {
                // Adjust timing: faster tempo = shorter time intervals
                const tempoRatio = originalTempo / newTempo;
                const adjustedStartTime = (group.startTime - elapsedTime) * tempoRatio;
                const timeFromNowMs = Math.max(0, adjustedStartTime * 1000);
                
                console.log(`📅 Group ${index}: original ${group.startTime}s, adjusted delay: ${adjustedStartTime.toFixed(2)}s`);
                
                const timeout = setTimeout(() => {
                    if (this.currentSequence && this.currentSequence.isPlaying) {
                        if (group.notes.length === 1) {
                            // Single note
                            const note = group.notes[0];
                            const adjustedDuration = note.duration * tempoRatio;
                            this.playNote(note.noteName, note.velocity, adjustedDuration);
                            console.log(`🎵 Playing note: ${note.noteName} from ${note.partName}`);
                        } else {
                            // Chord
                            const chordNames = group.notes.map(n => n.noteName).join(', ');
                            console.log(`🎵 Playing chord: ${chordNames}`);
                            group.notes.forEach(note => {
                                const adjustedDuration = note.duration * tempoRatio;
                                this.playNote(note.noteName, note.velocity, adjustedDuration);
                            });
                        }
                        
                        // Call onNotePlay callback for each note
                        if (this.currentSequence.onNoteStart) {
                            group.notes.forEach((note, noteIndex) => {
                                if (noteIndex === 0) { // Only callback for first note in group
                                    this.currentSequence.onNoteStart(note, index);
                                }
                            });
                        }
                    }
                }, timeFromNowMs);
                
                this.currentSequence.scheduledNotes.push(timeout);
            });
            
            // Update sequence tempo reference
            this.currentSequence.originalTempo = newTempo;
            
            console.log('✅ Real-time tempo change applied successfully');
            
        } catch (error) {
            console.error('❌ Real-time tempo change failed:', error);
        }
    }

    dispose() {
        this.stopSequence();
        this.stopAllNotes();
        
        if (this.audioContext) {
            this.audioContext.close();
            this.audioContext = null;
        }
        
        this.masterGain = null;
        this.isInitialized = false;
        console.log('🎹 Simple Audio Engine disposed');
    }
}

// Export for use in other modules
window.SimpleAudioEngine = SimpleAudioEngine;
