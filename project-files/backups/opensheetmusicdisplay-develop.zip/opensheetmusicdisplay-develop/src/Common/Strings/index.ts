// created from 'create-ts-index'

export * from "./StringUtil";
