/**
 * The fonts available for writing on the sheet music
 */
export enum Fonts {
    TimesNewRoman,
    Kokila
}
