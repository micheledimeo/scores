 privileges required'], 403);
            }

            $this->logger->info('Flat.io Player: Manual installation requested via web interface', [
                'app' => $this->appName,
                'user' => $this->userSession->getUser()->getUID()
            ]);

            // Run the auto-installation
            Application::runAutoInstallation();

            // Verify the installation
            $installInfo = $this->detectInstallationInfo();
            $status = $this->checkCurrentStatus($installInfo);

            if ($status['properly_configured']) {
                $this->logger->info('Flat.io Player: Manual installation completed successfully', [
                    'app' => $this->appName
                ]);

                return new DataResponse([
                    'status' => 'success',
                    'message' => 'Installation completed successfully',
                    'installation_info' => [
                        'owner' => $installInfo['owner'] . ':' . $installInfo['group'],
                        'app_path' => $installInfo['app_path']
                    ]
                ]);
            } else {
                return new DataResponse([
                    'status' => 'warning',
                    'message' => 'Installation completed but verification failed',
                    'current_status' => $status
                ], 500);
            }

        } catch (\Exception $e) {
            $this->logger->error('Flat.io Player: Manual installation failed: ' . $e->getMessage(), [
                'app' => $this->appName,
                'exception' => $e
            ]);

            return new DataResponse([
                'status' => 'error',
                'message' => 'Installation failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get installation diagnostics
     * 
     * @NoAdminRequired
     */
    public function diagnostics(): DataResponse {
        try {
            if (!$this->userSession->getUser() || !$this->isAdmin()) {
                return new DataResponse(['error' => 'Admin privileges required'], 403);
            }

            $installInfo = $this->detectInstallationInfo();
            $status = $this->checkCurrentStatus($installInfo);

            // Additional diagnostic information
            $diagnostics = [
                'php_user' => posix_getpwuid(posix_geteuid())['name'] ?? 'unknown',
                'current_user' => get_current_user(),
                'nextcloud_version' => \OC::$server->getSystemConfig()->getValue('version'),
                'app_version' => Application::APP_VERSION,
                'file_permissions' => [],
                'directory_permissions' => [],
                'missing_files' => [],
                'environment' => [
                    'php_version' => PHP_VERSION,
                    'os' => PHP_OS,
                    'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'unknown'
                ]
            ];

            // Check file permissions in detail
            $appPath = $installInfo['app_path'];
            $criticalFiles = [
                'appinfo/info.xml',
                'lib/AppInfo/Application.php',
                'composer.json',
                'templates/main.php',
                'css/app.css',
                'js/flatio-player.js'
            ];

            foreach ($criticalFiles as $file) {
                $fullPath = $appPath . '/' . $file;
                if (file_exists($fullPath)) {
                    $perms = fileperms($fullPath);
                    $owner = posix_getpwuid(fileowner($fullPath))['name'] ?? 'unknown';
                    $group = posix_getgrgid(filegroup($fullPath))['name'] ?? 'unknown';
                    
                    $diagnostics['file_permissions'][$file] = [
                        'permissions' => sprintf('%o', $perms & 0777),
                        'owner' => $owner,
                        'group' => $group,
                        'readable' => is_readable($fullPath),
                        'writable' => is_writable($fullPath)
                    ];
                } else {
                    $diagnostics['missing_files'][] = $file;
                }
            }

            // Check directory permissions
            $criticalDirs = [
                '',
                'appinfo',
                'lib',
                'css',
                'js',
                'templates',
                'img',
                'l10n'
            ];

            foreach ($criticalDirs as $dir) {
                $fullPath = $appPath . ($dir ? '/' . $dir : '');
                if (is_dir($fullPath)) {
                    $perms = fileperms($fullPath);
                    $owner = posix_getpwuid(fileowner($fullPath))['name'] ?? 'unknown';
                    $group = posix_getgrgid(filegroup($fullPath))['name'] ?? 'unknown';
                    
                    $diagnostics['directory_permissions'][$dir ?: 'root'] = [
                        'permissions' => sprintf('%o', $perms & 0777),
                        'owner' => $owner,
                        'group' => $group,
                        'readable' => is_readable($fullPath),
                        'writable' => is_writable($fullPath)
                    ];
                }
            }

            return new DataResponse([
                'status' => 'success',
                'installation_info' => $installInfo,
                'current_status' => $status,
                'diagnostics' => $diagnostics
            ]);

        } catch (\Exception $e) {
            $this->logger->error('Flat.io Player: Diagnostics failed: ' . $e->getMessage(), [
                'app' => $this->appName,
                'exception' => $e
            ]);

            return new DataResponse([
                'status' => 'error',
                'message' => 'Diagnostics failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Check if current user is admin
     */
    private function isAdmin(): bool {
        $user = $this->userSession->getUser();
        if (!$user) {
            return false;
        }

        $groupManager = \OC::$server->getGroupManager();
        return $groupManager->isAdmin($user->getUID());
    }

    /**
     * Detect installation information (same logic as Application.php)
     */
    private function detectInstallationInfo(): array {
        $nextcloudPath = \OC::$SERVERROOT;
        $appPath = $nextcloudPath . '/apps/' . Application::APP_ID;
        
        $owner = null;
        $group = null;
        
        // Method 1: Check app directory owner
        if (file_exists($appPath)) {
            $stat = stat($appPath);
            if ($stat !== false) {
                $owner = posix_getpwuid($stat['uid'])['name'] ?? null;
                $group = posix_getgrgid($stat['gid'])['name'] ?? null;
            }
        }
        
        // Method 2: Check Nextcloud config.php owner
        if (!$owner) {
            $configPath = $nextcloudPath . '/config/config.php';
            if (file_exists($configPath)) {
                $stat = stat($configPath);
                if ($stat !== false) {
                    $owner = posix_getpwuid($stat['uid'])['name'] ?? null;
                    $group = posix_getgrgid($stat['gid'])['name'] ?? null;
                }
            }
        }
        
        // Method 3: Check data directory owner
        if (!$owner) {
            $dataPath = \OC::$server->getConfig()->getSystemValue('datadirectory', $nextcloudPath . '/data');
            if (file_exists($dataPath)) {
                $stat = stat($dataPath);
                if ($stat !== false) {
                    $owner = posix_getpwuid($stat['uid'])['name'] ?? null;
                    $group = posix_getgrgid($stat['gid'])['name'] ?? null;
                }
            }
        }
        
        // Method 4: Detect common hosting patterns
        if (!$owner) {
            $pathParts = explode('/', $nextcloudPath);
            
            // Pattern: /home/username/domains/...
            if (count($pathParts) >= 3 && $pathParts[1] === 'home') {
                $potentialOwner = $pathParts[2];
                if (posix_getpwnam($potentialOwner) !== false) {
                    $owner = $potentialOwner;
                    $group = $potentialOwner;
                }
            }
            
            // Pattern: /var/www/...
            if (!$owner && in_array('www', $pathParts)) {
                $owner = 'www-data';
                $group = 'www-data';
            }
        }
        
        // Fallback
        if (!$owner) {
            $owner = 'www-data';
            $group = 'www-data';
        }
        
        return [
            'nextcloud_path' => $nextcloudPath,
            'app_path' => $appPath,
            'owner' => $owner,
            'group' => $group
        ];
    }

    /**
     * Check current installation status
     */
    private function checkCurrentStatus(array $installInfo): array {
        $appPath = $installInfo['app_path'];
        $owner = $installInfo['owner'];
        
        $status = [
            'app_exists' => is_dir($appPath),
            'critical_files_exist' => true,
            'permissions_correct' => true,
            'owner_correct' => true,
            'properly_configured' => false
        ];
        
        // Check critical files
        $criticalFiles = [
            'appinfo/info.xml',
            'lib/AppInfo/Application.php',
            'composer.json'
        ];
        
        foreach ($criticalFiles as $file) {
            if (!file_exists($appPath . '/' . $file)) {
                $status['critical_files_exist'] = false;
                break;
            }
        }
        
        // Check ownership
        if ($status['app_exists']) {
            $stat = stat($appPath);
            if ($stat !== false) {
                $actualOwner = posix_getpwuid($stat['uid'])['name'] ?? null;
                if ($actualOwner !== $owner) {
                    $status['owner_correct'] = false;
                }
            }
        }
        
        // Check permissions
        if ($status['app_exists'] && !is_readable($appPath)) {
            $status['permissions_correct'] = false;
        }
        
        $status['properly_configured'] = $status['app_exists'] && 
                                       $status['critical_files_exist'] && 
                                       $status['permissions_correct'] && 
                                       $status['owner_correct'];
        
        return $status;
    }
}
owner'] . ':' . $installInfo['group'],
                        'app_path' => $installInfo['app_path']
                    ]
                ]);
            } else {
                return new DataResponse([
                    'status' => 'warning',
                    'message' => 'Installation completed but verification failed',
                    'current_status' => $status
                ], 500);
            }

        } catch (\Exception $e) {
            $this->logger->error('Flat.io Player: Manual installation failed: ' . $e->getMessage(), [
                'app' => $this->appName,
                'exception' => $e
            ]);

            return new DataResponse([
                'status' => 'error',
                'message' => 'Installation failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get installation diagnostics
     * 
     * @NoAdminRequired
     */
    public function diagnostics(): DataResponse {
        try {
            if (!$this->userSession->getUser() || !$this->isAdmin()) {
                return new DataResponse(['error' => 'Admin privileges required'], 403);
            }

            $installInfo = $this->installationService->detectInstallationInfo();
            $status = $this->installationService->checkCurrentStatus($installInfo);

            // Additional diagnostic information
            $diagnostics = [
                'php_user' => posix_getpwuid(posix_geteuid())['name'] ?? 'unknown',
                'current_user' => get_current_user(),
                'nextcloud_version' => \OC::$server->getSystemConfig()->getValue('version'),
                'app_version' => Application::APP_VERSION,
                'file_permissions' => [],
                'directory_permissions' => [],
                'missing_files' => [],
                'environment' => [
                    'php_version' => PHP_VERSION,
                    'os' => PHP_OS,
                    'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'unknown'
                ]
            ];

            // Check file permissions in detail
            $this->gatherFilePermissions($installInfo, $diagnostics);
            
            // Check directory permissions
            $this->gatherDirectoryPermissions($installInfo, $diagnostics);

            return new DataResponse([
                'status' => 'success',
                'installation_info' => $installInfo,
                'current_status' => $status,
                'diagnostics' => $diagnostics
            ]);

        } catch (\Exception $e) {
            $this->logger->error('Flat.io Player: Diagnostics failed: ' . $e->getMessage(), [
                'app' => $this->appName,
                'exception' => $e
            ]);

            return new DataResponse([
                'status' => 'error',
                'message' => 'Diagnostics failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Check if current user is admin
     */
    private function isAdmin(): bool {
        $user = $this->userSession->getUser();
        if (!$user) {
            return false;
        }

        $groupManager = \OC::$server->getGroupManager();
        return $groupManager->isAdmin($user->getUID());
    }

    /**
     * Gather file permissions for diagnostics
     */
    private function gatherFilePermissions(array $installInfo, array &$diagnostics): void {
        $appPath = $installInfo['app_path'];
        $criticalFiles = [
            'appinfo/info.xml',
            'lib/AppInfo/Application.php',
            'composer.json',
            'templates/main.php',
            'css/app.css',
            'js/flatio-player.js'
        ];

        foreach ($criticalFiles as $file) {
            $fullPath = $appPath . '/' . $file;
            if (file_exists($fullPath)) {
                $perms = fileperms($fullPath);
                $owner = posix_getpwuid(fileowner($fullPath))['name'] ?? 'unknown';
                $group = posix_getgrgid(filegroup($fullPath))['name'] ?? 'unknown';
                
                $diagnostics['file_permissions'][$file] = [
                    'permissions' => sprintf('%o', $perms & 0777),
                    'owner' => $owner,
                    'group' => $group,
                    'readable' => is_readable($fullPath),
                    'writable' => is_writable($fullPath)
                ];
            } else {
                $diagnostics['missing_files'][] = $file;
            }
        }
    }

    /**
     * Gather directory permissions for diagnostics
     */
    private function gatherDirectoryPermissions(array $installInfo, array &$diagnostics): void {
        $appPath = $installInfo['app_path'];
        $criticalDirs = [
            '',
            'appinfo',
            'lib',
            'css',
            'js',
            'templates',
            'img',
            'l10n'
        ];

        foreach ($criticalDirs as $dir) {
            $fullPath = $appPath . ($dir ? '/' . $dir : '');
            if (is_dir($fullPath)) {
                $perms = fileperms($fullPath);
                $owner = posix_getpwuid(fileowner($fullPath))['name'] ?? 'unknown';
                $group = posix_getgrgid(filegroup($fullPath))['name'] ?? 'unknown';
                
                $diagnostics['directory_permissions'][$dir ?: 'root'] = [
                    'permissions' => sprintf('%o', $perms & 0777),
                    'owner' => $owner,
                    'group' => $group,
                    'readable' => is_readable($fullPath),
                    'writable' => is_writable($fullPath)
                ];
            }
        }
    }
}
