<?php

declare(strict_types=1);

namespace OCA\FlatioPlayer\Service;

use OCP\AppFramework\Http\ContentSecurityPolicy;
use OCP\Security\CSP\AddContentSecurityPolicyEvent;
use OCP\EventDispatcher\Event;
use OCP\EventDispatcher\IEventListener;

/**
 * Content Security Policy Provider for Flat.io Integration
 * 
 * Ensures proper CSP headers for Flat.io embed functionality
 * while maintaining security for Nextcloud 31.0.7.
 */
class CSPProvider implements IEventListener {

    public function handle(Event $event): void {
        if (!($event instanceof AddContentSecurityPolicyEvent)) {
            return;
        }

        // Get the current CSP
        $csp = $event->getPolicy();

        // Add Flat.io domains to CSP
        $csp->addAllowedScriptDomain('https://embed.flat.io');
        $csp->addAllowedFrameDomain('https://embed.flat.io');
        $csp->addAllowedConnectDomain('https://embed.flat.io');
        $csp->addAllowedWorkerSrcDomain('https://embed.flat.io');
        
        // Allow inline styles for Flat.io embed customization
        $csp->allowInlineStyle();
        
        // Allow data URIs for embedded content
        $csp->addAllowedImageDomain('data:');
        $csp->addAllowedMediaDomain('data:');

        // Apply updated policy
        $event->addPolicy($csp);
    }
}
