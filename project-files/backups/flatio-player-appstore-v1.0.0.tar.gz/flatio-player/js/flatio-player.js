0) {
                    this.selectFile(this.selectedIndex - 1);
                }
                break;

            case 'ArrowDown':
                event.preventDefault();
                if (this.selectedIndex < this.files.length - 1) {
                    this.selectFile(this.selectedIndex + 1);
                }
                break;

            case 'Escape':
                event.preventDefault();
                this.handleStop();
                break;

            case 'r':
                if (event.ctrlKey) {
                    event.preventDefault();
                    this.handleRefreshFiles();
                }
                break;
        }
    }

    handleBeforeUnload() {
        this.cleanup();
    }

    handleEmbedError(error) {
        console.error('FP: Embed error:', error);
        this.showError('Playback error: ' + error.message);
    }

    /**
     * UI State Management
     */
    showLoadingState(type) {
        if (type === 'files' && this.elements['fp-loading-files']) {
            this.elements['fp-loading-files'].style.display = 'flex';
        } else if (type === 'score' && this.elements['fp-loading-score']) {
            this.elements['fp-loading-score'].style.display = 'flex';
        }
    }

    hideLoadingState(type) {
        if (type === 'files' && this.elements['fp-loading-files']) {
            this.elements['fp-loading-files'].style.display = 'none';
        } else if (type === 'score' && this.elements['fp-loading-score']) {
            this.elements['fp-loading-score'].style.display = 'none';
        }
    }

    showEmptyState() {
        if (this.elements['fp-empty-state']) {
            this.elements['fp-empty-state'].style.display = 'flex';
        }
    }

    hideEmptyState() {
        if (this.elements['fp-empty-state']) {
            this.elements['fp-empty-state'].style.display = 'none';
        }
    }

    showWelcome() {
        if (this.elements['fp-welcome']) {
            this.elements['fp-welcome'].style.display = 'flex';
        }
    }

    hideWelcome() {
        if (this.elements['fp-welcome']) {
            this.elements['fp-welcome'].style.display = 'none';
        }
    }

    showScoreArea() {
        if (this.elements['fp-flatio-container']) {
            this.elements['fp-flatio-container'].style.display = 'flex';
        }
        this.hideErrorState();
    }

    showPlayerControls() {
        if (this.elements['fp-player-controls']) {
            this.elements['fp-player-controls'].style.display = 'block';
        }
    }

    hidePlayerControls() {
        if (this.elements['fp-player-controls']) {
            this.elements['fp-player-controls'].style.display = 'none';
        }
    }

    showErrorState() {
        if (this.elements['fp-error-state']) {
            this.elements['fp-error-state'].style.display = 'flex';
        }
        if (this.elements['fp-flatio-container']) {
            this.elements['fp-flatio-container'].style.display = 'none';
        }
    }

    hideErrorState() {
        if (this.elements['fp-error-state']) {
            this.elements['fp-error-state'].style.display = 'none';
        }
    }

    updatePlaybackUI(isPlaying) {
        if (this.elements['fp-play-btn']) {
            this.elements['fp-play-btn'].style.display = isPlaying ? 'none' : 'flex';
        }
        if (this.elements['fp-pause-btn']) {
            this.elements['fp-pause-btn'].style.display = isPlaying ? 'flex' : 'none';
        }
    }

    updateTrackInfo(metadata) {
        if (this.elements['fp-current-title']) {
            this.elements['fp-current-title'].textContent = metadata.name || 'Unknown Title';
        }
        if (this.elements['fp-current-composer']) {
            this.elements['fp-current-composer'].textContent = metadata.composer || '';
        }
    }

    showError(message) {
        console.error('FP: Error:', message);
        
        // Update error state
        if (this.elements['fp-error-title']) {
            this.elements['fp-error-title'].textContent = 'Unable to load score';
        }
        if (this.elements['fp-error-message']) {
            this.elements['fp-error-message'].textContent = message;
        }
        
        this.showErrorState();
        
        // Show Nextcloud notification if available
        if (window.OC && window.OC.Notification) {
            window.OC.Notification.showTemporary(message);
        }
        
        // Announce to screen readers
        this.announceToScreenReader('Error: ' + message);
    }

    /**
     * Language Support
     */
    setupLanguageSelector() {
        const selector = this.elements['fp-language-selector'];
        if (!selector) return;

        // Set current language
        const currentLang = document.documentElement.lang || 'en';
        selector.value = currentLang;

        // Handle changes
        selector.addEventListener('change', (event) => {
            this.changeLanguage(event.target.value);
        });
    }

    changeLanguage(langCode) {
        // This would typically integrate with Nextcloud's i18n system
        // For now, we'll store the preference
        if (window.localStorage) {
            localStorage.setItem('fp-language', langCode);
        }
        
        console.info(`FP: Language changed to ${langCode}`);
        this.announceToScreenReader(`Language changed to ${langCode}`);
    }

    /**
     * Auto-refresh setup
     */
    setupAutoRefresh() {
        setInterval(() => {
            if (document.visibilityState === 'visible' && this.isInitialized) {
                this.loadFiles().catch(error => {
                    console.warn('FP: Auto-refresh failed:', error);
                });
            }
        }, this.config.refreshInterval);
    }

    /**
     * Utility Methods
     */
    formatFileSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }

    formatDate(timestamp) {
        const date = new Date(timestamp * 1000);
        return date.toLocaleDateString(undefined, {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    debounce(func, delay) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, delay);
        };
    }

    announceToScreenReader(message) {
        const announcement = document.getElementById('fp-screen-reader-announcements');
        if (announcement) {
            announcement.textContent = message;
            // Clear after a delay
            setTimeout(() => {
                announcement.textContent = '';
            }, 1000);
        }
    }

    /**
     * Public API Methods
     */
    async refreshFiles() {
        return this.loadFiles();
    }

    getCurrentFile() {
        return this.currentFile;
    }

    getSelectedFile() {
        if (this.selectedIndex >= 0 && this.selectedIndex < this.files.length) {
            return this.files[this.selectedIndex];
        }
        return null;
    }

    isPlaying() {
        return this.embedManager ? this.embedManager.isPlaying() : false;
    }

    /**
     * Cleanup and destruction
     */
    cleanup() {
        console.info('FP: Cleaning up...');

        // Remove event listeners
        Object.entries(this.boundHandlers).forEach(([event, handler]) => {
            if (event === 'keyboard') {
                document.removeEventListener('keydown', handler);
            } else if (event === 'beforeUnload') {
                window.removeEventListener('beforeunload', handler);
            } else {
                // Remove from cached elements
                Object.values(this.elements).forEach(element => {
                    if (element && element.removeEventListener) {
                        element.removeEventListener('click', handler);
                        element.removeEventListener('input', handler);
                        element.removeEventListener('change', handler);
                    }
                });
            }
        });

        // Cleanup components
        if (this.embedManager) {
            this.embedManager.destroy();
            this.embedManager = null;
        }

        // Clear state
        this.isInitialized = false;
        this.currentFile = null;
        this.files = [];
        this.selectedIndex = -1;
        
        console.info('FP: Cleanup complete');
    }

    destroy() {
        this.cleanup();
    }
}

// Auto-initialization when DOM is ready
document.addEventListener('DOMContentLoaded', async () => {
    try {
        console.info('FP: DOM ready, initializing Flat.io Player...');
        
        // Check for required dependencies
        if (typeof FlatioEmbedManager === 'undefined') {
            throw new Error('FlatioEmbedManager not loaded');
        }
        
        if (typeof MusicXMLValidator === 'undefined') {
            throw new Error('MusicXMLValidator not loaded');
        }
        
        // Initialize player
        window.FlatioPlayer = FlatioPlayer;
        window.fpApp = new FlatioPlayer();
        await window.fpApp.init();
        
        console.info('FP: Application ready!');
        
    } catch (error) {
        console.error('FP: Initialization failed:', error);
        
        // Show user-friendly error
        const errorDiv = document.createElement('div');
        errorDiv.className = 'fp-init-error';
        errorDiv.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 2rem;
            background: var(--color-error);
            color: var(--color-primary-text);
            border-radius: var(--border-radius-large);
            max-width: 500px;
            text-align: center;
            z-index: 9999;
            box-shadow: var(--box-shadow);
        `;
        
        errorDiv.innerHTML = `
            <div style="font-size: 2rem; margin-bottom: 1rem;">⚠️</div>
            <h3 style="margin-bottom: 1rem;">Failed to Load</h3>
            <p style="margin-bottom: 1.5rem;">Flat.io Player could not initialize. Please refresh the page or contact your administrator.</p>
            <button onclick="location.reload()" style="
                padding: 0.5rem 1rem;
                background: rgba(255,255,255,0.2);
                border: 1px solid rgba(255,255,255,0.3);
                border-radius: var(--border-radius);
                color: inherit;
                cursor: pointer;
            ">Refresh Page</button>
        `;
        
        document.body.appendChild(errorDiv);
    }
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (window.fpApp) {
        window.fpApp.cleanup();
    }
});

// Export for external use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = FlatioPlayer;
}
        };
    }

    throttle(func, limit) {
        let inThrottle;
        return function(...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }

    announceToScreenReader(message) {
        const announcement = document.getElementById('fp-screen-reader-announcements');
        if (announcement) {
            announcement.textContent = message;
            // Clear after a delay
            setTimeout(() => {
                announcement.textContent = '';
            }, 1000);
        }
    }

    /**
     * Public API Methods
     */
    async refreshFiles() {
        return this.loadFiles();
    }

    getCurrentFile() {
        return this.currentFile;
    }

    getSelectedFile() {
        if (this.selectedIndex >= 0 && this.selectedIndex < this.files.length) {
            return this.files[this.selectedIndex];
        }
        return null;
    }

    isPlaying() {
        return this.embedManager ? this.embedManager.isPlaying() : false;
    }

    /**
     * Cleanup and destruction
     */
    cleanup() {
        this.log.info('Cleaning up...');

        // Remove event listeners
        Object.entries(this.boundHandlers).forEach(([event, handler]) => {
            if (event === 'keyboard') {
                document.removeEventListener('keydown', handler);
            } else if (event === 'beforeUnload') {
                window.removeEventListener('beforeunload', handler);
            } else {
                // Remove from cached elements
                Object.values(this.elements).forEach(element => {
                    if (element && element.removeEventListener) {
                        element.removeEventListener('click', handler);
                        element.removeEventListener('input', handler);
                        element.removeEventListener('change', handler);
                    }
                });
            }
        });

        // Cleanup components
        if (this.embedManager) {
            this.embedManager.destroy();
            this.embedManager = null;
        }

        // Clear state
        this.isInitialized = false;
        this.currentFile = null;
        this.files = [];
        this.selectedIndex = -1;
        
        this.log.info('Cleanup complete');
    }

    destroy() {
        this.cleanup();
    }
}

// Auto-initialization when DOM is ready
document.addEventListener('DOMContentLoaded', async () => {
    try {
        if (typeof FlatioEmbedManager === 'undefined') {
            throw new Error('FlatioEmbedManager not loaded');
        }
        
        if (typeof MusicXMLValidator === 'undefined') {
            throw new Error('MusicXMLValidator not loaded');
        }
        
        // Initialize player
        window.FlatioPlayer = FlatioPlayer;
        window.fpApp = new FlatioPlayer();
        await window.fpApp.init();
        
    } catch (error) {
        console.error('FP: Initialization failed:', error);
        
        // Show user-friendly error
        const errorDiv = document.createElement('div');
        errorDiv.className = 'fp-init-error';
        errorDiv.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 2rem;
            background: var(--color-error);
            color: var(--color-primary-text);
            border-radius: var(--border-radius-large);
            max-width: 500px;
            text-align: center;
            z-index: 9999;
            box-shadow: var(--box-shadow);
        `;
        
        errorDiv.innerHTML = `
            <div style="font-size: 2rem; margin-bottom: 1rem;">⚠️</div>
            <h3 style="margin-bottom: 1rem;">Failed to Load</h3>
            <p style="margin-bottom: 1.5rem;">Flat.io Player could not initialize. Please refresh the page or contact your administrator.</p>
            <button onclick="location.reload()" style="
                padding: 0.5rem 1rem;
                background: rgba(255,255,255,0.2);
                border: 1px solid rgba(255,255,255,0.3);
                border-radius: var(--border-radius);
                color: inherit;
                cursor: pointer;
            ">Refresh Page</button>
        `;
        
        document.body.appendChild(errorDiv);
    }
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (window.fpApp) {
        window.fpApp.cleanup();
    }
});

// Export for external use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = FlatioPlayer;
}
