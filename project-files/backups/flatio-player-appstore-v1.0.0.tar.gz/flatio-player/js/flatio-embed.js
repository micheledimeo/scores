/**
 * Flat.io Embed Manager - Optimized for Production
 * Handles Flat.io integration with error recovery and performance optimizations
 */

'use strict';

class FlatioEmbedManager {
    constructor() {
        this.embed = null;
        this.isReady = false;
        this.currentScore = null;
        this.onError = null;
        this.config = {
            embedUrl: 'https://embed.flat.io',
            timeout: 15000,
            debug: false
        };

        // Logging helper
        this.log = {
            info: (msg) => this.config.debug && console.info('FE:', msg),
            warn: (msg) => console.warn('FE:', msg),
            error: (msg) => console.error('FE:', msg)
        };

        this.log.info('Flat.io Embed Manager initialized');
    }

    /**
     * Load score with error handling and timeout
     */
    async loadScore(fileId) {
        if (!fileId) {
            throw new Error('File ID is required');
        }

        this.log.info(`Loading score: ${fileId}`);
        
        try {
            // Clear previous score
            this.currentScore = null;
            this.isReady = false;

            // Get score content from server
            const response = await this.fetchWithTimeout(
                OC.generateUrl(`/apps/flatioplayer/api/file/${fileId}`),
                this.config.timeout
            );

            if (!response.ok) {
                throw new Error(`Failed to fetch score: ${response.status}`);
            }

            const scoreData = await response.json();
            
            // Initialize Flat.io embed
            await this.initializeEmbed(scoreData);
            
            this.currentScore = scoreData;
            this.log.info('Score loaded successfully');

        } catch (error) {
            this.log.error(`Score loading failed: ${error.message}`);
            if (this.onError) this.onError(error);
            throw error;
        }
    }

    /**
     * Initialize Flat.io embed with retry mechanism
     */
    async initializeEmbed(scoreData) {
        const container = document.getElementById('fp-flatio-embed');
        if (!container) {
            throw new Error('Embed container not found');
        }

        // Clear container
        container.innerHTML = '';

        return new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                reject(new Error('Embed initialization timeout'));
            }, this.config.timeout);

            try {
                // Create Flat.io embed
                this.embed = new Flat.Embed(container, {
                    score: scoreData.content,
                    width: '100%',
                    height: '100%',
                    embedParams: {
                        appId: 'flatioplayer',
                        controlsPosition: 'bottom',
                        theme: 'auto',
                        showControls: true,
                        enableFullscreen: false,
                        branding: false
                    }
                });

                // Handle embed events
                this.embed.on('ready', () => {
                    clearTimeout(timeout);
                    this.isReady = true;
                    this.log.info('Embed ready');
                    resolve();
                });

                this.embed.on('error', (error) => {
                    clearTimeout(timeout);
                    this.log.error('Embed error:', error);
                    reject(new Error(`Embed error: ${error.message || 'Unknown error'}`));
                });

            } catch (error) {
                clearTimeout(timeout);
                this.log.error('Embed creation failed:', error);
                reject(error);
            }
        });
    }

    /**
     * Play score
     */
    play() {
        if (!this.isReady || !this.embed) {
            this.log.warn('Cannot play: embed not ready');
            return false;
        }

        try {
            this.embed.play();
            return true;
        } catch (error) {
            this.log.error('Play failed:', error);
            if (this.onError) this.onError(error);
            return false;
        }
    }

    /**
     * Pause playback
     */
    pause() {
        if (!this.isReady || !this.embed) {
            this.log.warn('Cannot pause: embed not ready');
            return false;
        }

        try {
            this.embed.pause();
            return true;
        } catch (error) {
            this.log.error('Pause failed:', error);
            if (this.onError) this.onError(error);
            return false;
        }
    }

    /**
     * Stop playback
     */
    stop() {
        if (!this.isReady || !this.embed) {
            this.log.warn('Cannot stop: embed not ready');
            return false;
        }

        try {
            this.embed.stop();
            return true;
        } catch (error) {
            this.log.error('Stop failed:', error);
            if (this.onError) this.onError(error);
            return false;
        }
    }

    /**
     * Set volume (0.0 to 1.0)
     */
    setVolume(volume) {
        if (!this.isReady || !this.embed) {
            this.log.warn('Cannot set volume: embed not ready');
            return false;
        }

        const normalizedVolume = Math.max(0, Math.min(1, volume));

        try {
            this.embed.setVolume(normalizedVolume);
            return true;
        } catch (error) {
            this.log.error('Volume change failed:', error);
            if (this.onError) this.onError(error);
            return false;
        }
    }

    /**
     * Check if currently playing
     */
    isPlaying() {
        if (!this.isReady || !this.embed) {
            return false;
        }

        try {
            return this.embed.isPlaying();
        } catch (error) {
            this.log.error('Status check failed:', error);
            return false;
        }
    }

    /**
     * Get current playback position
     */
    getCurrentTime() {
        if (!this.isReady || !this.embed) {
            return 0;
        }

        try {
            return this.embed.getCurrentTime();
        } catch (error) {
            this.log.error('Time check failed:', error);
            return 0;
        }
    }

    /**
     * Get score duration
     */
    getDuration() {
        if (!this.isReady || !this.embed) {
            return 0;
        }

        try {
            return this.embed.getDuration();
        } catch (error) {
            this.log.error('Duration check failed:', error);
            return 0;
        }
    }

    /**
     * Fetch with timeout utility
     */
    async fetchWithTimeout(url, timeout = 10000) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeout);

        try {
            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'requesttoken': OC.requestToken,
                    'Content-Type': 'application/json'
                },
                signal: controller.signal
            });
            
            clearTimeout(timeoutId);
            return response;
        } catch (error) {
            clearTimeout(timeoutId);
            throw error;
        }
    }

    /**
     * Destroy embed and cleanup
     */
    destroy() {
        this.log.info('Destroying embed manager');

        if (this.embed) {
            try {
                this.embed.destroy();
            } catch (error) {
                this.log.warn('Embed destruction warning:', error);
            }
            this.embed = null;
        }

        this.isReady = false;
        this.currentScore = null;
        this.onError = null;

        this.log.info('Embed manager destroyed');
    }
}

// Make available globally
if (typeof window !== 'undefined') {
    window.FlatioEmbedManager = FlatioEmbedManager;
}

// Export for Node.js environments
if (typeof module !== 'undefined' && module.exports) {
    module.exports = FlatioEmbedManager;
}
