                            </div>
                        </div>

                        <!-- Flat.io Embed Container -->
                        <div id="fp-flatio-container" class="fp-flatio-container" style="display: none;">
                            <div id="fp-flatio-embed" class="fp-flatio-embed"></div>
                        </div>

                        <!-- Loading state for score -->
                        <div id="fp-loading-score" class="fp-loading-score" style="display: none;">
                            <div class="fp-loading-content">
                                <div class="fp-spinner fp-spinner-large"></div>
                                <h3><?php p($l->t('Loading score...')); ?></h3>
                                <p><?php p($l->t('Preparing professional notation')); ?></p>
                            </div>
                        </div>

                        <!-- Error state -->
                        <div id="fp-error-state" class="fp-error-state" style="display: none;">
                            <div class="fp-error-content">
                                <div class="fp-error-icon">⚠️</div>
                                <h3 id="fp-error-title"><?php p($l->t('Unable to load score')); ?></h3>
                                <p id="fp-error-message"></p>
                                <button id="fp-retry-button" class="fp-button fp-button-primary">
                                    <?php p($l->t('Try again')); ?>
                                </button>
                            </div>
                        </div>

                    </section>

                </main>

                <!-- Player controls (when score is loaded) -->
                <div id="fp-player-controls" class="fp-player-controls" style="display: none;">
                    <div class="fp-controls-content">
                        <div class="fp-controls-left">
                            <button id="fp-play-btn" class="fp-button fp-button-primary fp-control-btn">
                                <span class="icon icon-play"></span>
                            </button>
                            <button id="fp-pause-btn" class="fp-button fp-button-primary fp-control-btn" style="display: none;">
                                <span class="icon icon-pause"></span>
                            </button>
                            <button id="fp-stop-btn" class="fp-button fp-button-secondary fp-control-btn">
                                <span class="icon icon-close"></span>
                            </button>
                        </div>
                        
                        <div class="fp-controls-center">
                            <div class="fp-track-info">
                                <h4 id="fp-current-title"><?php p($l->t('No score loaded')); ?></h4>
                                <p id="fp-current-composer"></p>
                            </div>
                        </div>
                        
                        <div class="fp-controls-right">
                            <div class="fp-volume-control">
                                <span class="icon icon-sound"></span>
                                <input type="range" id="fp-volume-slider" min="0" max="100" value="80">
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Accessibility improvements -->
<div id="fp-screen-reader-announcements" aria-live="polite" class="screen-reader-text"></div>

<script nonce="<?php p(\OCP\Util::getCSPNonce()); ?>">
// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    if (window.FlatioPlayer) {
        window.fpApp = new FlatioPlayer();
        window.fpApp.init();
    } else {
        console.error('Flat.io Player: Main class not loaded');
    }
});

// Global error handler for Flat.io embed
window.addEventListener('error', function(event) {
    if (event.filename && event.filename.includes('embed.flat.io')) {
        console.error('Flat.io embed error:', event.error);
        if (window.fpApp) {
            window.fpApp.handleEmbedError(event.error);
        }
    }
});
</script>
