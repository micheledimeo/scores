# MusicXML Scores for Nextcloud

Display, play, and manage MusicXML files directly in Nextcloud using OpenSheetMusicDisplay.

## Features

- 🎼 **Sheet Music Display**: Render MusicXML, MusicXML compressed (.mxl), and other music notation formats
- ▶️ **Advanced Playback Controls**: Play, pause, stop, and loop with real-time cursor tracking
- 🎚️ **Instrument Mixer**: Individual volume control for each instrument/channel with solo/mute capabilities
- 🎵 **Tempo & Volume Control**: Precise BPM adjustment (40-240) and master volume with numeric inputs
- 📊 **Progress Tracking**: Visual progress bar with current time and measure indicators
- ⌨️ **Keyboard Shortcuts**: Space (play/pause), arrows (navigate measures), +/- (zoom)
- 🔍 **Smart Search**: Real-time search across all scores and folders
- 📱 **Responsive Design**: Adaptive layout with collapsible sidebar
- 🔄 **Files App Integration**: Upload and share scores using Nextcloud Files app
- 🎯 **Admin Settings**: Configure scores folder path for all users

## Supported Formats

- MusicXML (.xml, .musicxml)
- MusicXML Compressed (.mxl)
- MEI (Music Encoding Initiative)
- Guitar Pro files (.gp, .gp3, .gp4, .gp5, .gpx)

## Installation

### Prerequisites

- Nextcloud 28 or later
- Node.js 20 or later
- npm 10 or later

### Development Setup

1. Clone or copy this directory to your Nextcloud `apps/` folder
2. Install dependencies:
   ```bash
   npm install
   ```
3. Build the app:
   ```bash
   npm run build
   ```
4. Enable the app in Nextcloud:
   ```bash
   php occ app:enable mxmlscores
   ```

### Production Build

For production, run:
```bash
npm run build
```

This will create optimized files in the `js/` directory.

### Development Mode

For development with hot reload:
```bash
npm run watch
```

## Usage

### Basic Usage

1. Navigate to the **Scores** app in Nextcloud
2. Use the search box to find specific scores, or browse the folder tree
3. Click on a score file to open it
4. The sheet music will be displayed with playback controls

### Playback Controls

- **Play/Pause/Stop**: Control playback with buttons or press `Space`
- **Loop**: Enable loop mode to repeat playback continuously
- **Tempo (BPM)**: Adjust playback speed from 40 to 240 BPM using numeric input
- **Volume (VOL)**: Control master volume from 0 to 100 using numeric input
- **Mixer**: Toggle instrument mixer to solo/mute individual channels (when available)
- **Progress Bar**: Visual timeline showing current playback position with time and measure count

### Navigation

- **Keyboard Shortcuts**:
  - `Space`: Play / Pause
  - `←` `→`: Navigate between measures
  - `+` `-`: Zoom in / out
- **Responsive Layout**: Toggle sidebar visibility to maximize sheet music viewing area

### File Management

- **Upload**: Use the Nextcloud **Files** app to upload new MusicXML files
- **Sharing**: Use the Nextcloud **Files** app to share scores with other users
- **Search**: Real-time search filters both folder names and file names

### Admin Configuration

Administrators can configure the default scores folder path:
1. Click on **Scores Settings** in the sidebar footer
2. Browse and select the folder containing music scores
3. The path is relative to each user's home directory
4. Leave empty to scan all user files

## Project Structure

```
mxmlscores/
├── appinfo/
│   ├── info.xml          # App metadata
│   └── routes.php        # App routes
├── lib/
│   └── Controller/       # PHP controllers
│       ├── PageController.php
│       ├── ApiController.php
│       └── SettingsController.php
├── src/
│   ├── main.js           # Vue app entry point
│   ├── init-app.js       # App initialization
│   ├── components/       # Vue components
│   │   ├── App.vue       # Main app with navigation
│   │   └── MusicViewer.vue  # Score viewer with playback
│   ├── utils/            # Utility classes
│   │   └── MixerInstrumentPlayer.js  # Mixer implementation
│   └── css/
│       └── main.scss     # Global styles
├── templates/
│   ├── main.php          # Main template
│   └── public.php        # Public share template
├── js/                   # Build output
│   ├── mxml-scores-main.js
│   └── init-app.js
├── css/                  # Build output
│   └── main.css
├── package.json          # Node dependencies
├── vite.config.js        # Vite configuration
└── README.md             # This file
```

## Development

### Adding New Features

1. Create new Vue components in `src/components/`
2. Add new routes in `appinfo/routes.php`
3. Create corresponding controllers in `lib/Controller/`
4. Build and test

### Debugging

- Enable Nextcloud debug mode in `config.php`:
  ```php
  'debug' => true,
  ```
- Check browser console for JavaScript errors
- Check Nextcloud logs for PHP errors: `data/nextcloud.log`

## Technologies Used

- **OpenSheetMusicDisplay**: Music notation rendering
- **Vue 3**: Frontend framework
- **Vite**: Build tool
- **Nextcloud Vue Components**: UI components
- **PHP**: Backend API

## License

AGPL-3.0-or-later

## Credits

- Built with [OpenSheetMusicDisplay](https://opensheetmusicdisplay.org/)
- Inspired by the WordPress OpenSheetMusicDisplay plugin

## Support

For issues and feature requests, please use the issue tracker on the repository.
