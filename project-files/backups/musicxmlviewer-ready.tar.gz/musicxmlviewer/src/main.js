import { createApp } from 'vue'
import App from './components/App.vue'

// Stili globali
import './css/main.scss'

const app = createApp(App)
app.mount('#app')
