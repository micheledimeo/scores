 solid var(--color-border-dark);
            }
            
            .fp-diag-table th {
                background: var(--color-background-dark);
                font-weight: 600;
                color: var(--color-main-text);
            }
            
            .fp-diag-table td {
                color: var(--color-text-lighter);
            }
            
            .fp-diag-status-ok {
                color: #2ECC71;
                font-weight: 600;
            }
            
            .fp-diag-status-error {
                color: #E74C3C;
                font-weight: 600;
            }
            
            .fp-diag-status-warning {
                color: #F39C12;
                font-weight: 600;
            }
        `;

        document.head.appendChild(style);
        document.body.appendChild(modal);

        // Add close event listeners
        modal.querySelectorAll('.fp-diagnostics-close').forEach(btn => {
            btn.addEventListener('click', () => {
                modal.remove();
                style.remove();
            });
        });

        // Close on backdrop click
        modal.querySelector('.fp-diagnostics-backdrop').addEventListener('click', () => {
            modal.remove();
            style.remove();
        });
    }

    /**
     * Generate HTML for diagnostics data
     */
    generateDiagnosticsHTML(data) {
        const { installation_info, current_status, diagnostics } = data;
        
        let html = `
            <div class="fp-diag-section">
                <h3>📍 Installation Information</h3>
                <table class="fp-diag-table">
                    <tr>
                        <th>Property</th>
                        <th>Value</th>
                    </tr>
                    <tr>
                        <td>Nextcloud Path</td>
                        <td>${installation_info.nextcloud_path}</td>
                    </tr>
                    <tr>
                        <td>App Path</td>
                        <td>${installation_info.app_path}</td>
                    </tr>
                    <tr>
                        <td>Detected Owner</td>
                        <td>${installation_info.owner}:${installation_info.group}</td>
                    </tr>
                </table>
            </div>

            <div class="fp-diag-section">
                <h3>🔍 Current Status</h3>
                <table class="fp-diag-table">
                    <tr>
                        <th>Check</th>
                        <th>Status</th>
                    </tr>
                    <tr>
                        <td>App Directory Exists</td>
                        <td class="${current_status.app_exists ? 'fp-diag-status-ok' : 'fp-diag-status-error'}">
                            ${current_status.app_exists ? '✅ Yes' : '❌ No'}
                        </td>
                    </tr>
                    <tr>
                        <td>Critical Files Present</td>
                        <td class="${current_status.critical_files_exist ? 'fp-diag-status-ok' : 'fp-diag-status-error'}">
                            ${current_status.critical_files_exist ? '✅ Yes' : '❌ No'}
                        </td>
                    </tr>
                    <tr>
                        <td>Permissions Correct</td>
                        <td class="${current_status.permissions_correct ? 'fp-diag-status-ok' : 'fp-diag-status-error'}">
                            ${current_status.permissions_correct ? '✅ Yes' : '❌ No'}
                        </td>
                    </tr>
                    <tr>
                        <td>Owner Correct</td>
                        <td class="${current_status.owner_correct ? 'fp-diag-status-ok' : 'fp-diag-status-error'}">
                            ${current_status.owner_correct ? '✅ Yes' : '❌ No'}
                        </td>
                    </tr>
                    <tr>
                        <td>Overall Status</td>
                        <td class="${current_status.properly_configured ? 'fp-diag-status-ok' : 'fp-diag-status-error'}">
                            ${current_status.properly_configured ? '✅ Properly Configured' : '❌ Needs Configuration'}
                        </td>
                    </tr>
                </table>
            </div>

            <div class="fp-diag-section">
                <h3>🖥️ Environment</h3>
                <table class="fp-diag-table">
                    <tr>
                        <th>Property</th>
                        <th>Value</th>
                    </tr>
                    <tr>
                        <td>PHP User</td>
                        <td>${diagnostics.php_user}</td>
                    </tr>
                    <tr>
                        <td>Current User</td>
                        <td>${diagnostics.current_user}</td>
                    </tr>
                    <tr>
                        <td>PHP Version</td>
                        <td>${diagnostics.environment.php_version}</td>
                    </tr>
                    <tr>
                        <td>Operating System</td>
                        <td>${diagnostics.environment.os}</td>
                    </tr>
                    <tr>
                        <td>Server Software</td>
                        <td>${diagnostics.environment.server_software}</td>
                    </tr>
                    <tr>
                        <td>Nextcloud Version</td>
                        <td>${diagnostics.nextcloud_version}</td>
                    </tr>
                    <tr>
                        <td>App Version</td>
                        <td>${diagnostics.app_version}</td>
                    </tr>
                </table>
            </div>
        `;

        // Add file permissions if available
        if (diagnostics.file_permissions && Object.keys(diagnostics.file_permissions).length > 0) {
            html += `
                <div class="fp-diag-section">
                    <h3>📄 File Permissions</h3>
                    <table class="fp-diag-table">
                        <tr>
                            <th>File</th>
                            <th>Permissions</th>
                            <th>Owner</th>
                            <th>Status</th>
                        </tr>
            `;
            
            for (const [file, info] of Object.entries(diagnostics.file_permissions)) {
                const isOk = info.readable && info.owner === installation_info.owner;
                html += `
                    <tr>
                        <td>${file}</td>
                        <td>${info.permissions}</td>
                        <td>${info.owner}:${info.group}</td>
                        <td class="${isOk ? 'fp-diag-status-ok' : 'fp-diag-status-warning'}">
                            ${isOk ? '✅' : '⚠️'} ${info.readable ? 'R' : ''}${info.writable ? 'W' : ''}
                        </td>
                    </tr>
                `;
            }
            
            html += `
                    </table>
                </div>
            `;
        }

        // Add missing files if any
        if (diagnostics.missing_files && diagnostics.missing_files.length > 0) {
            html += `
                <div class="fp-diag-section">
                    <h3>❌ Missing Files</h3>
                    <ul>
            `;
            
            diagnostics.missing_files.forEach(file => {
                html += `<li style="color: #E74C3C;">${file}</li>`;
            });
            
            html += `
                    </ul>
                </div>
            `;
        }

        return html;
    }

    /**
     * Add installation indicator to navigation
     */
    addInstallationIndicator() {
        // Add indicator to app navigation or admin menu
        const nav = document.querySelector('.app-navigation, #navigation');
        
        if (nav && !document.getElementById('fp-install-indicator')) {
            const indicator = document.createElement('li');
            indicator.id = 'fp-install-indicator';
            indicator.innerHTML = `
                <a href="#" style="color: #F39C12; font-weight: 600;">
                    ⚙️ Flat.io Player Setup
                </a>
            `;
            
            indicator.addEventListener('click', (e) => {
                e.preventDefault();
                this.runAutoInstallation();
            });
            
            nav.appendChild(indicator);
        }
    }

    /**
     * Add admin settings section
     */
    addAdminSettings() {
        // This could be expanded to add a dedicated admin settings page
        // For now, we rely on the banner and notifications
    }
}

// Initialize the auto-installer
window.FlatioAutoInstaller = new FlatioAutoInstaller();

// Global function for manual installation (can be called from console)
window.runFlatioInstallation = async function() {
    if (window.FlatioAutoInstaller) {
        await window.FlatioAutoInstaller.runAutoInstallation();
    } else {
        console.error('Flat.io Auto-Installer not available');
    }
};

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = FlatioAutoInstaller;
}
