<?php

declare(strict_types=1);

namespace OCA\FlatioPlayer\Controller;

use OCA\FlatioPlayer\AppInfo\Application;
use OCA\FlatioPlayer\Service\InstallationService;
use OCP\AppFramework\Controller;
use OCP\AppFramework\Http\DataResponse;
use OCP\IRequest;
use Psr\Log\LoggerInterface;
use OCP\IUserSession;

/**
 * Installation Controller
 * 
 * Handles installation requests via web interface
 * with automatic owner detection and permission setup.
 */
class InstallController extends Controller {

    private LoggerInterface $logger;
    private IUserSession $userSession;
    private InstallationService $installationService;

    public function __construct(
        string $appName,
        IRequest $request,
        LoggerInterface $logger,
        IUserSession $userSession,
        InstallationService $installationService = null
    ) {
        parent::__construct($appName, $request);
        $this->logger = $logger;
        $this->userSession = $userSession;
        $this->installationService = $installationService ?: new InstallationService($logger);
    }

    /**
     * Check installation status
     * 
     * @NoAdminRequired
     */
    public function status(): DataResponse {
        try {
            // Only admins can check installation status
            if (!$this->userSession->getUser() || !$this->isAdmin()) {
                return new DataResponse(['error' => 'Admin privileges required'], 403);
            }

            $installInfo = $this->installationService->detectInstallationInfo();
            $status = $this->installationService->checkCurrentStatus($installInfo);

            return new DataResponse([
                'status' => 'success',
                'installation_info' => [
                    'nextcloud_path' => $installInfo['nextcloud_path'],
                    'app_path' => $installInfo['app_path'],
                    'owner' => $installInfo['owner'],
                    'group' => $installInfo['group']
                ],
                'current_status' => $status,
                'needs_installation' => !$status['properly_configured']
            ]);

        } catch (\Exception $e) {
            $this->logger->error('Flat.io Player: Status check failed: ' . $e->getMessage(), [
                'app' => $this->appName,
                'exception' => $e->getTraceAsString()
            ]);
            
            return new DataResponse([
                'status' => 'error',
                'message' => 'Status check failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Run auto-installation
     * 
     * @NoAdminRequired
     */
    public function install(): DataResponse {
        try {
            // Only admins can run installation
            if (!$this->userSession->getUser() || !$this->isAdmin()) {
                return new DataResponse(['error' => 'Admin privileges required'], 403);
            }

            $this->logger->info('Flat.io Player: Manual installation requested via web interface', [
                'app' => $this->appName,
                'user' => $this->userSession->getUser()->getUID()
            ]);

            // Run the auto-installation
            Application::runAutoInstallation();

            // Verify the installation
            $installInfo = $this->installationService->detectInstallationInfo();
            $status = $this->installationService->checkCurrentStatus($installInfo);

            if ($status['properly_configured']) {
                $this->logger->info('Flat.io Player: Manual installation completed successfully', [
                    'app' => $this->appName
                ]);

                return new DataResponse([
                    'status' => 'success',
                    'message' => 'Installation completed successfully',
                    'installation_info' => [
                        'owner' => $installInfo['owner'] . ':' . $installInfo['group'],
                        'app_path' => $installInfo['app_path']
                    ]
                ]);
            } else {
                return new DataResponse([
                    'status' => 'warning',
                    'message' => 'Installation completed but verification failed',
                    'current_status' => $status
                ], 500);
            }

        } catch (\Exception $e) {
            $this->logger->error('Flat.io Player: Manual installation failed: ' . $e->getMessage(), [
                'app' => $this->appName,
                'exception' => $e->getTraceAsString()
            ]);

            return new DataResponse([
                'status' => 'error',
                'message' => 'Installation failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get installation diagnostics
     * 
     * @NoAdminRequired
     */
    public function diagnostics(): DataResponse {
        try {
            if (!$this->userSession->getUser() || !$this->isAdmin()) {
                return new DataResponse(['error' => 'Admin privileges required'], 403);
            }

            $installInfo = $this->installationService->detectInstallationInfo();
            $status = $this->installationService->checkCurrentStatus($installInfo);

            // Additional diagnostic information
            $diagnostics = [
                'php_user' => posix_getpwuid(posix_geteuid())['name'] ?? 'unknown',
                'current_user' => get_current_user(),
                'nextcloud_version' => \OC::$server->getSystemConfig()->getValue('version'),
                'app_version' => Application::APP_VERSION,
                'file_permissions' => [],
                'directory_permissions' => [],
                'missing_files' => [],
                'environment' => [
                    'php_version' => PHP_VERSION,
                    'os' => PHP_OS,
                    'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'unknown'
                ]
            ];

            // Check file permissions in detail
            $this->gatherFilePermissions($installInfo, $diagnostics);
            
            // Check directory permissions
            $this->gatherDirectoryPermissions($installInfo, $diagnostics);

            return new DataResponse([
                'status' => 'success',
                'installation_info' => $installInfo,
                'current_status' => $status,
                'diagnostics' => $diagnostics
            ]);

        } catch (\Exception $e) {
            $this->logger->error('Flat.io Player: Diagnostics failed: ' . $e->getMessage(), [
                'app' => $this->appName,
                'exception' => $e->getTraceAsString()
            ]);

            return new DataResponse([
                'status' => 'error',
                'message' => 'Diagnostics failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Check if current user is admin
     */
    private function isAdmin(): bool {
        $user = $this->userSession->getUser();
        if (!$user) {
            return false;
        }

        $groupManager = \OC::$server->getGroupManager();
        return $groupManager->isAdmin($user->getUID());
    }

    /**
     * Gather file permissions for diagnostics
     */
    private function gatherFilePermissions(array $installInfo, array &$diagnostics): void {
        $appPath = $installInfo['app_path'];
        $criticalFiles = [
            'appinfo/info.xml',
            'lib/AppInfo/Application.php',
            'composer.json',
            'templates/main.php',
            'css/app.css',
            'js/flatio-player.js'
        ];

        foreach ($criticalFiles as $file) {
            $fullPath = $appPath . '/' . $file;
            if (file_exists($fullPath)) {
                $perms = fileperms($fullPath);
                $owner = posix_getpwuid(fileowner($fullPath))['name'] ?? 'unknown';
                $group = posix_getgrgid(filegroup($fullPath))['name'] ?? 'unknown';
                
                $diagnostics['file_permissions'][$file] = [
                    'permissions' => sprintf('%o', $perms & 0777),
                    'owner' => $owner,
                    'group' => $group,
                    'readable' => is_readable($fullPath),
                    'writable' => is_writable($fullPath)
                ];
            } else {
                $diagnostics['missing_files'][] = $file;
            }
        }
    }

    /**
     * Gather directory permissions for diagnostics
     */
    private function gatherDirectoryPermissions(array $installInfo, array &$diagnostics): void {
        $appPath = $installInfo['app_path'];
        $criticalDirs = [
            '',
            'appinfo',
            'lib',
            'css',
            'js',
            'templates',
            'img',
            'l10n'
        ];

        foreach ($criticalDirs as $dir) {
            $fullPath = $appPath . ($dir ? '/' . $dir : '');
            if (is_dir($fullPath)) {
                $perms = fileperms($fullPath);
                $owner = posix_getpwuid(fileowner($fullPath))['name'] ?? 'unknown';
                $group = posix_getgrgid(filegroup($fullPath))['name'] ?? 'unknown';
                
                $diagnostics['directory_permissions'][$dir ?: 'root'] = [
                    'permissions' => sprintf('%o', $perms & 0777),
                    'owner' => $owner,
                    'group' => $group,
                    'readable' => is_readable($fullPath),
                    'writable' => is_writable($fullPath)
                ];
            }
        }
    }
}
