<?php

declare(strict_types=1);

namespace OCA\FlatioPlayer\Command;

use OCA\FlatioPlayer\AppInfo\Application;
use OCA\FlatioPlayer\Service\InstallationService;
use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

/**
 * OCC Command for manual installation of Flat.io Player
 * 
 * Usage: php occ flatioplayer:install
 */
class InstallCommand extends Command {

    private InstallationService $installationService;
    private LoggerInterface $logger;

    public function __construct(InstallationService $installationService = null, LoggerInterface $logger = null) {
        parent::__construct();
        $this->installationService = $installationService ?: new InstallationService(\OC::$server->get(LoggerInterface::class));
        $this->logger = $logger ?: \OC::$server->get(LoggerInterface::class);
    }

    protected function configure(): void {
        $this->setName('flatioplayer:install')
             ->setDescription('Install and configure Flat.io Player with automatic owner detection')
             ->addOption(
                 'force',
                 'f',
                 InputOption::VALUE_NONE,
                 'Force installation even if already configured'
             )
             ->addOption(
                 'owner',
                 'o',
                 InputOption::VALUE_REQUIRED,
                 'Manually specify file owner (auto-detected if not provided)'
             )
             ->addOption(
                 'dry-run',
                 null,
                 InputOption::VALUE_NONE,
                 'Show what would be done without making changes'
             );
    }

    protected function execute(InputInterface $input, OutputInterface $output): int {
        $io = new SymfonyStyle($input, $output);
        
        $io->title('🎼 Flat.io Player Auto-Installation');
        $io->text('Automatic owner detection and permission setup for Nextcloud');
        $io->newLine();

        try {
            // Check if dry run
            $dryRun = $input->getOption('dry-run');
            if ($dryRun) {
                $io->warning('DRY RUN MODE - No changes will be made');
            }

            // Detect installation info
            $io->section('📍 Detecting Installation Environment');
            
            $installInfo = $this->getInstallationInfo($input->getOption('owner'));
            
            $io->definitionList(
                ['Nextcloud Path' => $installInfo['nextcloud_path']],
                ['App Path' => $installInfo['app_path']],
                ['Detected Owner' => $installInfo['owner'] . ':' . $installInfo['group']],
                ['Current User' => get_current_user()],
                ['PHP Process User' => posix_getpwuid(posix_geteuid())['name'] ?? 'unknown']
            );

            // Verify we can proceed
            if (!$dryRun && !$this->verifyPermissions($installInfo, $io)) {
                return Command::FAILURE;
            }

            // Check current status
            $io->section('🔍 Current Installation Status');
            $status = $this->installationService->checkCurrentStatus($installInfo);
            
            $this->displayStatus($status, $io);
            
            if ($status['properly_configured'] && !$input->getOption('force')) {
                $io->success('Flat.io Player is already properly configured!');
                $io->text('Use --force to reinstall anyway');
                return Command::SUCCESS;
            }

            // Perform installation
            if (!$dryRun) {
                $io->section('🚀 Running Auto-Installation');
                $this->performInstallation($installInfo, $io);
            } else {
                $io->section('🚀 Installation Preview (Dry Run)');
                $this->previewInstallation($installInfo, $io);
            }

            // Verify results
            if (!$dryRun) {
                $io->section('✅ Verification');
                $finalStatus = $this->installationService->checkCurrentStatus($installInfo);
                
                if ($finalStatus['properly_configured']) {
                    $io->success('🎉 Flat.io Player installation completed successfully!');
                    $io->text('The app is now ready to use at: https://your-domain.com/nextcloud');
                    return Command::SUCCESS;
                } else {
                    $io->error('Installation completed but verification failed');
                    $this->displayStatus($finalStatus, $io);
                    return Command::FAILURE;
                }
            } else {
                $io->success('🎯 Dry run completed - ready for installation');
                $io->text('Run without --dry-run to perform actual installation');
                return Command::SUCCESS;
            }

        } catch (\Exception $e) {
            $io->error('Installation failed: ' . $e->getMessage());
            $io->text('Check Nextcloud logs for more details');
            return Command::FAILURE;
        }
    }

    private function getInstallationInfo(?string $manualOwner): array {
        // Use manual owner if provided
        if ($manualOwner) {
            $parts = explode(':', $manualOwner);
            $owner = $parts[0];
            $group = $parts[1] ?? $owner;
            
            // Verify user exists
            if (posix_getpwnam($owner) === false) {
                throw new \InvalidArgumentException("User '$owner' does not exist");
            }
            
            $nextcloudPath = \OC::$SERVERROOT;
            return [
                'nextcloud_path' => $nextcloudPath,
                'app_path' => $nextcloudPath . '/apps/' . Application::APP_ID,
                'owner' => $owner,
                'group' => $group
            ];
        }
        
        // Use service for auto-detection
        return $this->installationService->detectInstallationInfo();
    }

    private function verifyPermissions(array $installInfo, SymfonyStyle $io): bool {
        $currentUser = posix_getpwuid(posix_geteuid())['name'] ?? 'unknown';
        
        // Check if we're running as root or the target owner
        if ($currentUser !== 'root' && $currentUser !== $installInfo['owner']) {
            $io->warning([
                'Permission Notice:',
                "Current user: $currentUser",
                "Target owner: {$installInfo['owner']}",
                '',
                'You may need to run this command with sudo or as the correct user.',
                'The installation will attempt to proceed but may fail on permission changes.'
            ]);
            
            if (!$io->confirm('Continue anyway?', false)) {
                return false;
            }
        }
        
        return true;
    }

    private function displayStatus(array $status, SymfonyStyle $io): void {
        $rows = [
            ['App Directory Exists', $status['app_exists'] ? '✅ Yes' : '❌ No'],
            ['Critical Files Present', $status['critical_files_exist'] ? '✅ Yes' : '❌ No'],
            ['Permissions Correct', $status['permissions_correct'] ? '✅ Yes' : '❌ No'],
            ['Owner Correct', $status['owner_correct'] ? '✅ Yes' : '❌ No'],
            ['Overall Status', $status['properly_configured'] ? '✅ Configured' : '❌ Needs Setup']
        ];
        
        $io->table(['Check', 'Status'], $rows);
    }

    private function performInstallation(array $installInfo, SymfonyStyle $io): void {
        $progressBar = $io->createProgressBar(4);
        $progressBar->setFormat('verbose');
        $progressBar->start();

        $io->text('Setting up permissions...');
        $this->installationService->setupPermissions($installInfo);
        $progressBar->advance();

        $io->text('Creating directories...');
        $this->installationService->setupDirectories($installInfo);
        $progressBar->advance();

        $io->text('Verifying installation...');
        $this->installationService->verifyInstallation($installInfo);
        $progressBar->advance();

        $io->text('Finalizing...');
        $progressBar->advance();
        $progressBar->finish();
        
        $io->newLine(2);
        $io->text('✅ Installation completed');
    }

    private function previewInstallation(array $installInfo, SymfonyStyle $io): void {
        $io->text('Would perform the following actions:');
        $io->listing([
            "Set ownership of {$installInfo['app_path']} to {$installInfo['owner']}:{$installInfo['group']}",
            'Set directory permissions to 755',
            'Set file permissions to 644',
            'Create missing directories if needed',
            'Verify critical files exist'
        ]);
    }
}
