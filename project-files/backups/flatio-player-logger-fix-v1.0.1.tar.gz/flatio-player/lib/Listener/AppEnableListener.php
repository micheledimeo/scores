<?php

declare(strict_types=1);

namespace OCA\FlatioPlayer\Listener;

use OCP\App\Events\AppEnableEvent;
use OCP\EventDispatcher\Event;
use OCP\EventDispatcher\IEventListener;
use Psr\Log\LoggerInterface;
use OCA\FlatioPlayer\AppInfo\Application;

/**
 * App Enable Event Listener
 * 
 * Triggers auto-installation when the Flat.io Player app is enabled
 * in Nextcloud, with automatic owner detection and permission setup.
 */
class AppEnableListener implements IEventListener {

    private LoggerInterface $logger;

    public function __construct(LoggerInterface $logger) {
        $this->logger = $logger;
    }

    public function handle(Event $event): void {
        if (!($event instanceof AppEnableEvent)) {
            return;
        }

        // Check if this is our app being enabled
        if ($event->getAppId() !== Application::APP_ID) {
            return;
        }

        $this->logger->info('Flat.io Player: App enable event received', [
            'app' => Application::APP_ID
        ]);

        try {
            // Run auto-installation
            Application::runAutoInstallation();
            
            $this->logger->info('Flat.io Player: Auto-installation triggered successfully', [
                'app' => Application::APP_ID
            ]);
            
        } catch (\Exception $e) {
            $this->logger->error('Flat.io Player: Auto-installation failed in event handler: ' . $e->getMessage(), [
                'app' => Application::APP_ID,
                'exception' => $e->getTraceAsString()
            ]);
        }
    }
}
