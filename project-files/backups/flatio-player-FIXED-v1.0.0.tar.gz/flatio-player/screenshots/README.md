# Screenshots for Nextcloud App Store

This directory should contain screenshots of the app for the Nextcloud App Store submission.

## Required Screenshots:

### 1. main-interface.png (Required)
- **Size**: 1200x800px or similar 16:10 ratio
- **Content**: Main app interface showing the file list and Flat.io embed player
- **Description**: Screenshot of the main application interface with a MusicXML file loaded

### 2. thumbnail.png (Required)  
- **Size**: 600x400px
- **Content**: Smaller version of main interface or app icon
- **Description**: Thumbnail image used in app store listings

### 3. auto-installation.png (Optional)
- **Size**: 1200x800px
- **Content**: Screenshot of the auto-installation banner or diagnostic interface
- **Description**: Shows the innovative auto-installation system

### 4. playback-controls.png (Optional)
- **Size**: 1200x800px  
- **Content**: Screenshot highlighting the playback controls and audio features
- **Description**: Shows the professional music playback capabilities

### 5. mobile-view.png (Optional)
- **Size**: 400x800px (mobile ratio)
- **Content**: Mobile/responsive view of the app
- **Description**: Demonstrates mobile-first responsive design

## Screenshot Guidelines:

- Use high-quality, clear screenshots
- Show actual functionality, not mockups
- Include realistic MusicXML content
- Ensure good lighting and contrast
- Avoid personal/sensitive information
- Use PNG format for best quality
- Keep file sizes reasonable (< 1MB each)

## Current Status:
⚠️ **PLACEHOLDER FILES** - Replace with actual screenshots before App Store submission

## How to Create Screenshots:
1. Install the app on a Nextcloud instance
2. Upload sample MusicXML files
3. Take screenshots using browser dev tools or screenshot tools
4. Resize and optimize images
5. Replace placeholder files in this directory
