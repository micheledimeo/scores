# 🚨 SOLUZIONE RAPIDA: "Could not download app musicxmlplayerflat"

## ⚡ **FIX IMMEDIATO**

Il problema è il **nome della directory**. Nextcloud richiede che la directory abbia **esattamente** lo stesso nome dell'ID app.

### **🔧 Soluzione per cloud.ottoniascoppio.org**

```bash
# 1. Accedi al server
ssh ottoniascoppio@cloud.ottoniascoppio.org

# 2. Vai alla directory apps
cd /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps

# 3. Verifica directory attuali (potrebbero esserci nomi sbagliati)
ls -la | grep -E "(flatio|musicxml)"

# 4. Rimuovi qualsiasi directory con nome sbagliato
sudo rm -rf flatio-player musicxml-player musicxmlplayer musicxmlplayerflat

# 5. Reinstalla con nome CORRETTO
sudo tar -xzf /tmp/flatio-player-v1.0.0.tar.gz
sudo mv flatio-player flatioplayer  # ← NOME ESATTO!

# 6. Fix permissions
sudo chown -R ottoniascoppio:ottoniascoppio flatioplayer
sudo chmod -R 755 flatioplayer

# 7. Pulisci cache Nextcloud
sudo -u ottoniascoppio php ../occ app:list --refresh

# 8. Ricarica Apache
sudo systemctl reload apache2
```

### **✅ Verifica Corretta**

Dopo il fix, dovresti vedere:

```bash
# Directory corretta
ls -la flatioplayer/
# drwxr-xr-x ottoniascoppio ottoniascoppio flatioplayer/

# ID corretto nel file
cat flatioplayer/appinfo/info.xml | grep "<id>"
# <id>flatioplayer</id>

# App riconosciuta da Nextcloud
sudo -u ottoniascoppio php ../occ app:list | grep flatioplayer
# - flatioplayer: Flat.io Player
```

---

## ❌ **ERRORE COMUNE**

La causa principale è che la directory si chiamava probabilmente:
- `flatio-player` (con trattino) ❌
- `musicxml-player` (nome vecchio) ❌  
- `musicxmlplayer` (senza flat.io) ❌

**DEVE chiamarsi esattamente**: `flatioplayer` ✅

---

## 🚀 **Dopo il Fix**

1. **Nel browser admin Nextcloud**:
   - Vai su **Apps** → **Your apps**
   - Dovresti vedere **"Flat.io Player"** 
   - Click **"Enable"** dovrebbe funzionare!

2. **Auto-installazione attiva**:
   - L'app si configurerà automaticamente
   - Banner di successo apparirà
   - Nessuna configurazione manuale necessaria

3. **App nel menu**:
   - **"Flat.io Player"** apparirà nel menu principale
   - Click per aprire l'interfaccia

---

## 📞 **Se il Problema Persiste**

Invia l'output di questi comandi:

```bash
# Verifica directory
ls -la /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/ | grep flatio

# Verifica ID nell'info.xml
cat /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/flatioplayer/appinfo/info.xml | grep "<id>"

# Verifica log errori
tail -20 /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/data/nextcloud.log
```

**Il nome directory `flatioplayer` (senza trattini) risolverà sicuramente il problema! 🎯**
