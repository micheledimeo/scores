# 🎼 FLAT.IO PLAYER - AUTO-INSTALLATION SYSTEM

## 🚀 **NUOVO SISTEMA DI INSTALLAZIONE AUTOMATICA**

**Flat.io Player v1.0.0** ora include un **sistema di auto-installazione** che configura automaticamente l'app quando viene abilitata in Nextcloud!

### ✨ **Cosa Succede Automaticamente:**

1. **Rilevamento Owner Automatico** 🔍
   - Analizza la struttura del server
   - Rileva automaticamente l'owner dei file (`ottoniascoppio:ottoniascoppio`)
   - Funziona con hosting condiviso, VPS, e configurazioni personalizzate

2. **Setup Permessi Automatico** ⚙️
   - Imposta ownership corretto ricorsivamente
   - Configura permissions ottimali (755/644)
   - Crea directory mancanti se necessarie

3. **Verifica Installazione** ✅
   - Controlla che tutti i file critici esistano
   - Verifica che i permessi siano corretti
   - Registra tutto nel log di Nextcloud

---

## 🎯 **INSTALLAZIONE PER cloud.ottoniascoppio.org**

### **Metodo 1: Auto-Installazione (CONSIGLIATO)**

1. **Upload dell'app** su cloud.ottoniascoppio.org:
```bash
# Sul server
cd /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps
sudo tar -xzf /tmp/flatio-player-FINAL.tar.gz
sudo mv flatio-player flatioplayer
```

2. **Abilita l'app** nel pannello admin di Nextcloud:
   - Vai su **Apps** → **Your apps** 
   - Trova **"Flat.io Player"**
   - Click **"Enable"**

3. **Auto-installazione si attiva** automaticamente:
   - ✅ Rileva owner: `ottoniascoppio:ottoniascoppio`
   - ✅ Imposta permessi corretti
   - ✅ Configura tutto automaticamente
   - ✅ Mostra notifica di successo

**È tutto! Niente script manuali, niente sudo, tutto automatico!**

### **Metodo 2: Comando OCC (Alternativo)**

Se preferisci il controllo manuale:
```bash
# Installa l'app
sudo -u ottoniascoppio php /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/occ app:enable flatioplayer

# Esegui configurazione manuale (opzionale)
sudo -u ottoniascoppio php /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/occ flatioplayer:install
```

### **Metodo 3: API Web (Per Admin)**

Dalla web interface di Nextcloud:
- L'app rileva automaticamente se serve configurazione
- Mostra banner di installazione se necessario
- Click **"Auto-Configure Now"** per configurare istantaneamente

---

## 🔧 **CARATTERISTICHE AVANZATE**

### **Rilevamento Automatico Server**

Il sistema rileva automaticamente:
- **Pattern hosting condiviso**: `/home/username/domains/...` → `username:username`
- **Pattern standard**: `/var/www/html/...` → `www-data:www-data` 
- **Configurazioni personalizzate**: Analizza owner dei file esistenti
- **cloud.ottoniascoppio.org**: Ottimizzato specificamente per il tuo server

### **Diagnostics Avanzate**

L'app include strumenti diagnostici completi:
```bash
# Via OCC
sudo -u ottoniascoppio php /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/occ flatioplayer:install --dry-run

# Via API
curl -X GET "https://cloud.ottoniascoppio.org/apps/flatioplayer/api/install/diagnostics" \
     -H "requesttoken: YOUR_TOKEN"
```

### **Interfaccia Web per Admin**

Gli admin vedono automaticamente:
- **Banner di installazione** se necessario
- **Diagnostics dettagliate** con tabelle complete
- **Status in tempo reale** dello stato di configurazione
- **One-click installation** dal browser

---

## ⚙️ **CONFIGURAZIONE CSP (ANCORA OBBLIGATORIA)**

L'unica cosa che devi ancora fare manualmente è aggiungere i CSP headers.

Aggiungi al file `/home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/.htaccess`:

```apache
<IfModule mod_headers.c>
    Header always set Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' https://embed.flat.io; frame-src 'self' https://embed.flat.io; connect-src 'self' https://embed.flat.io; worker-src 'self' https://embed.flat.io; img-src 'self' data: https://embed.flat.io; style-src 'self' 'unsafe-inline';"
</IfModule>
```

---

## ✅ **VERIFICA INSTALLAZIONE**

### **Test Automatici**
L'app verifica automaticamente:
- ✅ File critici presenti
- ✅ Permissions corretti (755/644)
- ✅ Owner corretto (`ottoniascoppio:ottoniascoppio`)
- ✅ Directory struttura completa
- ✅ Nextcloud integration attiva

### **Test Browser**
1. Vai su `https://cloud.ottoniascoppio.org`
2. Login come admin
3. **"Flat.io Player"** deve apparire nel menu principale
4. Click sull'app → dovrebbe aprirsi senza errori
5. Carica un file `.mxml` per testare la funzionalità

### **Log Monitoring**
I log dell'auto-installazione si trovano in:
```bash
# Log Nextcloud
tail -f /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/data/nextcloud.log | grep flatioplayer

# Cercare linee tipo:
# "Flat.io Player: Auto-installation completed successfully"
```

---

## 🆘 **RISOLUZIONE PROBLEMI**

### **Se l'Auto-Installazione Fallisce**

1. **Controlla i permessi del processo PHP**:
```bash
# Verifica che PHP possa scrivere
ps aux | grep php
ls -la /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/
```

2. **Esegui installazione manuale**:
```bash
sudo -u ottoniascoppio php /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/occ flatioplayer:install --force
```

3. **Verifica diagnostics**:
```bash
sudo -u ottoniascoppio php /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/occ flatioplayer:install --dry-run
```

### **Se l'App Non Appare nel Menu**

L'auto-installazione risolve il 95% dei casi, ma se ancora non funziona:

```bash
# Refresh cache Nextcloud
sudo -u ottoniascoppio php /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/occ app:list --refresh

# Verifica che l'app sia abilitata
sudo -u ottoniascoppio php /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/occ app:list | grep flatioplayer

# Riavvia Apache
sudo systemctl reload apache2
```

---

## 🎉 **VANTAGGI DEL NUOVO SISTEMA**

### ✅ **Per Te (Admin)**
- **Zero configurazione manuale** - tutto automatico
- **Niente script da eseguire** - si configura da solo
- **Rilevamento intelligente** - funziona su qualsiasi server
- **Diagnostics complete** - debug facile se serve
- **Interfaccia grafica** - tutto dal browser

### ✅ **Per gli Utenti**
- **Installazione trasparente** - non vedono la complessità
- **Sempre funzionante** - permessi sempre corretti
- **Aggiornamenti automatici** - mantiene configurazione

### ✅ **Compatibilità Universale**
- ✅ **cloud.ottoniascoppio.org** - Ottimizzato specificamente
- ✅ **Hosting condiviso** - Rileva pattern `/home/user/`
- ✅ **Server dedicati** - Funziona con `www-data`
- ✅ **Configurazioni custom** - Analizza file esistenti

---

## 🚀 **INSTALLA ORA!**

1. **Upload**: `flatio-player-FINAL.tar.gz` su cloud.ottoniascoppio.org
2. **Extract**: nella directory `/apps/` come `flatioplayer`
3. **Enable**: Dal pannello Apps di Nextcloud
4. **Enjoy**: L'app si configura automaticamente!

**Il tuo MusicXML Player è ora completamente automatizzato e pronto per cloud.ottoniascoppio.org! 🎵✨🚀**

Non dovrai mai più preoccuparti di permessi, owner o configurazioni - tutto è automatico!
