# 🔧 Risoluzione Problema: "App not found"

## 🚨 Problema Identificato
Nextcloud non trova l'app **flatioplayer** neanche tra quelle disabilitate.

## 🔍 Cause Più Comuni
1. **App non installata correttamente** nella directory apps
2. **Permessi errati** sui file dell'app
3. **Errori nel file info.xml** 
4. **Cache Nextcloud** non aggiornata
5. **Nome directory** diverso dall'ID app

## 🛠️ Soluzione Step-by-Step

### Step 1: Verifica Posizionamento App
```bash
# Connettiti al tuo server ottoniascoppio.org
ssh user@ottoniascoppio.org

# Controlla se l'app esiste
ls -la /var/www/html/nextcloud/apps/ | grep flatio

# Se non esiste, dovrai installarla
```

### Step 2: Installazione Corretta
Se l'app non c'è, installala:

```bash
# Vai alla directory apps di Nextcloud  
cd /var/www/html/nextcloud/apps

# Se hai già caricato l'archivio
sudo tar -xzf /tmp/flatio-player.tar.gz

# IMPORTANTE: rinomina la directory con l'ID corretto
sudo mv flatio-player flatioplayer

# Imposta permessi corretti
sudo chown -R www-data:www-data flatioplayer
sudo chmod -R 755 flatioplayer
```

### Step 3: Verifica Struttura File
```bash
# Controlla che i file essenziali esistano
ls -la /var/www/html/nextcloud/apps/flatioplayer/appinfo/info.xml
ls -la /var/www/html/nextcloud/apps/flatioplayer/lib/AppInfo/Application.php

# Se mancano, l'installazione è incompleta
```

### Step 4: Verifica info.xml
```bash
# Controlla il contenuto del file info.xml
cat /var/www/html/nextcloud/apps/flatioplayer/appinfo/info.xml

# Verifica che contenga:
# <id>flatioplayer</id>
# <namespace>FlatioPlayer</namespace>
```

### Step 5: Rinfresca Cache Nextcloud
```bash
# Aggiorna la lista delle app
sudo -u www-data php /var/www/html/nextcloud/occ app:list --refresh

# Riavvia Apache
sudo systemctl reload apache2

# Ricontrolla
sudo -u www-data php /var/www/html/nextcloud/occ app:list | grep flatio
```

### Step 6: Script Diagnostico
Usa lo script diagnostico per identificare il problema:

```bash
# Esegui diagnostics integrate via OCC
sudo -u www-data php /path/to/nextcloud/occ flatioplayer:install --dry-run

# Oppure via interfaccia web admin
# → Login come admin → Vai a Flat.io Player → Click "View Diagnostics"
```

## 🔧 Soluzioni Alternative

### Metodo 1: Reinstallazione Pulita
```bash
# Rimuovi completamente (se esiste)
sudo rm -rf /var/www/html/nextcloud/apps/flatioplayer

# Ricrea da zero
cd /var/www/html/nextcloud/apps
sudo tar -xzf /tmp/flatio-player.tar.gz
sudo mv flatio-player flatioplayer
sudo chown -R www-data:www-data flatioplayer
sudo chmod -R 755 flatioplayer

# Prova ad abilitare
sudo -u www-data php /var/www/html/nextcloud/occ app:enable flatioplayer
```

### Metodo 2: Verifica ID App
```bash
# Controlla l'ID nell'info.xml
grep -n "<id>" /var/www/html/nextcloud/apps/flatioplayer/appinfo/info.xml

# Deve essere esattamente: <id>flatioplayer</id>
# Se è diverso, correggilo
```

### Metodo 3: Debug Avanzato
```bash
# Controlla i log di Nextcloud per errori
sudo tail -f /var/www/html/nextcloud/data/nextcloud.log | grep -i error

# Controlla i log di Apache
sudo tail -f /var/log/apache2/error.log

# Test diretto dell'app
sudo -u www-data php -r "
include '/var/www/html/nextcloud/apps/flatioplayer/lib/AppInfo/Application.php';
echo 'App class loaded successfully\n';
"
```

## 🎯 Comando di Installazione Rapida

Se vuoi rifare tutto da capo, usa questo comando singolo:

```bash
#!/bin/bash
# Installazione rapida Flat.io Player

cd /var/www/html/nextcloud/apps && \
sudo rm -rf flatioplayer && \
sudo tar -xzf /tmp/flatio-player.tar.gz && \
sudo mv flatio-player flatioplayer && \
sudo chown -R www-data:www-data flatioplayer && \
sudo chmod -R 755 flatioplayer && \
sudo -u www-data php /var/www/html/nextcloud/occ app:list --refresh && \
sudo systemctl reload apache2 && \
sleep 2 && \
sudo -u www-data php /var/www/html/nextcloud/occ app:enable flatioplayer

echo "Installazione completata!"
```

## 📋 Checklist Verifica

Dopo l'installazione, verifica:

- [ ] Directory `/var/www/html/nextcloud/apps/flatioplayer` esiste
- [ ] File `appinfo/info.xml` contiene `<id>flatioplayer</id>`
- [ ] Permessi: owner `www-data`, permissions `755`
- [ ] `occ app:list` mostra l'app (anche se disabilitata)
- [ ] Nessun errore nei log di Nextcloud/Apache

## 🆘 Se Ancora Non Funziona

Crea un ticket di supporto con queste informazioni:

```bash
# Raccogli informazioni per il supporto
echo "=== DEBUG INFO ===" > debug-info.txt
echo "Nextcloud version:" >> debug-info.txt
sudo -u www-data php /var/www/html/nextcloud/occ status >> debug-info.txt
echo -e "\nApp directory structure:" >> debug-info.txt
ls -la /var/www/html/nextcloud/apps/flatioplayer/ >> debug-info.txt
echo -e "\ninfo.xml content:" >> debug-info.txt
cat /var/www/html/nextcloud/apps/flatioplayer/appinfo/info.xml >> debug-info.txt
echo -e "\nRecent errors:" >> debug-info.txt
sudo tail -20 /var/www/html/nextcloud/data/nextcloud.log >> debug-info.txt

# Invia debug-info.txt per supporto
```

Il problema più comune è il **nome della directory** che deve essere **esattamente** `flatioplayer` per corrispondere all'ID nell'info.xml.
