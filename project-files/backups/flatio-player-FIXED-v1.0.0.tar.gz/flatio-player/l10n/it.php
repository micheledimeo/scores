<?php
$TRANSLATIONS = array(
    "Flat.io Player" => "Flat.io Player",
    "Professional music notation" => "Notazione musicale professionale",
    "Music Library" => "Libreria Musicale",
    "Refresh" => "Aggiorna",
    "No music files found" => "Nessun file musicale trovato",
    "Upload MusicXML files (.mxml, .musicxml, .xml) to get started" => "Carica file MusicXML (.mxml, .musicxml, .xml) per iniziare",
    "Loading files..." => "Caricamento file...",
    "Welcome to Flat.io Player" => "Benvenuto in Flat.io Player",
    "Professional music notation powered by Flat.io" => "Notazione musicale professionale powered by Flat.io",
    "Select a music file from your library" => "Seleziona un file musicale dalla tua libreria",
    "View professional sheet music" => "Visualizza spartiti musicali professionali",
    "Play with high-quality audio" => "Riproduci con audio di alta qualità",
    "Advanced playback controls" => "Controlli di riproduzione avanzati",
    "Choose a file to begin" => "Scegli un file per iniziare",
    "Loading score..." => "Caricamento spartito...",
    "Preparing professional notation" => "Preparazione notazione professionale",
    "Unable to load score" => "Impossibile caricare lo spartito",
    "Try again" => "Riprova",
    "No score loaded" => "Nessuno spartito caricato",
    "Play" => "Riproduci",
    "Pause" => "Pausa",
    "Stop" => "Ferma",
    "Volume" => "Volume"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";