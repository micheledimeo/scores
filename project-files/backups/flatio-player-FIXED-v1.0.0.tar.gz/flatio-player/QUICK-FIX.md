# 🚨 QUICK FIX: Flat.io Player Auto-Installation

## ⚡ **NUOVO SISTEMA AUTO-INSTALLAZIONE**

**Flat.io Player v1.0.0** ora si configura **AUTOMATICAMENTE** quando viene abilitato!

### 🎯 **Soluzione Immediata per cloud.ottoniascoppio.org**

#### **Metodo 1: Auto-Installation (CONSIGLIATO)**

1. **Upload dell'app**:
```bash
# Sul server cloud.ottoniascoppio.org
cd /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps
sudo tar -xzf /tmp/flatio-player-FINAL.tar.gz
sudo mv flatio-player flatioplayer
```

2. **Abilita dal pannello Nextcloud**:
   - Vai su **Apps** → **Your apps**
   - Trova **"Flat.io Player"**
   - Click **"Enable"**

3. **Auto-installazione si attiva**:
   - ✅ Rileva automaticamente: `ottoniascoppio:ottoniascoppio`
   - ✅ Imposta permissions: 755/644
   - ✅ Configura tutto automaticamente
   - ✅ Mostra notifica successo

**È TUTTO! Zero configurazione manuale necessaria!**

#### **Metodo 2: Comando OCC (Se serve controllo manuale)**

```bash
# Abilita + auto-configurazione
sudo -u ottoniascoppio php /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/occ app:enable flatioplayer

# Installazione manuale (opzionale)
sudo -u ottoniascoppio php /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/occ flatioplayer:install

# Diagnostics complete
sudo -u ottoniascoppio php /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/occ flatioplayer:install --dry-run
```

#### **Metodo 3: Interfaccia Web (Per Admin)**

Se accedi all'app come admin e c'è un problema di configurazione:
- **Banner automatico** appare con "Auto-Configure Now"
- **Click del button** → Configurazione istantanea
- **Modal diagnostics** per informazioni dettagliate

---

## 🔧 **Se l'Auto-Installation Non Funziona**

### **Troubleshooting Rapido**

1. **Controlla i log Nextcloud**:
```bash
tail -f /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/data/nextcloud.log | grep flatioplayer
```

2. **Forza reinstallazione**:
```bash
sudo -u ottoniascoppio php /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/occ flatioplayer:install --force
```

3. **Verifica owner manuale**:
```bash
ls -la /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps/flatioplayer/
# Deve essere: ottoniascoppio ottoniascoppio
```

### **Fix Permissions Manuale**

Se l'auto-installazione fallisce:
```bash
cd /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/apps
sudo chown -R ottoniascoppio:ottoniascoppio flatioplayer
sudo chmod -R 755 flatioplayer
sudo find flatioplayer -name "*.php" -exec chmod 644 {} \;
sudo find flatioplayer -name "*.js" -exec chmod 644 {} \;
sudo find flatioplayer -name "*.css" -exec chmod 644 {} \;
```

### **Refresh Cache**

Dopo qualsiasi modifica:
```bash
sudo -u ottoniascoppio php /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/occ app:list --refresh
sudo systemctl reload apache2
```

---

## ✅ **Verifica Installazione**

```bash
# Test app abilitata
sudo -u ottoniascoppio php /home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/occ app:list | grep flatioplayer
# Output: - flatioplayer: Flat.io Player

# Test browser
https://cloud.ottoniascoppio.org
# "Flat.io Player" deve apparire nel menu
```

## 🎯 **CSP Headers (OBBLIGATORI)**

Aggiungi a `/home/ottoniascoppio/domains/cloud.ottoniascoppio.org/public_html/.htaccess`:
```apache
<IfModule mod_headers.c>
    Header always set Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' https://embed.flat.io; frame-src 'self' https://embed.flat.io; connect-src 'self' https://embed.flat.io; worker-src 'self' https://embed.flat.io; img-src 'self' data: https://embed.flat.io; style-src 'self' 'unsafe-inline';"
</IfModule>
```

---

## 🎉 **VANTAGGI AUTO-INSTALLAZIONE**

- ✅ **Zero script manuali** - Tutto automatico al enable
- ✅ **Rilevamento intelligente** - Funziona su qualsiasi hosting
- ✅ **Diagnostics integrate** - Debug facile se necessario
- ✅ **Interfaccia admin** - Configurazione dal browser
- ✅ **Sempre aggiornato** - Mantiene configurazione negli update

**Il tuo Flat.io Player è ora completamente automatico! 🎵✨**
